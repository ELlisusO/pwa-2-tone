# Bóveda

Bóveda personal de cuentas y credenciales. Aplicación web 100% local: no hay backend,
no hay red — todo se cifra y se guarda en el propio dispositivo.

## Puesta en marcha

```bash
npm install
npm run dev       # servidor de desarrollo (Vite)
npm run build     # build de producción -> carpeta dist/
npm run preview   # sirve el build de producción localmente
```

Requiere Node.js 18+. No hay backend que levantar: `npm run dev` es suficiente.

El build usa `HashRouter` (rutas tipo `#/cuentas`) a propósito, para que `dist/index.html`
funcione igual sirviéndolo desde un servidor estático o abriéndolo/instalándolo como
app local, sin depender de que el servidor reescriba rutas.

## Stack

- **React 18 + Vite** — sin backend, sin llamadas de red.
- **Zustand** — estado global (`useAuthStore` para sesión/PIN, `useVaultStore` para los
  datos descifrados en memoria, `useUiStore` para toasts y el diálogo de confirmación).
- **Tailwind CSS** — tokens de diseño propios vía variables CSS (ver `src/index.css` y
  `tailwind.config.js`), sin componentes de ninguna librería de UI.
- **Web Crypto API nativa** — PBKDF2 + AES-256-GCM. No hay ninguna dependencia externa
  de criptografía.
- Todos los iconos son SVG propios (`src/icons/index.jsx`), sin librería de iconos.
- Todos los selectores, calendarios, scrollbars, modales, etc. son componentes propios;
  no se usa `<input type="date">`, `<select>` nativo ni el scrollbar del navegador.
- `public/` trae favicon (SVG + PNG de respaldo), `apple-touch-icon.png` y un
  `manifest.webmanifest` mínimo, todos derivados del propio glyph `IconVault` sobre el
  fondo grafito→verde profundo de la app — nada de un ícono genérico de Vite/React.

## Modelo de seguridad

- El PIN principal (PIN 1) nunca se guarda, ni en texto plano ni como hash. Se deriva
  una clave AES-256 vía PBKDF2 (210 000 iteraciones) y se guarda únicamente un
  **verificador cifrado**: si el PIN introducido permite descifrarlo, es correcto. Esa
  misma clave cifra toda la bóveda en reposo (`localStorage`).
- El PIN 2 (protección adicional) funciona igual, con su propia sal y su propia clave
  derivada (`sensitiveKey`), completamente independiente de la del PIN 1.
- En una cuenta marcada como protegida, sólo tres campos quedan cifrados con la clave
  del PIN 2 en vez de con la del PIN 1: **contraseña, PIN adicional y código de
  recuperación** (de la cuenta y de sus servicios asociados). El resto de la cuenta
  (usuario, categoría, notas, fechas…) sigue protegido por el PIN 1, como el resto de
  la bóveda — así el listado y la búsqueda pueden mostrar esos datos sin pedir el PIN 2.
- La clave del PIN 2 sólo vive en memoria mientras la sesión de "protección adicional"
  está activa (5 minutos de inactividad) y nunca se persiste. Ninguna acción trivial
  (marcar favorito, reordenar, etc.) exige el PIN 2; sólo ver/editar los campos
  protegidos.
- Ambos PIN tienen bloqueo temporal progresivo tras varios intentos fallidos.
- Ver `src/lib/crypto.js` y `src/lib/sensitiveFields.js` para el detalle exacto.

## Copias de seguridad

La exportación descifra los datos en memoria y los vuelve a cifrar con una contraseña
independiente que tú eliges en ese momento (no reutiliza tus PIN). Al importar, si el
archivo trae cuentas protegidas y tu bóveda actual no tiene un PIN 2 configurado, esas
cuentas se restauran sin la protección adicional (se avisa en pantalla) en vez de
fallar la importación completa.

## Decisiones de alcance

El encargo original es muy extenso. Para entregar algo sólido y coherente en vez de
un boceto de todo, tomé estas decisiones conscientes:

- **Relaciones vs. Mapa (secciones 9 y 10):** se implementó la vista de relaciones por
  cuenta (cada cuenta como nodo central con sus servicios alrededor). El "Mapa" global
  de toda la bóveda se marcaba como opcional en el encargo y se dejó fuera de esta
  primera entrega; `RelationsGraph.jsx` está escrito de forma que aceptar varias
  cuentas raíz en el futuro es una extensión natural, no una reescritura.
- **Sensibilidad a nivel de servicio:** los servicios asociados heredan la protección
  adicional de su cuenta; no tienen un interruptor "protección adicional" propio e
  independiente. Simplifica el modelo de claves sin perder el caso de uso real.
- **Fuentes vía Google Fonts:** Fraunces (títulos/cifras) + IBM Plex Sans/Mono (UI y
  datos). Se cargan por `<link>` en `index.html`; si no hay conexión la primera vez,
  cae a una pila de fuentes del sistema igualmente cuidada. El resto de la app funciona
  100% offline (no hay ninguna otra petición de red en todo el código).
- **Sin tests automatizados** ni CI: no se pidieron explícitamente y el foco se puso en
  la superficie funcional completa pedida en el encargo.

## Estructura

```
src/
  lib/         criptografía, almacenamiento, fechas, respaldo (sin UI, sin estado)
  state/       zustand: auth (sesión/PIN), vault (datos), ui (toasts/confirm)
  data/        modelos y fábricas de datos por defecto
  icons/       set de iconos SVG propio
  components/  UI, organizada por dominio (accounts, home, profile, settings…)
  pages/       una por ruta
```

La capa `lib/` no importa nada de `state/` ni de `components/`, así que cambiar de
`localStorage` a IndexedDB (por ejemplo, para adjuntar imágenes más grandes) sólo
implica reescribir `lib/storage.js`.
