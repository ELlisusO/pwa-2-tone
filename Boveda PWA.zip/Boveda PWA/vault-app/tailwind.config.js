/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: 'rgb(var(--c-bg) / <alpha-value>)',
        surface: 'rgb(var(--c-surface) / <alpha-value>)',
        surface2: 'rgb(var(--c-surface-2) / <alpha-value>)',
        surfaceHover: 'rgb(var(--c-surface-hover) / <alpha-value>)',
        border: 'rgb(var(--c-border) / <alpha-value>)',
        borderStrong: 'rgb(var(--c-border-strong) / <alpha-value>)',
        deep: 'rgb(var(--c-deep) / <alpha-value>)',
        emerald: {
          DEFAULT: 'rgb(var(--c-emerald) / <alpha-value>)',
          strong: 'rgb(var(--c-emerald-strong) / <alpha-value>)',
          deep: 'rgb(var(--c-emerald-deep) / <alpha-value>)',
          soft: 'rgb(var(--c-emerald-soft) / <alpha-value>)',
        },
        sage: 'rgb(var(--c-sage) / <alpha-value>)',
        ink: 'rgb(var(--c-ink) / <alpha-value>)',
        inkMuted: 'rgb(var(--c-ink-muted) / <alpha-value>)',
        inkFaint: 'rgb(var(--c-ink-faint) / <alpha-value>)',
        amber: {
          DEFAULT: 'rgb(var(--c-amber) / <alpha-value>)',
          soft: 'rgb(var(--c-amber-soft) / <alpha-value>)',
        },
        brick: {
          DEFAULT: 'rgb(var(--c-brick) / <alpha-value>)',
          soft: 'rgb(var(--c-brick-soft) / <alpha-value>)',
        },
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', '"Iowan Old Style"', 'serif'],
        body: ['"IBM Plex Sans"', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', '"SF Mono"', 'Menlo', 'monospace'],
      },
      borderRadius: {
        xl2: '18px',
        xl3: '22px',
      },
      boxShadow: {
        vault: '0 1px 0 0 rgb(var(--c-border) / 0.6) inset, 0 12px 28px -16px rgb(0 0 0 / 0.55)',
        pop: '0 20px 45px -20px rgb(0 0 0 / 0.65)',
      },
      keyframes: {
        'fade-in': { from: { opacity: 0 }, to: { opacity: 1 } },
        'rise-in': { from: { opacity: 0, transform: 'translateY(6px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
        'scale-in': { from: { opacity: 0, transform: 'scale(0.96)' }, to: { opacity: 1, transform: 'scale(1)' } },
        'sheet-in': { from: { transform: 'translateY(100%)' }, to: { transform: 'translateY(0)' } },
        'ring-sweep': { from: { strokeDashoffset: 'var(--ring-from, 283)' }, to: { strokeDashoffset: 'var(--ring-to, 0)' } },
        shake: { '0%,100%': { transform: 'translateX(0)' }, '20%': { transform: 'translateX(-6px)' }, '40%': { transform: 'translateX(6px)' }, '60%': { transform: 'translateX(-4px)' }, '80%': { transform: 'translateX(4px)' } },
      },
      animation: {
        'fade-in': 'fade-in .2s ease-out',
        'rise-in': 'rise-in .28s cubic-bezier(.2,.7,.2,1)',
        'scale-in': 'scale-in .18s cubic-bezier(.2,.7,.2,1)',
        'sheet-in': 'sheet-in .32s cubic-bezier(.16,1,.3,1)',
        shake: 'shake .4s ease-in-out',
      },
    },
  },
  plugins: [],
}
