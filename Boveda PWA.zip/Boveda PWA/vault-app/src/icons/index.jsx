function Base({ size = 20, className = '', strokeWidth = 1.75, children, ...rest }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...rest}
    >
      {children}
    </svg>
  )
}

/* ---------------- Chrome / navegación / UI ---------------- */

export const IconHome = (p) => (
  <Base {...p}>
    <path d="M3.5 11.5 12 4l8.5 7.5" />
    <path d="M6 10v9.2c0 .44.36.8.8.8H10v-5.6c0-.44.36-.8.8-.8h2.4c.44 0 .8.36.8.8V20h3.2c.44 0 .8-.36.8-.8V10" />
  </Base>
)

export const IconVault = (p) => (
  <Base {...p}>
    <rect x="4" y="4" width="16" height="16" rx="3" />
    <circle cx="12" cy="12" r="3.4" />
    <path d="M12 9.8v.9M12 13.3v.9M9.8 12h.9M13.3 12h.9" />
  </Base>
)

export const IconActivity = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.25" />
    <path d="M12 7.5V12l3 2" />
  </Base>
)

export const IconUser = (p) => (
  <Base {...p}>
    <circle cx="12" cy="8.3" r="3.3" />
    <path d="M5 19.5c0-3.6 3.13-6 7-6s7 2.4 7 6" />
  </Base>
)

export const IconStar = (p) => (
  <Base {...p}>
    <path d="M12 4.2 14.3 9.4l5.6.6-4.2 3.8 1.2 5.6L12 16.6l-4.9 2.8 1.2-5.6-4.2-3.8 5.6-.6Z" />
  </Base>
)

export const IconStarFilled = (p) => (
  <Base fill="currentColor" strokeWidth="1" {...p}>
    <path d="M12 4.2 14.3 9.4l5.6.6-4.2 3.8 1.2 5.6L12 16.6l-4.9 2.8 1.2-5.6-4.2-3.8 5.6-.6Z" />
  </Base>
)

export const IconGrid = (p) => (
  <Base {...p}>
    <rect x="4" y="4" width="7" height="7" rx="1.6" />
    <rect x="13" y="4" width="7" height="7" rx="1.6" />
    <rect x="4" y="13" width="7" height="7" rx="1.6" />
    <rect x="13" y="13" width="7" height="7" rx="1.6" />
  </Base>
)

export const IconSettings = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="2.6" />
    <path d="M12 3.6v2.3M12 18.1v2.3M20.4 12h-2.3M5.9 12H3.6M17.5 6.5l-1.6 1.6M8.1 15.9l-1.6 1.6M17.5 17.5l-1.6-1.6M8.1 8.1 6.5 6.5" />
  </Base>
)

export const IconCloudBackup = (p) => (
  <Base {...p}>
    <path d="M7.2 18.2a4.2 4.2 0 0 1-.6-8.36 5.4 5.4 0 0 1 10.5-2 4.6 4.6 0 0 1-1 10.36" />
    <path d="M12 10.5v7M9.3 15.1l2.7 2.4 2.7-2.4" />
  </Base>
)

export const IconSearch = (p) => (
  <Base {...p}>
    <circle cx="10.8" cy="10.8" r="6.3" />
    <path d="m19.5 19.5-4-4" />
  </Base>
)

export const IconFilter = (p) => (
  <Base {...p}>
    <path d="M4 5.5h16M7.5 12h9M10.5 18.5h3" />
  </Base>
)

export const IconPlus = (p) => (
  <Base {...p}>
    <path d="M12 5v14M5 12h14" />
  </Base>
)

export const IconPlusCircle = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.25" />
    <path d="M12 8.3v7.4M8.3 12h7.4" />
  </Base>
)

export const IconEdit = (p) => (
  <Base {...p}>
    <path d="M15.6 4.6a1.9 1.9 0 0 1 2.7 2.7L8 17.6l-3.6 1 1-3.6Z" />
  </Base>
)

export const IconTrash = (p) => (
  <Base {...p}>
    <path d="M5 7.2h14M9.5 7.2V5.4c0-.5.45-1 1-1h3c.55 0 1 .5 1 1v1.8M6.7 7.2 7.4 19a1.5 1.5 0 0 0 1.5 1.4h6.2A1.5 1.5 0 0 0 16.6 19l.7-11.8" />
  </Base>
)

export const IconChevronDown = (p) => (
  <Base {...p}>
    <path d="m6 9 6 6 6-6" />
  </Base>
)
export const IconChevronUp = (p) => (
  <Base {...p}>
    <path d="m6 15 6-6 6 6" />
  </Base>
)
export const IconChevronLeft = (p) => (
  <Base {...p}>
    <path d="m15 6-6 6 6 6" />
  </Base>
)
export const IconChevronRight = (p) => (
  <Base {...p}>
    <path d="m9 6 6 6-6 6" />
  </Base>
)
export const IconArrowLeft = (p) => (
  <Base {...p}>
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </Base>
)

export const IconMore = (p) => (
  <Base {...p}>
    <circle cx="5.2" cy="12" r="1.15" fill="currentColor" stroke="none" />
    <circle cx="12" cy="12" r="1.15" fill="currentColor" stroke="none" />
    <circle cx="18.8" cy="12" r="1.15" fill="currentColor" stroke="none" />
  </Base>
)

export const IconTag = (p) => (
  <Base {...p}>
    <path d="M11.3 4H6a2 2 0 0 0-2 2v5.3c0 .53.21 1.04.59 1.41l8 8a2 2 0 0 0 2.82 0l5.3-5.3a2 2 0 0 0 0-2.82l-8-8A2 2 0 0 0 11.3 4Z" />
    <circle cx="8.2" cy="8.2" r="1.15" />
  </Base>
)

export const IconLink = (p) => (
  <Base {...p}>
    <path d="M9.5 14.5 14.5 9.5" />
    <path d="M11 6.5l1.2-1.2a3.5 3.5 0 0 1 5 5L16 11.5M13 17.5l-1.2 1.2a3.5 3.5 0 0 1-5-5L8 12.5" />
  </Base>
)

export const IconUpload = (p) => (
  <Base {...p}>
    <path d="M12 15.5V5M8 8.7 12 4.7l4 4" />
    <path d="M5 16.5v2a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 18.5v-2" />
  </Base>
)
export const IconDownload = (p) => (
  <Base {...p}>
    <path d="M12 4.5v10.8M8 12.3l4 4 4-4" />
    <path d="M5 16.5v2a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 18.5v-2" />
  </Base>
)

export const IconImage = (p) => (
  <Base {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.2" />
    <circle cx="8.6" cy="9.4" r="1.5" />
    <path d="m5 18 5-5 3 3 3.5-3.5L20.5 17" />
  </Base>
)

export const IconCamera = (p) => (
  <Base {...p}>
    <path d="M4 8.2A1.7 1.7 0 0 1 5.7 6.5h2l1-1.7h6.6l1 1.7h2A1.7 1.7 0 0 1 20 8.2v9.1a1.7 1.7 0 0 1-1.7 1.7H5.7A1.7 1.7 0 0 1 4 17.3Z" />
    <circle cx="12" cy="12.4" r="3.4" />
  </Base>
)

export const IconClose = (p) => (
  <Base {...p}>
    <path d="m6 6 12 12M18 6 6 18" />
  </Base>
)

export const IconInfo = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.25" />
    <path d="M12 11v5.3M12 8.1v.1" />
  </Base>
)

export const IconClock = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.25" />
    <path d="M12 7.8V12l3.2 1.9" />
  </Base>
)

export const IconCalendar = (p) => (
  <Base {...p}>
    <rect x="4" y="5.5" width="16" height="14.5" rx="2.2" />
    <path d="M4 10h16M8.3 3.5v3.5M15.7 3.5v3.5" />
  </Base>
)

export const IconRefresh = (p) => (
  <Base {...p}>
    <path d="M4.5 12a7.5 7.5 0 0 1 12.6-5.5M19.5 12a7.5 7.5 0 0 1-12.6 5.5" />
    <path d="M17 3.8v3.2h-3.2M7 20.2V17h3.2" />
  </Base>
)

export const IconShare = (p) => (
  <Base {...p}>
    <circle cx="6" cy="12" r="2.1" />
    <circle cx="17.5" cy="6" r="2.1" />
    <circle cx="17.5" cy="18" r="2.1" />
    <path d="m7.9 11 7.7-4M7.9 13l7.7 4" />
  </Base>
)

export const IconMap = (p) => (
  <Base {...p}>
    <path d="M9 4.5 4.5 6v13L9 17.5l6 2 4.5-1.5v-13L15 6.5l-6-2Z" />
    <path d="M9 4.5v13M15 6.5v13" />
  </Base>
)

export const IconSun = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 3v2M12 19v2M4.2 12H2.2M21.8 12h-2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4" />
  </Base>
)
export const IconMoon = (p) => (
  <Base {...p}>
    <path d="M20 13.8A8.2 8.2 0 1 1 10.2 4a6.6 6.6 0 0 0 9.8 9.8Z" />
  </Base>
)

export const IconSliders = (p) => (
  <Base {...p}>
    <path d="M5 6.5h9M17.5 6.5H19M5 12h4.5M12 12H19M5 17.5h9.5M17 17.5H19" />
    <circle cx="12" cy="6.5" r="1.7" fill="currentColor" stroke="none" />
    <circle cx="7" cy="12" r="1.7" fill="currentColor" stroke="none" />
    <circle cx="15" cy="17.5" r="1.7" fill="currentColor" stroke="none" />
  </Base>
)

export const IconFileJson = (p) => (
  <Base {...p}>
    <path d="M7 3.5h7l4 4V19a1.4 1.4 0 0 1-1.4 1.4H7A1.4 1.4 0 0 1 5.6 19V4.9A1.4 1.4 0 0 1 7 3.5Z" />
    <path d="M9.3 12.2c-.7 0-1 .4-1 1v.6c0 .5-.2.8-.7.9.5.1.7.4.7.9v.6c0 .6.3 1 1 1M14.7 12.2c.7 0 1 .4 1 1v.6c0 .5.2.8.7.9-.5.1-.7.4-.7.9v.6c0 .6-.3 1-1 1" />
  </Base>
)

export const IconAlertTriangle = (p) => (
  <Base {...p}>
    <path d="M10.6 4.4 2.9 18a1.6 1.6 0 0 0 1.4 2.4h15.4a1.6 1.6 0 0 0 1.4-2.4L13.4 4.4a1.6 1.6 0 0 0-2.8 0Z" />
    <path d="M12 10v3.6M12 16.4v.1" />
  </Base>
)

export const IconAlertOctagon = (p) => (
  <Base {...p}>
    <path d="M7.9 3.5h8.2l4.4 4.4v8.2l-4.4 4.4H7.9l-4.4-4.4V7.9Z" />
    <path d="M12 8v4.6M12 15.5v.1" />
  </Base>
)

export const IconCheckCircle = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.25" />
    <path d="m8.3 12.3 2.5 2.5 5-5.2" />
  </Base>
)

export const IconCheck = (p) => (
  <Base {...p}>
    <path d="m5 12.5 4.5 4.5L19 7" />
  </Base>
)

export const IconMinus = (p) => (
  <Base {...p}>
    <path d="M5 12h14" />
  </Base>
)

export const IconFolder = (p) => (
  <Base {...p}>
    <path d="M4 6.8c0-.72.58-1.3 1.3-1.3h4.2l1.8 2h7.4c.72 0 1.3.58 1.3 1.3v8.9c0 .72-.58 1.3-1.3 1.3H5.3A1.3 1.3 0 0 1 4 17.7Z" />
  </Base>
)

/* ---------------- Seguridad ---------------- */

export const IconShield = (p) => (
  <Base {...p}>
    <path d="M12 3.6 19 6.3v5.4c0 4.8-3 8-7 9-4-1-7-4.2-7-9V6.3Z" />
  </Base>
)
export const IconShieldCheck = (p) => (
  <Base {...p}>
    <path d="M12 3.6 19 6.3v5.4c0 4.8-3 8-7 9-4-1-7-4.2-7-9V6.3Z" />
    <path d="m9 12 2.1 2.1L15.3 10" />
  </Base>
)
export const IconLock = (p) => (
  <Base {...p}>
    <rect x="5" y="10.5" width="14" height="9.5" rx="2.1" />
    <path d="M8 10.5V7.8a4 4 0 0 1 8 0v2.7" />
  </Base>
)
export const IconLockOpen = (p) => (
  <Base {...p}>
    <rect x="5" y="10.5" width="14" height="9.5" rx="2.1" />
    <path d="M8 10.5V7.8a4 4 0 0 1 7.6-1.7" />
  </Base>
)
export const IconKey = (p) => (
  <Base {...p}>
    <circle cx="7.3" cy="16.7" r="3.2" />
    <path d="m9.5 14.5 8-8M14.4 9.6l2 2M17.4 6.6l2 2" />
  </Base>
)
export const IconEye = (p) => (
  <Base {...p}>
    <path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12Z" />
    <circle cx="12" cy="12" r="2.6" />
  </Base>
)
export const IconEyeOff = (p) => (
  <Base {...p}>
    <path d="M4 4l16 16" />
    <path d="M10.6 6.1A9.6 9.6 0 0 1 12 5.8c6 0 9.5 6.2 9.5 6.2a15 15 0 0 1-3.2 3.9M7.4 7.5A14.7 14.7 0 0 0 2.5 12S6 18.2 12 18.2a9.7 9.7 0 0 0 3.2-.55" />
    <path d="M9.9 10a2.6 2.6 0 0 0 3.6 3.6" />
  </Base>
)
export const IconCopy = (p) => (
  <Base {...p}>
    <rect x="9" y="9" width="11" height="11" rx="2" />
    <path d="M15 9V6.5A1.5 1.5 0 0 0 13.5 5H6a2 2 0 0 0-2 2v7.5A1.5 1.5 0 0 0 5.5 16H9" />
  </Base>
)

/* ---------------- Biblioteca de iconos seleccionables ---------------- */

export const IconBank = (p) => (
  <Base {...p}>
    <path d="M3.5 9.5 12 4l8.5 5.5" />
    <path d="M5 9.5v8.3M9.3 9.5v8.3M14.7 9.5v8.3M19 9.5v8.3" />
    <path d="M4 19.8h16" />
  </Base>
)
export const IconCard = (p) => (
  <Base {...p}>
    <rect x="3" y="6" width="18" height="12.5" rx="2.2" />
    <path d="M3 10.2h18M6.5 14.5h4" />
  </Base>
)
export const IconWallet = (p) => (
  <Base {...p}>
    <path d="M4 7.3A1.8 1.8 0 0 1 5.8 5.5h11.4A1.8 1.8 0 0 1 19 7.3V8H5.8A1.8 1.8 0 0 1 4 6.2" />
    <rect x="3.5" y="8" width="17" height="11" rx="2.1" />
    <circle cx="15.6" cy="13.5" r="1.15" fill="currentColor" stroke="none" />
  </Base>
)
export const IconCoins = (p) => (
  <Base {...p}>
    <ellipse cx="9" cy="8" rx="5" ry="3" />
    <path d="M4 8v4c0 1.66 2.24 3 5 3s5-1.34 5-3V8" />
    <ellipse cx="15" cy="14" rx="5" ry="3" />
    <path d="M10 14v3.3c0 1.66 2.24 3 5 3s5-1.34 5-3V14" />
  </Base>
)
export const IconChartLine = (p) => (
  <Base {...p}>
    <path d="M4 19.5h16" />
    <path d="M5 15.5 9.5 10l3.3 3 5.7-6.5" />
  </Base>
)
export const IconTrendingUp = (p) => (
  <Base {...p}>
    <path d="m4 16 5.5-5.5 3.5 3.5L20.5 6.5" />
    <path d="M15 6.5h5.5V12" />
  </Base>
)
export const IconComputer = (p) => (
  <Base {...p}>
    <rect x="3.5" y="5" width="17" height="11" rx="1.8" />
    <path d="M9 20h6M12 16v4" />
  </Base>
)
export const IconCloud = (p) => (
  <Base {...p}>
    <path d="M7.2 18.2a4.2 4.2 0 0 1-.6-8.36 5.4 5.4 0 0 1 10.5-2 4.6 4.6 0 0 1-1 10.36Z" />
  </Base>
)
export const IconServer = (p) => (
  <Base {...p}>
    <rect x="4" y="4.5" width="16" height="6" rx="1.6" />
    <rect x="4" y="13.5" width="16" height="6" rx="1.6" />
    <circle cx="7.4" cy="7.5" r="0.9" fill="currentColor" stroke="none" />
    <circle cx="7.4" cy="16.5" r="0.9" fill="currentColor" stroke="none" />
  </Base>
)
export const IconPhone = (p) => (
  <Base {...p}>
    <rect x="7" y="3" width="10" height="18" rx="2.2" />
    <path d="M10.5 18h3" />
  </Base>
)
export const IconGlobe = (p) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.25" />
    <path d="M3.75 12h16.5M12 3.75c2.2 2.2 3.3 5.1 3.3 8.25s-1.1 6.05-3.3 8.25c-2.2-2.2-3.3-5.1-3.3-8.25S9.8 5.95 12 3.75Z" />
  </Base>
)
export const IconCode = (p) => (
  <Base {...p}>
    <path d="m9 8-4.5 4L9 16M15 8l4.5 4-4.5 4M13.2 5.5l-2.4 13" />
  </Base>
)
export const IconGamepad = (p) => (
  <Base {...p}>
    <path d="M7 8.5h10a4 4 0 0 1 3.95 4.6l-.5 3.2a2.4 2.4 0 0 1-4.3 1.05L15 16H9l-1.15 1.35a2.4 2.4 0 0 1-4.3-1.05l-.5-3.2A4 4 0 0 1 7 8.5Z" />
    <path d="M8.3 11v3M6.8 12.5h3M15.3 11.3h.1M17.6 13.1h.1" />
  </Base>
)
export const IconJoystick = (p) => (
  <Base {...p}>
    <circle cx="12" cy="7" r="2.6" />
    <path d="M12 9.6V15" />
    <rect x="6" y="15" width="12" height="4.5" rx="1.6" />
  </Base>
)
export const IconTrophy = (p) => (
  <Base {...p}>
    <path d="M7 5h10v4.2a5 5 0 0 1-10 0Z" />
    <path d="M7 6H4.6A2.6 2.6 0 0 0 7 10.6M17 6h2.4A2.6 2.6 0 0 1 17 10.6" />
    <path d="M12 14.2V17M8.5 20h7" />
  </Base>
)
export const IconUniversity = (p) => (
  <Base {...p}>
    <path d="m3.5 9 8.5-4.5L20.5 9 12 12Z" />
    <path d="M6 10.8v5.4c1.6 1.4 4 2.1 6 2.1s4.4-.7 6-2.1v-5.4" />
  </Base>
)
export const IconBook = (p) => (
  <Base {...p}>
    <path d="M5 5.3c1.4-.7 3.6-1 7-.4v13.8c-3.4-.6-5.6-.3-7 .4Z" />
    <path d="M19 5.3c-1.4-.7-3.6-1-7-.4v13.8c3.4-.6 5.6-.3 7 .4Z" />
  </Base>
)
export const IconDiploma = (p) => (
  <Base {...p}>
    <rect x="3.5" y="4.5" width="17" height="12" rx="2" />
    <path d="M8.5 20 9.5 16.5M15.5 20 14.5 16.5" />
    <circle cx="12" cy="10.5" r="2.4" />
  </Base>
)
export const IconFlask = (p) => (
  <Base {...p}>
    <path d="M10 3.5h4M10.3 3.5v6.2L5.5 18a1.8 1.8 0 0 0 1.55 2.7h9.9A1.8 1.8 0 0 0 18.5 18l-4.8-8.3V3.5" />
    <path d="M8.3 15.5h7.4" />
  </Base>
)
export const IconHouse = (p) => (
  <Base {...p}>
    <path d="M4.5 11 12 5l7.5 6" />
    <path d="M6.5 10v8.5c0 .55.45 1 1 1H16c.55 0 1-.45 1-1V10" />
    <path d="M10 19.5v-5h4v5" />
  </Base>
)
export const IconContactCard = (p) => (
  <Base {...p}>
    <rect x="3" y="5" width="18" height="14" rx="2.1" />
    <circle cx="8.5" cy="11" r="2" />
    <path d="M5.7 16c.5-1.6 1.7-2.4 2.8-2.4s2.3.8 2.8 2.4M14.5 9.5h4M14.5 13h4M14.5 16h2.7" />
  </Base>
)
export const IconBriefcase = (p) => (
  <Base {...p}>
    <rect x="3" y="7.5" width="18" height="11.5" rx="2" />
    <path d="M8.5 7.5V6a1.6 1.6 0 0 1 1.6-1.6h3.8A1.6 1.6 0 0 1 15.5 6v1.5M3 12.5h18" />
  </Base>
)
export const IconBuilding = (p) => (
  <Base {...p}>
    <rect x="5.5" y="3.5" width="9" height="17" rx="1.2" />
    <path d="M8.3 7h.1M11.9 7h.1M8.3 10.4h.1M11.9 10.4h.1M8.3 13.8h.1M11.9 13.8h.1" />
    <path d="M14.5 10.5H19a1 1 0 0 1 1 1v9h-5.5" />
  </Base>
)
export const IconBuilding2 = (p) => (
  <Base {...p}>
    <rect x="4" y="9" width="7" height="11.5" rx="1.2" />
    <rect x="13" y="4" width="7" height="16.5" rx="1.2" />
    <path d="M6.5 12h.1M6.5 15h.1M6.5 18h.1M15.5 7.5h.1M15.5 10.5h.1M15.5 13.5h.1M15.5 16.5h.1" />
  </Base>
)
export const IconChat = (p) => (
  <Base {...p}>
    <path d="M4 5.5h16v10.2H9.8L5.5 19V15.7H4Z" />
  </Base>
)
export const IconCart = (p) => (
  <Base {...p}>
    <path d="M3.5 4.5h2l1.9 10.6a1.8 1.8 0 0 0 1.8 1.5h7a1.8 1.8 0 0 0 1.78-1.5L19.5 8H6" />
    <circle cx="9.5" cy="19.5" r="1.3" />
    <circle cx="16.5" cy="19.5" r="1.3" />
  </Base>
)
export const IconMusic = (p) => (
  <Base {...p}>
    <path d="M9.5 17.5V6l9-1.5v11" />
    <circle cx="7" cy="17.8" r="2.3" />
    <circle cx="16" cy="16.2" r="2.3" />
  </Base>
)
export const IconPlane = (p) => (
  <Base {...p}>
    <path d="m3 14 18-6.5c1-.35 1.8.75 1.15 1.6L15 18.5l-1.5-4.6L9 16.5l.2 3.2-2-2.3-3.2-.2 2.3-2Z" />
  </Base>
)
export const IconSparkle = (p) => (
  <Base {...p}>
    <path d="M12 3.5c.5 3 2 4.5 5 5-3 .5-4.5 2-5 5-.5-3-2-4.5-5-5 3-.5 4.5-2 5-5Z" />
    <path d="M18.5 15c.25 1.4.95 2.1 2.35 2.35-1.4.25-2.1.95-2.35 2.35-.25-1.4-.95-2.1-2.35-2.35 1.4-.25 2.1-.95 2.35-2.35Z" />
  </Base>
)
export const IconHeart = (p) => (
  <Base {...p}>
    <path d="M12 19.5s-7.5-4.6-7.5-10a4.3 4.3 0 0 1 7.5-2.85A4.3 4.3 0 0 1 19.5 9.5c0 5.4-7.5 10-7.5 10Z" />
  </Base>
)
export const IconLayers = (p) => (
  <Base {...p}>
    <path d="m12 3.5 8 4.2-8 4.2-8-4.2Z" />
    <path d="m4 12 8 4.2 8-4.2M4 15.8 12 20l8-4.2" />
  </Base>
)

export const ICON_LIBRARY = [
  {
    group: 'Finanzas',
    items: [
      { key: 'bank', label: 'Banco', Icon: IconBank },
      { key: 'card', label: 'Tarjeta', Icon: IconCard },
      { key: 'wallet', label: 'Cartera', Icon: IconWallet },
      { key: 'coins', label: 'Monedas', Icon: IconCoins },
      { key: 'chart-line', label: 'Gráfico', Icon: IconChartLine },
      { key: 'trending-up', label: 'Inversión', Icon: IconTrendingUp },
    ],
  },
  {
    group: 'Tecnología',
    items: [
      { key: 'computer', label: 'Computadora', Icon: IconComputer },
      { key: 'cloud', label: 'Nube', Icon: IconCloud },
      { key: 'server', label: 'Servidor', Icon: IconServer },
      { key: 'phone', label: 'Teléfono', Icon: IconPhone },
      { key: 'globe', label: 'Web', Icon: IconGlobe },
      { key: 'code', label: 'Software', Icon: IconCode },
    ],
  },
  {
    group: 'Gaming',
    items: [
      { key: 'gamepad', label: 'Gamepad', Icon: IconGamepad },
      { key: 'joystick', label: 'Consola', Icon: IconJoystick },
      { key: 'trophy', label: 'Logros', Icon: IconTrophy },
    ],
  },
  {
    group: 'Estudio',
    items: [
      { key: 'university', label: 'Universidad', Icon: IconUniversity },
      { key: 'book', label: 'Libro', Icon: IconBook },
      { key: 'diploma', label: 'Diploma', Icon: IconDiploma },
      { key: 'flask', label: 'Laboratorio', Icon: IconFlask },
    ],
  },
  {
    group: 'Personal',
    items: [
      { key: 'user', label: 'Usuario', Icon: IconUser },
      { key: 'house', label: 'Casa', Icon: IconHouse },
      { key: 'contact-card', label: 'Contacto', Icon: IconContactCard },
      { key: 'calendar', label: 'Calendario', Icon: IconCalendar },
    ],
  },
  {
    group: 'Trabajo',
    items: [
      { key: 'briefcase', label: 'Maletín', Icon: IconBriefcase },
      { key: 'building', label: 'Oficina', Icon: IconBuilding },
      { key: 'building2', label: 'Empresa', Icon: IconBuilding2 },
    ],
  },
  {
    group: 'Seguridad',
    items: [
      { key: 'shield', label: 'Escudo', Icon: IconShield },
      { key: 'shield-check', label: 'Verificado', Icon: IconShieldCheck },
      { key: 'lock', label: 'Candado', Icon: IconLock },
      { key: 'key', label: 'Llave', Icon: IconKey },
    ],
  },
  {
    group: 'General',
    items: [
      { key: 'star', label: 'Favorito', Icon: IconStar },
      { key: 'tag', label: 'Etiqueta', Icon: IconTag },
      { key: 'folder', label: 'Carpeta', Icon: IconFolder },
      { key: 'image', label: 'Imagen', Icon: IconImage },
      { key: 'music', label: 'Música', Icon: IconMusic },
      { key: 'cart', label: 'Compras', Icon: IconCart },
      { key: 'chat', label: 'Redes', Icon: IconChat },
      { key: 'plane', label: 'Viajes', Icon: IconPlane },
      { key: 'heart', label: 'Personal', Icon: IconHeart },
      { key: 'sparkle', label: 'Otros', Icon: IconSparkle },
      { key: 'layers', label: 'Servicios', Icon: IconLayers },
    ],
  },
]

export const ICON_MAP = ICON_LIBRARY.reduce((acc, g) => {
  g.items.forEach((it) => (acc[it.key] = it.Icon))
  return acc
}, {})

export function IconByKey({ iconKey, ...rest }) {
  const Icon = ICON_MAP[iconKey] || IconSparkle
  return <Icon {...rest} />
}
