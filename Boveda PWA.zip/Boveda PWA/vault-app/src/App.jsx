import { useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from './state/useAuthStore.js'
import { useVaultStore } from './state/useVaultStore.js'
import SetupWizard from './components/auth/SetupWizard.jsx'
import LockScreen from './components/auth/LockScreen.jsx'
import AppShell from './components/layout/AppShell.jsx'
import HomePage from './pages/HomePage.jsx'
import AccountsPage from './pages/AccountsPage.jsx'
import AccountDetailPage from './pages/AccountDetailPage.jsx'
import FavoritesPage from './pages/FavoritesPage.jsx'
import CategoriesPage from './pages/CategoriesPage.jsx'
import ActivityPage from './pages/ActivityPage.jsx'
import ProfilePage from './pages/ProfilePage.jsx'
import SettingsPage from './pages/SettingsPage.jsx'
import BackupPage from './pages/BackupPage.jsx'

export default function App() {
  const status = useAuthStore((s) => s.status)
  const init = useAuthStore((s) => s.init)
  const theme = useVaultStore((s) => s.settings.theme)

  useEffect(() => {
    init()
  }, [init])

  useEffect(() => {
    if (status !== 'unlocked') return
    const isLight = theme === 'light'
    document.documentElement.setAttribute('data-theme', isLight ? 'light' : 'dark')
    document.documentElement.classList.toggle('dark', !isLight)
  }, [theme, status])

  if (status === 'checking') {
    return <div className="flex min-h-full items-center justify-center bg-bg text-[13px] text-inkFaint">Cargando…</div>
  }
  if (status === 'setup') return <SetupWizard />
  if (status === 'locked') return <LockScreen />

  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<HomePage />} />
        <Route path="cuentas" element={<AccountsPage />} />
        <Route path="cuentas/:id" element={<AccountDetailPage />} />
        <Route path="favoritas" element={<FavoritesPage />} />
        <Route path="categorias" element={<CategoriesPage />} />
        <Route path="registro" element={<ActivityPage />} />
        <Route path="perfil" element={<ProfilePage />} />
        <Route path="configuracion" element={<SettingsPage />} />
        <Route path="respaldo" element={<BackupPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
