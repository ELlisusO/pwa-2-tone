import { create } from 'zustand'
import { uuid, encryptJSON } from '../lib/crypto.js'
import { nowISO } from '../lib/dateUtils.js'
import * as storage from '../lib/storage.js'
import { encryptAccountSensitive, decryptAccountSensitive } from '../lib/sensitiveFields.js'
import { buildDefaultCategories, FALLBACK_CATEGORY_ID } from '../data/defaultCategories.js'
import { emptyProfile } from '../data/model.js'
import { useAuthStore } from './useAuthStore.js'

function emptyVaultState() {
  return {
    loaded: false,
    accounts: [],
    categories: [],
    tags: [],
    profile: emptyProfile(),
    activityLog: [],
    settings: { theme: 'dark' },
  }
}

export const useVaultStore = create((set, get) => ({
  ...emptyVaultState(),

  loadFromDecrypted(state) {
    set({ ...emptyVaultState(), ...state, loaded: true })
  },

  clearInMemory() {
    set(emptyVaultState())
  },

  async persist() {
    const { vaultKey } = useAuthStore.getState()
    if (!vaultKey) return
    const { accounts, categories, tags, profile, activityLog, settings } = get()
    const payload = await encryptJSON({ accounts, categories, tags, profile, activityLog, settings }, vaultKey)
    storage.writeBlob(payload)
  },

  logActivity(type, message) {
    const entry = { id: uuid(), type, message, timestamp: nowISO() }
    set((state) => ({ activityLog: [entry, ...state.activityLog].slice(0, 500) }))
  },

  async logAndPersist(type, message) {
    get().logActivity(type, message)
    await get().persist()
  },

  // ---------------- Cuentas ----------------

  /** Descifra (si hace falta, solicitando el PIN 2) una copia editable en texto plano de una cuenta. */
  async getEditableAccount(id) {
    const account = get().accounts.find((a) => a.id === id)
    if (!account) return null
    if (!account.sensitive) return account
    const key = await useAuthStore.getState().requestSensitiveUnlock(`Ver "${account.name || 'cuenta protegida'}"`)
    if (!key) return null
    return decryptAccountSensitive(account, key)
  },

  async upsertAccount(accountPlain) {
    const authState = useAuthStore.getState()
    const isNew = !get().accounts.some((a) => a.id === accountPlain.id)
    let toStore = { ...accountPlain, updatedAt: nowISO() }
    if (toStore.sensitive) {
      if (!authState.sensitiveKey) {
        const err = new Error('Debes verificar tu PIN 2 para guardar una cuenta protegida.')
        err.code = 'SENSITIVE_LOCKED'
        throw err
      }
      toStore = await encryptAccountSensitive(toStore, authState.sensitiveKey)
    }
    set((state) => ({
      accounts: isNew ? [...state.accounts, toStore] : state.accounts.map((a) => (a.id === toStore.id ? toStore : a)),
    }))
    get().logActivity(
      isNew ? 'account_created' : 'account_updated',
      `Cuenta "${accountPlain.name || 'sin nombre'}" ${isNew ? 'creada' : 'actualizada'}`
    )
    await get().persist()
    return toStore
  },

  async deleteAccount(id) {
    const acc = get().accounts.find((a) => a.id === id)
    set((state) => ({ accounts: state.accounts.filter((a) => a.id !== id) }))
    if (acc) get().logActivity('account_deleted', `Cuenta "${acc.name || 'sin nombre'}" eliminada`)
    await get().persist()
  },

  async toggleFavorite(id) {
    set((state) => ({
      accounts: state.accounts.map((a) => (a.id === id ? { ...a, favorite: !a.favorite, updatedAt: nowISO() } : a)),
    }))
    await get().persist()
  },

  // "favorite" nunca es un campo cifrado (ni en cuentas ni en servicios), así que esto
  // se puede mutar directamente sin pasar por la clave del PIN 2, incluso en cuentas
  // protegidas: evita pedir el segundo PIN de forma innecesaria (ver sección 13).
  async toggleServiceFavorite(accountId, serviceId) {
    set((state) => ({
      accounts: state.accounts.map((a) =>
        a.id === accountId
          ? { ...a, services: (a.services || []).map((s) => (s.id === serviceId ? { ...s, favorite: !s.favorite } : s)) }
          : a
      ),
    }))
    await get().persist()
  },

  async reencryptSensitiveAccounts(oldKey, newKey) {
    const accounts = await Promise.all(
      get().accounts.map(async (a) => {
        if (!a.sensitive) return a
        const plain = await decryptAccountSensitive(a, oldKey)
        return encryptAccountSensitive(plain, newKey)
      })
    )
    set({ accounts })
    await get().logAndPersist('pin2_changed', 'PIN 2 actualizado')
  },

  async downgradeAllSensitive(sensitiveKey) {
    let count = 0
    const accounts = await Promise.all(
      get().accounts.map(async (a) => {
        if (!a.sensitive) return a
        count += 1
        const plain = await decryptAccountSensitive(a, sensitiveKey)
        return { ...plain, sensitive: false }
      })
    )
    set({ accounts })
    if (count > 0) {
      await get().logAndPersist(
        'pin2_disabled',
        `Protección adicional desactivada en ${count} cuenta${count > 1 ? 's' : ''}`
      )
    } else {
      await get().persist()
    }
  },

  // ---------------- Categorías ----------------

  async addCategory({ name, icon }) {
    const cat = { id: uuid(), name: name.trim(), icon: icon || 'sparkle', isDefault: false }
    set((state) => ({ categories: [...state.categories, cat] }))
    await get().logAndPersist('category_created', `Categoría "${cat.name}" creada`)
    return cat
  },

  async updateCategory(id, updates) {
    set((state) => ({ categories: state.categories.map((c) => (c.id === id ? { ...c, ...updates } : c)) }))
    await get().logAndPersist('category_updated', 'Categoría actualizada')
  },

  async deleteCategory(id) {
    if (id === FALLBACK_CATEGORY_ID) {
      return { ok: false, error: 'No puedes eliminar la categoría "Otros".' }
    }
    const cat = get().categories.find((c) => c.id === id)
    set((state) => ({
      categories: state.categories.filter((c) => c.id !== id),
      accounts: state.accounts.map((a) => (a.categoryId === id ? { ...a, categoryId: FALLBACK_CATEGORY_ID } : a)),
    }))
    await get().logAndPersist('category_deleted', `Categoría "${cat?.name || ''}" eliminada`)
    return { ok: true }
  },

  // ---------------- Etiquetas ----------------

  async addTag(name) {
    const clean = (name || '').trim()
    if (!clean) return null
    const existing = get().tags.find((t) => t.name.toLowerCase() === clean.toLowerCase())
    if (existing) return existing
    const tag = { id: uuid(), name: clean }
    set((state) => ({ tags: [...state.tags, tag] }))
    await get().persist()
    return tag
  },

  async deleteTag(id) {
    set((state) => ({
      tags: state.tags.filter((t) => t.id !== id),
      accounts: state.accounts.map((a) => ({
        ...a,
        tags: (a.tags || []).filter((tid) => tid !== id),
        services: (a.services || []).map((s) => ({ ...s, tags: (s.tags || []).filter((tid) => tid !== id) })),
      })),
    }))
    await get().logAndPersist('tag_deleted', 'Etiqueta eliminada')
  },

  // ---------------- Perfil ----------------

  async updateProfileBasic(updates) {
    set((state) => ({ profile: { ...state.profile, ...updates } }))
    await get().logAndPersist('profile_updated', 'Perfil actualizado')
  },

  async addProfileEntry(section, entry) {
    set((state) => ({ profile: { ...state.profile, [section]: [...(state.profile[section] || []), entry] } }))
    await get().logAndPersist('profile_updated', 'Perfil actualizado')
  },

  async updateProfileEntry(section, id, updates) {
    set((state) => ({
      profile: {
        ...state.profile,
        [section]: state.profile[section].map((e) => (e.id === id ? { ...e, ...updates } : e)),
      },
    }))
    await get().logAndPersist('profile_updated', 'Perfil actualizado')
  },

  async removeProfileEntry(section, id) {
    set((state) => ({
      profile: { ...state.profile, [section]: state.profile[section].filter((e) => e.id !== id) },
    }))
    await get().logAndPersist('profile_updated', 'Perfil actualizado')
  },

  async updateSkills(skills) {
    set((state) => ({ profile: { ...state.profile, skills } }))
    await get().persist()
  },

  // ---------------- Ajustes ----------------

  async updateSettings(updates) {
    set((state) => ({ settings: { ...state.settings, ...updates } }))
    await get().persist()
  },

  // ---------------- Respaldo ----------------

  async replaceAll(bundle) {
    set({
      accounts: bundle.accounts || [],
      categories: bundle.categories?.length ? bundle.categories : buildDefaultCategories(),
      tags: bundle.tags || [],
      profile: bundle.profile || emptyProfile(),
      activityLog: bundle.activityLog || [],
      settings: bundle.settings || { theme: 'dark' },
    })
    await get().logAndPersist('backup_imported', 'Bóveda restaurada desde una copia de seguridad')
  },
}))
