import { create } from 'zustand'
import { deriveKey, createVerifier, checkVerifier, randomB64, encryptJSON, decryptJSON } from '../lib/crypto.js'
import * as storage from '../lib/storage.js'
import { buildDefaultCategories } from '../data/defaultCategories.js'
import { emptyProfile } from '../data/model.js'
import { useVaultStore } from './useVaultStore.js'

const SENSITIVE_SESSION_MS = 5 * 60 * 1000 // reverificar PIN 2 pasado este tiempo de inactividad
export const PIN1_LENGTH = 6
export const PIN2_LENGTH = 6

function lockoutDurationMs(attempts) {
  if (attempts < 5) return 0
  if (attempts < 7) return 30 * 1000
  if (attempts < 9) return 2 * 60 * 1000
  return 5 * 60 * 1000
}

function buildDefaultVaultState() {
  return {
    accounts: [],
    categories: buildDefaultCategories(),
    tags: [],
    profile: emptyProfile(),
    activityLog: [],
    settings: { theme: 'dark' },
  }
}

export const useAuthStore = create((set, get) => ({
  status: 'checking', // checking | setup | locked | unlocked
  meta: null,
  vaultKey: null,
  sensitiveKey: null,
  sensitiveUnlockedAt: null,
  gateOpen: false,
  gateResolve: null,
  gateReason: '',
  error: '',

  init() {
    const meta = storage.readMeta()
    if (!meta) {
      set({ status: 'setup', meta: null })
    } else {
      set({ status: 'locked', meta })
    }
  },

  lockoutRemainingMs() {
    const meta = get().meta
    if (!meta?.lockoutUntil) return 0
    return Math.max(0, meta.lockoutUntil - Date.now())
  },

  async createVault(pin1) {
    const salt = randomB64(16)
    const key = await deriveKey(pin1, salt)
    const verifier = await createVerifier(key)
    const meta = {
      version: storage.SCHEMA_VERSION,
      createdAt: new Date().toISOString(),
      pin1: { salt, verifier },
      pin2: null,
      failedAttempts: 0,
      lockoutUntil: null,
      pin2FailedAttempts: 0,
      pin2LockoutUntil: null,
    }
    const defaultState = buildDefaultVaultState()
    const blob = await encryptJSON(defaultState, key)
    storage.writeMeta(meta)
    storage.writeBlob(blob)
    useVaultStore.getState().loadFromDecrypted(defaultState)
    set({ status: 'unlocked', meta, vaultKey: key, error: '' })
  },

  async unlock(pin1) {
    const meta = get().meta
    if (!meta) return { ok: false, error: 'No hay bóveda creada.' }
    const remaining = get().lockoutRemainingMs()
    if (remaining > 0) return { ok: false, lockedMs: remaining }

    const key = await deriveKey(pin1, meta.pin1.salt)
    const valid = await checkVerifier(meta.pin1.verifier, key)

    if (!valid) {
      const failedAttempts = (meta.failedAttempts || 0) + 1
      const wait = lockoutDurationMs(failedAttempts)
      const nextMeta = {
        ...meta,
        failedAttempts,
        lockoutUntil: wait > 0 ? Date.now() + wait : null,
      }
      storage.writeMeta(nextMeta)
      set({ meta: nextMeta })
      return { ok: false, lockedMs: wait }
    }

    const blob = storage.readBlob()
    let state
    try {
      state = await decryptJSON(blob, key)
    } catch {
      return { ok: false, error: 'No se pudo leer la bóveda. Los datos podrían estar dañados.' }
    }

    const nextMeta = { ...meta, failedAttempts: 0, lockoutUntil: null }
    storage.writeMeta(nextMeta)
    useVaultStore.getState().loadFromDecrypted(state)
    set({ status: 'unlocked', meta: nextMeta, vaultKey: key, sensitiveKey: null, sensitiveUnlockedAt: null })
    return { ok: true }
  },

  lock() {
    useVaultStore.getState().clearInMemory()
    set({ status: 'locked', vaultKey: null, sensitiveKey: null, sensitiveUnlockedAt: null })
  },

  async changePin1(oldPin, newPin) {
    const meta = get().meta
    const oldKey = await deriveKey(oldPin, meta.pin1.salt)
    const ok = await checkVerifier(meta.pin1.verifier, oldKey)
    if (!ok) return { ok: false, error: 'El PIN actual no es correcto.' }

    const salt = randomB64(16)
    const newKey = await deriveKey(newPin, salt)
    const verifier = await createVerifier(newKey)
    const nextMeta = { ...meta, pin1: { salt, verifier } }
    set({ vaultKey: newKey, meta: nextMeta })
    storage.writeMeta(nextMeta)
    await useVaultStore.getState().logAndPersist('pin_changed', 'PIN principal actualizado')
    return { ok: true }
  },

  hasPin2() {
    return !!get().meta?.pin2
  },

  pin2LockoutRemainingMs() {
    const meta = get().meta
    if (!meta?.pin2LockoutUntil) return 0
    return Math.max(0, meta.pin2LockoutUntil - Date.now())
  },

  async setupPin2(pin2) {
    const meta = get().meta
    const salt = randomB64(16)
    const key = await deriveKey(pin2, salt)
    const verifier = await createVerifier(key)
    const nextMeta = { ...meta, pin2: { salt, verifier }, pin2FailedAttempts: 0, pin2LockoutUntil: null }
    storage.writeMeta(nextMeta)
    set({ meta: nextMeta, sensitiveKey: key, sensitiveUnlockedAt: Date.now() })
    await useVaultStore.getState().logAndPersist('pin2_enabled', 'PIN 2 (protección adicional) configurado')
    return { ok: true }
  },

  async changePin2(oldPin2, newPin2) {
    const meta = get().meta
    const oldKey = await deriveKey(oldPin2, meta.pin2.salt)
    const ok = await checkVerifier(meta.pin2.verifier, oldKey)
    if (!ok) return { ok: false, error: 'El PIN 2 actual no es correcto.' }

    const salt = randomB64(16)
    const newKey = await deriveKey(newPin2, salt)
    const verifier = await createVerifier(newKey)
    const nextMeta = { ...meta, pin2: { salt, verifier } }

    await useVaultStore.getState().reencryptSensitiveAccounts(oldKey, newKey)
    storage.writeMeta(nextMeta)
    set({ meta: nextMeta, sensitiveKey: newKey, sensitiveUnlockedAt: Date.now() })
    return { ok: true }
  },

  async disablePin2(currentPin2) {
    const meta = get().meta
    const key = await deriveKey(currentPin2, meta.pin2.salt)
    const ok = await checkVerifier(meta.pin2.verifier, key)
    if (!ok) return { ok: false, error: 'El PIN 2 no es correcto.' }

    await useVaultStore.getState().downgradeAllSensitive(key)
    const nextMeta = { ...meta, pin2: null, pin2FailedAttempts: 0, pin2LockoutUntil: null }
    storage.writeMeta(nextMeta)
    set({ meta: nextMeta, sensitiveKey: null, sensitiveUnlockedAt: null })
    return { ok: true }
  },

  isSensitiveUnlocked() {
    const { sensitiveKey, sensitiveUnlockedAt } = get()
    if (!sensitiveKey || !sensitiveUnlockedAt) return false
    if (Date.now() - sensitiveUnlockedAt > SENSITIVE_SESSION_MS) return false
    return true
  },

  touchSensitiveSession() {
    if (get().sensitiveKey) set({ sensitiveUnlockedAt: Date.now() })
  },

  lockSensitive() {
    set({ sensitiveKey: null, sensitiveUnlockedAt: null })
  },

  async verifyPin2(pin2) {
    const meta = get().meta
    if (!meta?.pin2) return { ok: false, error: 'No hay PIN 2 configurado.' }
    const remaining = get().pin2LockoutRemainingMs()
    if (remaining > 0) return { ok: false, lockedMs: remaining }

    const key = await deriveKey(pin2, meta.pin2.salt)
    const valid = await checkVerifier(meta.pin2.verifier, key)
    if (!valid) {
      const failed = (meta.pin2FailedAttempts || 0) + 1
      const wait = lockoutDurationMs(failed)
      const nextMeta = { ...meta, pin2FailedAttempts: failed, pin2LockoutUntil: wait > 0 ? Date.now() + wait : null }
      storage.writeMeta(nextMeta)
      set({ meta: nextMeta })
      return { ok: false, lockedMs: wait }
    }
    const nextMeta = { ...meta, pin2FailedAttempts: 0, pin2LockoutUntil: null }
    storage.writeMeta(nextMeta)
    set({ meta: nextMeta, sensitiveKey: key, sensitiveUnlockedAt: Date.now() })
    return { ok: true, key }
  },

  /**
   * Puerta reutilizable para revelar/editar información protegida.
   * Si ya hay una sesión de PIN 2 vigente, resuelve al instante.
   * Si no, abre el modal global de PIN 2 y espera la respuesta del usuario.
   */
  requestSensitiveUnlock(reason = '') {
    if (get().isSensitiveUnlocked()) {
      get().touchSensitiveSession()
      return Promise.resolve(get().sensitiveKey)
    }
    return new Promise((resolve) => {
      set({ gateOpen: true, gateReason: reason, gateResolve: resolve })
    })
  },

  resolveGate(key) {
    const resolve = get().gateResolve
    set({ gateOpen: false, gateResolve: null, gateReason: '' })
    if (resolve) resolve(key || null)
  },

  async wipeVault() {
    storage.wipeAll()
    useVaultStore.getState().clearInMemory()
    set({
      status: 'setup',
      meta: null,
      vaultKey: null,
      sensitiveKey: null,
      sensitiveUnlockedAt: null,
    })
  },
}))
