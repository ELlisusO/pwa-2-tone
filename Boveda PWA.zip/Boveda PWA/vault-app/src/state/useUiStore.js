import { create } from 'zustand'
import { uuid } from '../lib/crypto.js'

export const useUiStore = create((set, get) => ({
  toasts: [],
  confirmState: null, // { title, message, danger, confirmLabel, cancelLabel, resolve }

  pushToast(message, variant = 'default') {
    const id = uuid()
    set((state) => ({ toasts: [...state.toasts, { id, message, variant }] }))
    setTimeout(() => get().dismissToast(id), 4200)
  },

  dismissToast(id) {
    set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }))
  },

  confirm({ title, message, danger = false, confirmLabel = 'Confirmar', cancelLabel = 'Cancelar' }) {
    return new Promise((resolve) => {
      set({ confirmState: { title, message, danger, confirmLabel, cancelLabel, resolve } })
    })
  },

  resolveConfirm(result) {
    const c = get().confirmState
    set({ confirmState: null })
    if (c) c.resolve(result)
  },
}))
