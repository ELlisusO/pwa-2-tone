import { uuid } from '../lib/crypto.js'
import { nowISO } from '../lib/dateUtils.js'
import { FALLBACK_CATEGORY_ID } from './defaultCategories.js'

export function emptyRecovery() {
  return { method: '', email: '', additionalPin: '', backupCode: '', twoFactor: '' }
}

export function emptyDateEntry(type = 'other') {
  return { id: uuid(), type, customLabel: '', value: '' }
}

export function emptyService(categoryId = FALLBACK_CATEGORY_ID) {
  const t = nowISO()
  return {
    id: uuid(),
    name: '',
    username: '',
    email: '',
    password: '',
    url: '',
    phone: '',
    recovery: emptyRecovery(),
    categoryId,
    notes: '',
    tags: [],
    dates: [],
    favorite: false,
    icon: 'layers',
    customImage: null,
    createdAt: t,
    updatedAt: t,
  }
}

export function emptyAccount(categoryId = FALLBACK_CATEGORY_ID) {
  const t = nowISO()
  return {
    id: uuid(),
    name: '',
    username: '',
    email: '',
    password: '',
    url: '',
    phone: '',
    recovery: emptyRecovery(),
    categoryId,
    tags: [],
    favorite: false,
    description: '',
    sensitive: false,
    dates: [],
    services: [],
    icon: 'sparkle',
    customImage: null,
    createdAt: t,
    updatedAt: t,
  }
}

export function emptyProfile() {
  return {
    photo: null,
    fullName: '',
    headline: '',
    city: '',
    country: '',
    email: '',
    phones: [],
    website: '',
    education: [],
    experience: [],
    projects: [],
    certificates: [],
    skills: [],
  }
}

export function emptyEducationEntry() {
  return { id: uuid(), institution: '', degree: '', field: '', startDate: '', endDate: '', description: '' }
}
export function emptyExperienceEntry() {
  return { id: uuid(), company: '', role: '', startDate: '', endDate: '', description: '' }
}
export function emptyProjectEntry() {
  return { id: uuid(), name: '', description: '', date: '', link: '', tech: '', image: null }
}
export function emptyCertificateEntry() {
  return { id: uuid(), name: '', institution: '', date: '', description: '', reference: '' }
}

/**
 * Devuelve la lista de motivos por los que una cuenta se considera
 * incompleta (array vacío = completa). Usado por "Revisar" y "Estado".
 */
export function accountIssues(account) {
  const issues = []
  if (!account.name?.trim()) issues.push('Sin nombre')
  if (!account.categoryId) issues.push('Sin categoría')
  if (!account.username?.trim() && !account.email?.trim()) issues.push('Sin usuario ni correo')
  const hasPassword = typeof account.password === 'string' ? account.password.trim() : !!account.password
  if (!hasPassword) issues.push('Sin contraseña')
  const rec = account.recovery || {}
  if (!rec.email?.trim() && !rec.method?.trim() && !rec.backupCode?.trim()) {
    issues.push('Sin información de recuperación')
  }
  if (!account.dates || account.dates.length === 0) issues.push('Sin fecha registrada')
  return issues
}

export function isAccountComplete(account) {
  return accountIssues(account).length === 0
}
