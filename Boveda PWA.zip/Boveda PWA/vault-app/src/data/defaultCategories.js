export function buildDefaultCategories() {
  return [
    { id: 'cat-gaming', name: 'Gaming', icon: 'gamepad', isDefault: true },
    { id: 'cat-finanzas', name: 'Finanzas', icon: 'bank', isDefault: true },
    { id: 'cat-estudio', name: 'Estudio', icon: 'university', isDefault: true },
    { id: 'cat-trabajo', name: 'Trabajo', icon: 'briefcase', isDefault: true },
    { id: 'cat-redes', name: 'Redes', icon: 'chat', isDefault: true },
    { id: 'cat-compras', name: 'Compras', icon: 'cart', isDefault: true },
    { id: 'cat-entretenimiento', name: 'Entretenimiento', icon: 'music', isDefault: true },
    { id: 'cat-servicios', name: 'Servicios', icon: 'cloud', isDefault: true },
    { id: 'cat-software', name: 'Software', icon: 'code', isDefault: true },
    { id: 'cat-viajes', name: 'Viajes', icon: 'plane', isDefault: true },
    { id: 'cat-personal', name: 'Personal', icon: 'house', isDefault: true },
    { id: 'cat-otros', name: 'Otros', icon: 'sparkle', isDefault: true },
  ]
}

export const FALLBACK_CATEGORY_ID = 'cat-otros'
