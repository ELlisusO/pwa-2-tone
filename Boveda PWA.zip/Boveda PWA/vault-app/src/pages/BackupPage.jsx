import PageHeader from '../components/common/PageHeader.jsx'
import BackupSettings from '../components/settings/BackupSettings.jsx'

export default function BackupPage() {
  return (
    <div>
      <PageHeader title="Copias de seguridad" backTo="/configuracion" />
      <BackupSettings />
    </div>
  )
}
