import { useEffect, useState } from 'react'
import { useVaultStore } from '../state/useVaultStore.js'
import { useUiStore } from '../state/useUiStore.js'
import PageHeader from '../components/common/PageHeader.jsx'
import Button from '../components/common/Button.jsx'
import Input from '../components/common/Input.jsx'
import Modal from '../components/common/Modal.jsx'
import Avatar from '../components/common/Avatar.jsx'
import IconPicker from '../components/common/IconPicker.jsx'
import { IconByKey, IconPlus, IconEdit, IconTrash } from '../icons/index.jsx'
import { FALLBACK_CATEGORY_ID } from '../data/defaultCategories.js'

function CategoryModal({ open, onClose, initial }) {
  const addCategory = useVaultStore((s) => s.addCategory)
  const updateCategory = useVaultStore((s) => s.updateCategory)
  const pushToast = useUiStore((s) => s.pushToast)
  const [name, setName] = useState('')
  const [icon, setIcon] = useState('sparkle')
  const [iconPickerOpen, setIconPickerOpen] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (open) {
      setName(initial?.name || '')
      setIcon(initial?.icon || 'sparkle')
      setError('')
    }
  }, [open, initial])

  async function handleSave(e) {
    e.preventDefault()
    if (!name.trim()) {
      setError('Ponle un nombre a la categoría.')
      return
    }
    if (initial) {
      await updateCategory(initial.id, { name: name.trim(), icon })
      pushToast('Categoría actualizada.', 'success')
    } else {
      await addCategory({ name: name.trim(), icon })
      pushToast('Categoría creada.', 'success')
    }
    onClose()
  }

  return (
    <Modal open={open} onClose={onClose} title={initial ? 'Editar categoría' : 'Nueva categoría'} size="sm">
      <form onSubmit={handleSave} className="space-y-4 pb-2">
        <div className="flex items-center gap-3.5">
          <button type="button" onClick={() => setIconPickerOpen(true)}>
            <Avatar iconKey={icon} size="lg" />
          </button>
          <div className="flex-1">
            <Input label="Nombre" value={name} onChange={(e) => setName(e.target.value)} error={error} autoFocus />
          </div>
        </div>
        <Button type="submit" full>
          Guardar
        </Button>
      </form>
      <IconPicker open={iconPickerOpen} onClose={() => setIconPickerOpen(false)} value={icon} onChange={({ icon }) => setIcon(icon)} />
    </Modal>
  )
}

export default function CategoriesPage() {
  const categories = useVaultStore((s) => s.categories)
  const accounts = useVaultStore((s) => s.accounts)
  const deleteCategory = useVaultStore((s) => s.deleteCategory)
  const confirm = useUiStore((s) => s.confirm)
  const pushToast = useUiStore((s) => s.pushToast)

  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)

  async function handleDelete(cat) {
    const count = accounts.filter((a) => a.categoryId === cat.id).length
    const ok = await confirm({
      title: `Eliminar "${cat.name}"`,
      message:
        count > 0
          ? `Hay ${count} cuenta${count > 1 ? 's' : ''} en esta categoría. Se moverán a "Otros".`
          : 'Esta categoría se eliminará de tu bóveda.',
      danger: true,
      confirmLabel: 'Eliminar',
    })
    if (!ok) return
    const res = await deleteCategory(cat.id)
    if (!res.ok) pushToast(res.error, 'danger')
    else pushToast('Categoría eliminada.', 'default')
  }

  return (
    <div>
      <PageHeader
        title="Categorías"
        subtitle={`${categories.length} categorías`}
        backTo="/cuentas"
        action={
          <Button
            size="sm"
            icon={IconPlus}
            onClick={() => {
              setEditing(null)
              setModalOpen(true)
            }}
          >
            Nueva
          </Button>
        }
      />
      <div className="space-y-2">
        {categories.map((cat) => {
          const count = accounts.filter((a) => a.categoryId === cat.id).length
          return (
            <div key={cat.id} className="flex items-center gap-3 rounded-xl2 border border-border bg-surface p-3">
              <Avatar iconKey={cat.icon} size="md" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[14px] text-ink">{cat.name}</p>
                <p className="text-[12px] text-inkFaint">{count} cuenta{count === 1 ? '' : 's'}</p>
              </div>
              <button
                onClick={() => {
                  setEditing(cat)
                  setModalOpen(true)
                }}
                className="shrink-0 rounded-lg p-2 text-inkFaint hover:bg-surfaceHover hover:text-ink"
              >
                <IconEdit size={15} />
              </button>
              {cat.id !== FALLBACK_CATEGORY_ID && (
                <button onClick={() => handleDelete(cat)} className="shrink-0 rounded-lg p-2 text-inkFaint hover:bg-surfaceHover hover:text-brick-soft">
                  <IconTrash size={15} />
                </button>
              )}
            </div>
          )
        })}
      </div>
      <CategoryModal open={modalOpen} onClose={() => setModalOpen(false)} initial={editing} />
    </div>
  )
}
