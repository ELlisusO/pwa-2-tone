import ProfileHeader from '../components/profile/ProfileHeader.jsx'
import RepeatableEntrySection from '../components/profile/RepeatableEntrySection.jsx'
import SkillsEditor from '../components/profile/SkillsEditor.jsx'
import { formatDate } from '../lib/dateUtils.js'
import { emptyEducationEntry, emptyExperienceEntry, emptyProjectEntry, emptyCertificateEntry } from '../data/model.js'
import { IconUniversity, IconBriefcase, IconFolder, IconDiploma } from '../icons/index.jsx'

function dateRange(start, end) {
  if (!start && !end) return ''
  return `${start ? formatDate(start, { withYear: true }) : '—'} — ${end ? formatDate(end, { withYear: true }) : 'Presente'}`
}

export default function ProfilePage() {
  return (
    <div className="space-y-8">
      <ProfileHeader />

      <RepeatableEntrySection
        section="education"
        icon={IconUniversity}
        title="Educación"
        emptyFactory={emptyEducationEntry}
        fields={[
          { key: 'institution', label: 'Institución' },
          { key: 'degree', label: 'Grado' },
          { key: 'field', label: 'Carrera / área' },
          { key: 'startDate', label: 'Fecha de inicio', type: 'date' },
          { key: 'endDate', label: 'Fecha final', type: 'date' },
          { key: 'description', label: 'Descripción', type: 'textarea' },
        ]}
        renderSummary={(e) => ({
          title: e.degree || e.institution || 'Sin título',
          subtitle: [e.institution, e.field].filter(Boolean).join(' · '),
          meta: dateRange(e.startDate, e.endDate),
          description: e.description,
        })}
      />

      <RepeatableEntrySection
        section="experience"
        icon={IconBriefcase}
        title="Experiencia"
        emptyFactory={emptyExperienceEntry}
        fields={[
          { key: 'company', label: 'Empresa' },
          { key: 'role', label: 'Puesto' },
          { key: 'startDate', label: 'Fecha de inicio', type: 'date' },
          { key: 'endDate', label: 'Fecha final', type: 'date' },
          { key: 'description', label: 'Descripción', type: 'textarea' },
        ]}
        renderSummary={(e) => ({
          title: e.role || e.company || 'Sin puesto',
          subtitle: e.company,
          meta: dateRange(e.startDate, e.endDate),
          description: e.description,
        })}
      />

      <RepeatableEntrySection
        section="projects"
        icon={IconFolder}
        title="Proyectos"
        emptyFactory={emptyProjectEntry}
        fields={[
          { key: 'name', label: 'Nombre' },
          { key: 'description', label: 'Descripción', type: 'textarea' },
          { key: 'date', label: 'Fecha', type: 'date' },
          { key: 'link', label: 'Enlace' },
          { key: 'tech', label: 'Tecnologías / intereses' },
          { key: 'image', label: 'Imagen', type: 'image' },
        ]}
        renderSummary={(e) => ({
          title: e.name || 'Sin nombre',
          subtitle: e.tech,
          meta: e.date ? formatDate(e.date) : '',
          description: e.description,
        })}
      />

      <RepeatableEntrySection
        section="certificates"
        icon={IconDiploma}
        title="Diplomas y certificados"
        emptyFactory={emptyCertificateEntry}
        fields={[
          { key: 'name', label: 'Nombre' },
          { key: 'institution', label: 'Institución' },
          { key: 'date', label: 'Fecha', type: 'date' },
          { key: 'reference', label: 'Referencia / enlace al documento' },
          { key: 'description', label: 'Descripción', type: 'textarea' },
        ]}
        renderSummary={(e) => ({
          title: e.name || 'Sin nombre',
          subtitle: e.institution,
          meta: e.date ? formatDate(e.date) : '',
          description: e.description,
        })}
      />

      <SkillsEditor />
    </div>
  )
}
