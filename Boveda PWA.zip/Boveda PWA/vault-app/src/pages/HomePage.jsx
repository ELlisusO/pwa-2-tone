import { Link } from 'react-router-dom'
import { useVaultStore } from '../state/useVaultStore.js'
import { useAuthStore } from '../state/useAuthStore.js'
import SectionHeader from '../components/common/SectionHeader.jsx'
import SummaryStats from '../components/home/SummaryStats.jsx'
import DistributionChart from '../components/home/DistributionChart.jsx'
import FavoritesSection from '../components/home/FavoritesSection.jsx'
import ReviewSection from '../components/home/ReviewSection.jsx'
import SecurityStatus from '../components/home/SecurityStatus.jsx'
import { accountIssues } from '../data/model.js'
import { IconStar, IconGrid, IconCloudBackup, IconSettings } from '../icons/index.jsx'

const QUICK = [
  { to: '/favoritas', label: 'Favoritas', icon: IconStar },
  { to: '/categorias', label: 'Categorías', icon: IconGrid },
  { to: '/respaldo', label: 'Copias', icon: IconCloudBackup },
  { to: '/configuracion', label: 'Configuración', icon: IconSettings },
]

export default function HomePage() {
  const accounts = useVaultStore((s) => s.accounts)
  const categories = useVaultStore((s) => s.categories)
  const hasPin2 = useAuthStore((s) => !!s.meta?.pin2)

  const totalServices = accounts.reduce((sum, a) => sum + (a.services?.length || 0), 0)
  const favorites = accounts.filter((a) => a.favorite)
  const withIssues = accounts.map((a) => ({ ...a, issues: accountIssues(a) })).filter((a) => a.issues.length > 0)

  return (
    <div className="space-y-8 lg:space-y-10">
      <div>
        <p className="text-[12.5px] font-medium uppercase tracking-[0.14em] text-emerald">Bienvenido de nuevo</p>
        <h1 className="mt-1 font-display text-[28px] font-medium tracking-tight text-ink">Mi bóveda</h1>
      </div>

      <div className="chip-row -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 lg:hidden">
        {QUICK.map((q) => (
          <Link
            key={q.to}
            to={q.to}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-surface2 px-3 py-1.5 text-[12.5px] text-inkMuted hover:text-ink"
          >
            <q.icon size={13} />
            {q.label}
          </Link>
        ))}
      </div>

      <SummaryStats
        stats={{
          accounts: accounts.length,
          services: totalServices,
          categories: categories.length,
          favorites: favorites.length,
        }}
      />

      <section>
        <SectionHeader title="Distribución" subtitle="Cuentas por categoría" />
        <div className="rounded-xl2 border border-border bg-surface p-4">
          <DistributionChart categories={categories} accounts={accounts} />
        </div>
      </section>

      <section>
        <SectionHeader title="Favoritas" action={<Link to="/favoritas" className="text-[12.5px] text-emerald hover:underline">Ver todas</Link>} />
        <FavoritesSection accounts={favorites} />
      </section>

      <section>
        <SectionHeader title="Revisar" subtitle="Cuentas con información pendiente" />
        <ReviewSection items={withIssues} />
      </section>

      <section>
        <SectionHeader title="Estado de la bóveda" />
        <SecurityStatus accounts={accounts} hasPin2={hasPin2} />
      </section>
    </div>
  )
}
