import { useVaultStore } from '../state/useVaultStore.js'
import SectionHeader from '../components/common/SectionHeader.jsx'
import ActivityTimeline from '../components/activity/ActivityTimeline.jsx'

export default function ActivityPage() {
  const activityLog = useVaultStore((s) => s.activityLog)

  return (
    <div>
      <SectionHeader title="Registro" subtitle="Actividad reciente de tu bóveda" />
      <ActivityTimeline entries={activityLog} />
    </div>
  )
}
