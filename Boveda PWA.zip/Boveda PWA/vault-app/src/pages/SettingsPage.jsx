import { Link } from 'react-router-dom'
import PageHeader from '../components/common/PageHeader.jsx'
import PinSettings from '../components/settings/PinSettings.jsx'
import AppearanceSettings from '../components/settings/AppearanceSettings.jsx'
import TagManager from '../components/settings/TagManager.jsx'
import DangerZone from '../components/settings/DangerZone.jsx'
import SectionHeader from '../components/common/SectionHeader.jsx'
import { IconGrid, IconCloudBackup, IconChevronRight } from '../icons/index.jsx'

export default function SettingsPage() {
  return (
    <div className="space-y-8">
      <PageHeader title="Configuración" backTo="/" />

      <PinSettings />

      <AppearanceSettings />

      <section>
        <SectionHeader title="Organización" />
        <div className="space-y-2">
          <Link to="/categorias" className="flex items-center gap-3 rounded-xl2 border border-border bg-surface p-3.5 hover:border-borderStrong">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
              <IconGrid size={16} />
            </span>
            <span className="flex-1 text-[13.5px] text-ink">Administrar categorías</span>
            <IconChevronRight size={16} className="text-inkFaint" />
          </Link>
          <Link to="/respaldo" className="flex items-center gap-3 rounded-xl2 border border-border bg-surface p-3.5 hover:border-borderStrong">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
              <IconCloudBackup size={16} />
            </span>
            <span className="flex-1 text-[13.5px] text-ink">Copias de seguridad</span>
            <IconChevronRight size={16} className="text-inkFaint" />
          </Link>
        </div>
      </section>

      <TagManager />

      <DangerZone />
    </div>
  )
}
