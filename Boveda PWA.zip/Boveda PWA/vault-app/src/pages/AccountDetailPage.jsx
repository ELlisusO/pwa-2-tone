import { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { useVaultStore } from '../state/useVaultStore.js'
import { useUiStore } from '../state/useUiStore.js'
import PageHeader from '../components/common/PageHeader.jsx'
import Avatar from '../components/common/Avatar.jsx'
import Button from '../components/common/Button.jsx'
import Chip from '../components/common/Chip.jsx'
import Collapsible from '../components/common/Collapsible.jsx'
import EmptyState from '../components/common/EmptyState.jsx'
import AccountForm from '../components/accounts/AccountForm.jsx'
import ServiceForm from '../components/accounts/ServiceForm.jsx'
import ServiceCard from '../components/accounts/ServiceCard.jsx'
import ServiceDetailModal from '../components/accounts/ServiceDetailModal.jsx'
import SensitiveField from '../components/accounts/SensitiveField.jsx'
import RelationsGraph from '../components/accounts/RelationsGraph.jsx'
import { accountIssues } from '../data/model.js'
import { formatDate, dateTypeLabel } from '../lib/dateUtils.js'
import {
  IconByKey,
  IconStar,
  IconStarFilled,
  IconEdit,
  IconTrash,
  IconInfo,
  IconLock,
  IconCalendar,
  IconLayers,
  IconShare,
  IconPlus,
  IconGlobe,
  IconShieldCheck,
  IconAlertTriangle,
  IconVault,
} from '../icons/index.jsx'

export default function AccountDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()

  const accounts = useVaultStore((s) => s.accounts)
  const categories = useVaultStore((s) => s.categories)
  const tags = useVaultStore((s) => s.tags)
  const toggleFavorite = useVaultStore((s) => s.toggleFavorite)
  const deleteAccount = useVaultStore((s) => s.deleteAccount)
  const upsertAccount = useVaultStore((s) => s.upsertAccount)
  const getEditableAccount = useVaultStore((s) => s.getEditableAccount)
  const toggleServiceFavorite = useVaultStore((s) => s.toggleServiceFavorite)
  const confirm = useUiStore((s) => s.confirm)
  const pushToast = useUiStore((s) => s.pushToast)

  const [accountFormOpen, setAccountFormOpen] = useState(false)
  const [editableAccount, setEditableAccount] = useState(null)
  const [serviceFormOpen, setServiceFormOpen] = useState(false)
  const [editingService, setEditingService] = useState(null)
  const [detailServiceId, setDetailServiceId] = useState(null)

  const account = accounts.find((a) => a.id === id)

  if (!account) {
    return (
      <div>
        <PageHeader title="Cuenta" backTo="/cuentas" />
        <EmptyState
          icon={IconVault}
          title="No se encontró la cuenta"
          description="Puede que ya se haya eliminado."
          action={
            <Link to="/cuentas">
              <Button>Volver a cuentas</Button>
            </Link>
          }
        />
      </div>
    )
  }

  const category = categories.find((c) => c.id === account.categoryId)
  const accountTags = (account.tags || []).map((tid) => tags.find((t) => t.id === tid)).filter(Boolean)
  const issues = accountIssues(account)
  const detailService = account.services?.find((s) => s.id === detailServiceId) || null

  async function openEditAccount() {
    const plain = await getEditableAccount(account.id)
    if (!plain) return
    setEditableAccount(plain)
    setAccountFormOpen(true)
  }

  async function handleDeleteAccount() {
    const ok = await confirm({
      title: `Eliminar "${account.name}"`,
      message: 'Esta cuenta y todos sus servicios asociados se eliminarán permanentemente. Esta acción no se puede deshacer.',
      danger: true,
      confirmLabel: 'Eliminar',
    })
    if (!ok) return
    await deleteAccount(account.id)
    navigate('/cuentas')
  }

  async function openEditService(serviceId) {
    const plain = await getEditableAccount(account.id)
    if (!plain) return
    const svc = plain.services.find((s) => s.id === serviceId)
    setEditingService(svc)
    setServiceFormOpen(true)
    setDetailServiceId(null)
  }

  function openAddService() {
    setEditingService(null)
    setServiceFormOpen(true)
  }

  async function handleSaveService(serviceData) {
    const plain = await getEditableAccount(account.id)
    if (!plain) return
    const exists = plain.services.some((s) => s.id === serviceData.id)
    const nextServices = exists
      ? plain.services.map((s) => (s.id === serviceData.id ? serviceData : s))
      : [...plain.services, serviceData]
    try {
      await upsertAccount({ ...plain, services: nextServices })
      pushToast(exists ? 'Servicio actualizado.' : 'Servicio añadido.', 'success')
    } catch {
      pushToast('No se pudo guardar el servicio. Verifica tu PIN 2 e inténtalo de nuevo.', 'danger')
    }
  }

  async function handleDeleteService(serviceId) {
    const svc = account.services.find((s) => s.id === serviceId)
    const ok = await confirm({
      title: `Eliminar "${svc?.name || 'servicio'}"`,
      message: 'Esta acción no se puede deshacer.',
      danger: true,
      confirmLabel: 'Eliminar',
    })
    if (!ok) return
    const plain = await getEditableAccount(account.id)
    if (!plain) return
    await upsertAccount({ ...plain, services: plain.services.filter((s) => s.id !== serviceId) })
    setDetailServiceId(null)
    pushToast('Servicio eliminado.', 'default')
  }

  async function handleToggleServiceFavorite(serviceId) {
    await toggleServiceFavorite(account.id, serviceId)
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title=""
        backTo="/cuentas"
        action={
          <div className="flex gap-1.5">
            <button
              onClick={() => toggleFavorite(account.id)}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-surface2 text-inkFaint hover:text-amber"
            >
              {account.favorite ? <IconStarFilled size={16} className="text-amber" /> : <IconStar size={16} />}
            </button>
            <button
              onClick={openEditAccount}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-surface2 text-inkFaint hover:text-ink"
            >
              <IconEdit size={15} />
            </button>
            <button
              onClick={handleDeleteAccount}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-surface2 text-inkFaint hover:text-brick-soft"
            >
              <IconTrash size={15} />
            </button>
          </div>
        }
      />

      <div className="flex items-start gap-4">
        <Avatar iconKey={account.icon} customImage={account.customImage} size="xl" />
        <div className="min-w-0 flex-1 pt-1">
          <div className="flex items-center gap-1.5">
            <h1 className="truncate font-display text-[21px] font-medium text-ink">{account.name || 'Sin nombre'}</h1>
            {account.sensitive && <IconShieldCheck size={15} className="shrink-0 text-emerald" />}
          </div>
          <p className="truncate text-[13.5px] text-inkFaint">{account.username || account.email || 'Sin usuario ni correo'}</p>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {category && <Chip icon={(p) => <IconByKey iconKey={category.icon} {...p} />} label={category.name} size="sm" />}
            {accountTags.map((t) => (
              <Chip key={t.id} label={t.name} size="sm" />
            ))}
          </div>
        </div>
      </div>

      {issues.length > 0 && (
        <div className="flex items-start gap-2.5 rounded-xl2 border border-amber/30 bg-amber/[0.07] px-4 py-3 text-[13px] text-amber-soft">
          <IconAlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>Información pendiente: {issues.join(', ')}.</span>
        </div>
      )}

      <Collapsible title="Información" icon={IconInfo}>
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          <Field label="Usuario" value={account.username} />
          <Field label="Correo" value={account.email} />
          <Field label="Teléfono asociado" value={account.phone} />
          <Field
            label="URL"
            value={
              account.url ? (
                <a href={account.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-emerald hover:underline">
                  <IconGlobe size={12} />
                  {account.url}
                </a>
              ) : null
            }
          />
        </div>
      </Collapsible>

      <Collapsible title="Seguridad" icon={IconLock} badge={account.sensitive && <IconShieldCheck size={13} className="text-emerald" />}>
        <div className="space-y-3.5">
          <SensitiveField label="Contraseña" rawValue={account.password} sensitive={account.sensitive} />
          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
            <Field label="Método de recuperación" value={account.recovery?.method} />
            <Field label="Correo de recuperación" value={account.recovery?.email} />
            <Field label="Autenticación utilizada" value={account.recovery?.twoFactor} />
          </div>
          {account.recovery?.additionalPin && (
            <SensitiveField label="PIN adicional" rawValue={account.recovery.additionalPin} sensitive={account.sensitive} />
          )}
          {account.recovery?.backupCode && (
            <SensitiveField label="Código de recuperación" rawValue={account.recovery.backupCode} sensitive={account.sensitive} />
          )}
        </div>
      </Collapsible>

      <Collapsible title="Fechas" icon={IconCalendar} defaultOpen={account.dates?.length > 0}>
        {account.dates?.length > 0 ? (
          <div className="space-y-2">
            {account.dates.map((d) => (
              <div key={d.id} className="flex items-center justify-between text-[13.5px]">
                <span className="text-inkMuted">{d.type === 'other' ? d.customLabel || 'Otra fecha' : dateTypeLabel(d.type)}</span>
                <span className="font-mono tabular-nums text-ink">{formatDate(d.value)}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-[13px] text-inkFaint">Sin fechas registradas.</p>
        )}
      </Collapsible>

      <Collapsible
        title="Servicios asociados"
        icon={IconLayers}
        badge={account.services?.length > 0 && <span className="text-[12px] text-inkFaint">{account.services.length}</span>}
      >
        <div className="space-y-2.5">
          {(account.services || []).map((s) => (
            <ServiceCard
              key={s.id}
              service={s}
              onOpen={() => setDetailServiceId(s.id)}
              onEdit={() => openEditService(s.id)}
              onDelete={() => handleDeleteService(s.id)}
              onToggleFavorite={() => handleToggleServiceFavorite(s.id)}
            />
          ))}
          <Button variant="secondary" size="sm" icon={IconPlus} onClick={openAddService}>
            Añadir servicio
          </Button>
        </div>
      </Collapsible>

      <Collapsible title="Relaciones" icon={IconShare} defaultOpen={account.services?.length > 0}>
        <RelationsGraph account={account} onSelectService={(sid) => setDetailServiceId(sid)} />
      </Collapsible>

      <Collapsible title="Notas" icon={IconInfo} defaultOpen={!!account.description}>
        {account.description ? (
          <p className="whitespace-pre-wrap text-[13.5px] text-inkMuted">{account.description}</p>
        ) : (
          <p className="text-[13px] text-inkFaint">Sin notas adicionales.</p>
        )}
      </Collapsible>

      <AccountForm
        open={accountFormOpen}
        onClose={() => setAccountFormOpen(false)}
        initialAccount={editableAccount}
        defaultCategoryId={account.categoryId}
      />

      <ServiceForm
        open={serviceFormOpen}
        onClose={() => setServiceFormOpen(false)}
        initialService={editingService}
        defaultCategoryId={account.categoryId}
        parentSensitive={account.sensitive}
        onSave={handleSaveService}
      />

      <ServiceDetailModal
        service={detailService}
        sensitive={account.sensitive}
        onClose={() => setDetailServiceId(null)}
        onEdit={() => openEditService(detailServiceId)}
        onDelete={() => handleDeleteService(detailServiceId)}
      />
    </div>
  )
}

function Field({ label, value }) {
  return (
    <div className="min-w-0">
      <p className="text-[11.5px] text-inkFaint">{label}</p>
      <p className="truncate text-[13.5px] text-ink">{value || <span className="text-inkFaint">Sin definir</span>}</p>
    </div>
  )
}
