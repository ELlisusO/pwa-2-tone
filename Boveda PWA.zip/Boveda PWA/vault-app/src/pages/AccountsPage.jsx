import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useVaultStore } from '../state/useVaultStore.js'
import SectionHeader from '../components/common/SectionHeader.jsx'
import SearchBar from '../components/accounts/SearchBar.jsx'
import CategoryFilterBar from '../components/accounts/CategoryFilterBar.jsx'
import AccountCard from '../components/accounts/AccountCard.jsx'
import AccountForm from '../components/accounts/AccountForm.jsx'
import EmptyState from '../components/common/EmptyState.jsx'
import Button from '../components/common/Button.jsx'
import { IconPlusCircle, IconVault, IconStar, IconGrid, IconCloudBackup, IconSettings } from '../icons/index.jsx'

const QUICK = [
  { to: '/favoritas', label: 'Favoritas', icon: IconStar },
  { to: '/categorias', label: 'Categorías', icon: IconGrid },
  { to: '/respaldo', label: 'Copias', icon: IconCloudBackup },
  { to: '/configuracion', label: 'Configuración', icon: IconSettings },
]

export default function AccountsPage() {
  const accounts = useVaultStore((s) => s.accounts)
  const categories = useVaultStore((s) => s.categories)
  const tags = useVaultStore((s) => s.tags)

  const [search, setSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState(null)
  const [formOpen, setFormOpen] = useState(false)

  const categoryById = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return accounts
      .filter((a) => {
        if (categoryFilter && a.categoryId !== categoryFilter) return false
        if (!q) return true
        const tagNames = (a.tags || []).map((id) => tags.find((t) => t.id === id)?.name || '').join(' ')
        const serviceNames = (a.services || []).map((s) => s.name).join(' ')
        const categoryName = categoryById[a.categoryId]?.name || ''
        const haystack = [a.name, a.email, a.username, categoryName, serviceNames, a.description, tagNames]
          .join(' ')
          .toLowerCase()
        return haystack.includes(q)
      })
      .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'es'))
  }, [accounts, search, categoryFilter, tags, categoryById])

  return (
    <div className="space-y-5">
      <SectionHeader
        title="Cuentas"
        subtitle={`${accounts.length} cuenta${accounts.length === 1 ? '' : 's'} en tu bóveda`}
        action={
          <Button icon={IconPlusCircle} onClick={() => setFormOpen(true)}>
            Nueva
          </Button>
        }
      />

      <div className="chip-row -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 lg:hidden">
        {QUICK.map((q) => (
          <Link
            key={q.to}
            to={q.to}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-surface2 px-3 py-1.5 text-[12.5px] text-inkMuted hover:text-ink"
          >
            <q.icon size={13} />
            {q.label}
          </Link>
        ))}
      </div>

      <SearchBar value={search} onChange={setSearch} />
      <CategoryFilterBar categories={categories} value={categoryFilter} onChange={setCategoryFilter} />

      {filtered.length === 0 ? (
        accounts.length === 0 ? (
          <EmptyState
            icon={IconVault}
            title="Tu bóveda está vacía"
            description="Crea tu primera cuenta para empezar a organizar tus credenciales."
            action={
              <Button icon={IconPlusCircle} onClick={() => setFormOpen(true)}>
                Crear la primera cuenta
              </Button>
            }
          />
        ) : (
          <EmptyState icon={IconVault} title="Sin resultados" description="Prueba con otro término de búsqueda o cambia el filtro de categoría." compact />
        )
      ) : (
        <div className="space-y-2.5">
          {filtered.map((a) => (
            <AccountCard key={a.id} account={a} category={categoryById[a.categoryId]} />
          ))}
        </div>
      )}

      <AccountForm open={formOpen} onClose={() => setFormOpen(false)} defaultCategoryId={categoryFilter || categories[0]?.id} />
    </div>
  )
}
