import { useMemo } from 'react'
import { useVaultStore } from '../state/useVaultStore.js'
import PageHeader from '../components/common/PageHeader.jsx'
import AccountCard from '../components/accounts/AccountCard.jsx'
import EmptyState from '../components/common/EmptyState.jsx'
import { IconStar } from '../icons/index.jsx'

export default function FavoritesPage() {
  const accounts = useVaultStore((s) => s.accounts)
  const categories = useVaultStore((s) => s.categories)
  const categoryById = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories])
  const favorites = accounts.filter((a) => a.favorite)

  return (
    <div>
      <PageHeader title="Favoritas" subtitle={`${favorites.length} cuenta${favorites.length === 1 ? '' : 's'}`} backTo="/" />
      {favorites.length === 0 ? (
        <EmptyState icon={IconStar} title="Sin favoritas" description="Marca cuentas con la estrella para verlas aquí." />
      ) : (
        <div className="space-y-2.5">
          {favorites.map((a) => (
            <AccountCard key={a.id} account={a} category={categoryById[a.categoryId]} />
          ))}
        </div>
      )}
    </div>
  )
}
