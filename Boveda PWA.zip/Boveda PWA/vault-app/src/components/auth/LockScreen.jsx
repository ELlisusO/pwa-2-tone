import { useEffect, useState } from 'react'
import AuthLayout from './AuthLayout.jsx'
import PinPad from '../common/PinPad.jsx'
import { useAuthStore, PIN1_LENGTH } from '../../state/useAuthStore.js'
import { useUiStore } from '../../state/useUiStore.js'

export default function LockScreen() {
  const unlock = useAuthStore((s) => s.unlock)
  const wipeVault = useAuthStore((s) => s.wipeVault)
  const confirm = useUiStore((s) => s.confirm)
  const pushToast = useUiStore((s) => s.pushToast)
  const [error, setError] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')
  const [attemptKey, setAttemptKey] = useState(0)
  const [remainingMs, setRemainingMs] = useState(0)

  useEffect(() => {
    const id = setInterval(() => {
      setRemainingMs(useAuthStore.getState().lockoutRemainingMs())
    }, 500)
    return () => clearInterval(id)
  }, [])

  async function handleComplete(pin) {
    const res = await unlock(pin)
    if (!res.ok) {
      setError(true)
      setAttemptKey((k) => k + 1)
      setErrorMsg(res.error || (res.lockedMs ? 'Demasiados intentos.' : 'PIN incorrecto.'))
      setRemainingMs(res.lockedMs || 0)
    } else {
      setError(false)
    }
  }

  async function handleReset() {
    const ok = await confirm({
      title: 'Restablecer la bóveda',
      message:
        'Esto borrará permanentemente todas las cuentas, servicios, el perfil y el registro guardados en este dispositivo. No se puede deshacer y no existe forma de recuperar el PIN olvidado.',
      danger: true,
      confirmLabel: 'Borrar todo',
    })
    if (ok) {
      await wipeVault()
      pushToast('La bóveda se restableció en este dispositivo.', 'default')
    }
  }

  const seconds = Math.ceil(remainingMs / 1000)

  return (
    <AuthLayout eyebrow="Acceso privado" title="Desbloquea tu bóveda" subtitle="Introduce tu PIN de 6 dígitos">
      <PinPad
        length={PIN1_LENGTH}
        onComplete={handleComplete}
        error={error}
        disabled={remainingMs > 0}
        resetSignal={attemptKey}
      />
      <p className="mt-5 h-4 text-center text-[12.5px] text-brick-soft">
        {remainingMs > 0 ? `Bloqueado. Intenta de nuevo en ${seconds}s.` : errorMsg}
      </p>
      <button
        onClick={handleReset}
        className="mt-6 text-[12.5px] text-inkFaint underline decoration-dotted underline-offset-4 hover:text-brick-soft"
      >
        Olvidé mi PIN — restablecer bóveda
      </button>
    </AuthLayout>
  )
}
