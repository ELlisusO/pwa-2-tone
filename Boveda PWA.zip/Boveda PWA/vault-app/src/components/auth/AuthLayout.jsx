import { IconVault } from '../../icons/index.jsx'

export default function AuthLayout({ eyebrow, title, subtitle, children, footer }) {
  return (
    <div className="flex min-h-full flex-col items-center justify-center bg-bg bg-noise px-6 py-12">
      <div className="mb-8 flex flex-col items-center">
        <span className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-border bg-surface text-emerald shadow-vault">
          <IconVault size={26} />
        </span>
        {eyebrow && <p className="mb-1 text-[12px] font-medium uppercase tracking-[0.14em] text-emerald">{eyebrow}</p>}
        <h1 className="font-display text-[24px] font-medium text-ink">{title}</h1>
        {subtitle && <p className="mt-1.5 max-w-xs text-center text-[13.5px] text-inkFaint">{subtitle}</p>}
      </div>
      {children}
      {footer && <div className="mt-8">{footer}</div>}
    </div>
  )
}
