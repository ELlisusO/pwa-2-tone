import { useState } from 'react'
import Modal from '../common/Modal.jsx'
import PinPad from '../common/PinPad.jsx'
import { useAuthStore, PIN2_LENGTH } from '../../state/useAuthStore.js'
import { IconLock } from '../../icons/index.jsx'

export default function SecondPinGateModal() {
  const gateOpen = useAuthStore((s) => s.gateOpen)
  const gateReason = useAuthStore((s) => s.gateReason)
  const resolveGate = useAuthStore((s) => s.resolveGate)
  const verifyPin2 = useAuthStore((s) => s.verifyPin2)
  const [error, setError] = useState(false)
  const [lockedMsg, setLockedMsg] = useState('')
  const [attemptKey, setAttemptKey] = useState(0)

  async function handleComplete(pin) {
    const res = await verifyPin2(pin)
    if (res.ok) {
      setError(false)
      resolveGate(res.key)
    } else {
      setError(true)
      setAttemptKey((k) => k + 1)
      if (res.lockedMs) {
        setLockedMsg(`Demasiados intentos. Espera ${Math.ceil(res.lockedMs / 1000)} s.`)
        setTimeout(() => setLockedMsg(''), res.lockedMs)
      }
    }
  }

  return (
    <Modal
      open={gateOpen}
      onClose={() => resolveGate(null)}
      title="Protección adicional"
      subtitle={gateReason ? `Verifica tu PIN 2 para ${gateReason}` : 'Introduce tu PIN 2'}
      size="sm"
    >
      <div className="flex flex-col items-center py-3">
        <span className="mb-5 flex h-11 w-11 items-center justify-center rounded-full bg-emerald-soft text-emerald">
          <IconLock size={20} />
        </span>
        <PinPad
          length={PIN2_LENGTH}
          onComplete={handleComplete}
          error={error}
          disabled={!!lockedMsg}
          resetSignal={attemptKey}
        />
        <p className="mt-4 h-4 text-[12.5px] text-brick-soft">{lockedMsg}</p>
      </div>
    </Modal>
  )
}
