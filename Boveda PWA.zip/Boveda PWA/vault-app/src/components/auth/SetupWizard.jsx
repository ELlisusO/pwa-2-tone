import { useState } from 'react'
import AuthLayout from './AuthLayout.jsx'
import PinPad from '../common/PinPad.jsx'
import Button from '../common/Button.jsx'
import { useAuthStore, PIN1_LENGTH } from '../../state/useAuthStore.js'
import { IconShieldCheck, IconLayers, IconLock } from '../../icons/index.jsx'

const PERKS = [
  { icon: IconLayers, text: 'Cuentas, servicios asociados y sus relaciones, todo en un mismo lugar.' },
  { icon: IconLock, text: 'Cifrado en tu dispositivo con AES-256. Nada sale de aquí.' },
  { icon: IconShieldCheck, text: 'Una segunda capa de PIN para tus cuentas más delicadas.' },
]

export default function SetupWizard() {
  const createVault = useAuthStore((s) => s.createVault)
  const [step, setStep] = useState('welcome') // welcome | create | confirm
  const [firstPin, setFirstPin] = useState('')
  const [error, setError] = useState(false)
  const [attemptKey, setAttemptKey] = useState(0)

  if (step === 'welcome') {
    return (
      <AuthLayout eyebrow="Nueva bóveda" title="Bienvenido a tu bóveda" subtitle="Un espacio privado para organizar todas tus cuentas.">
        <div className="mb-8 w-full max-w-xs space-y-4">
          {PERKS.map((p, i) => (
            <div key={i} className="flex items-start gap-3">
              <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
                <p.icon size={15} />
              </span>
              <p className="text-[13.5px] leading-relaxed text-inkMuted">{p.text}</p>
            </div>
          ))}
        </div>
        <Button full size="lg" onClick={() => setStep('create')}>
          Crear mi PIN de acceso
        </Button>
      </AuthLayout>
    )
  }

  if (step === 'create') {
    return (
      <AuthLayout eyebrow="Paso 1 de 2" title="Crea tu PIN principal" subtitle={`Elige ${PIN1_LENGTH} dígitos. Lo usarás cada vez que abras la bóveda.`}>
        <PinPad
          length={PIN1_LENGTH}
          onComplete={(pin) => {
            setFirstPin(pin)
            setStep('confirm')
          }}
        />
      </AuthLayout>
    )
  }

  return (
    <AuthLayout eyebrow="Paso 2 de 2" title="Confirma tu PIN" subtitle="Vuelve a introducir el mismo PIN para confirmarlo.">
      <PinPad
        length={PIN1_LENGTH}
        error={error}
        resetSignal={attemptKey}
        onComplete={async (pin) => {
          if (pin !== firstPin) {
            setError(true)
            setAttemptKey((k) => k + 1)
            return
          }
          setError(false)
          await createVault(pin)
        }}
      />
      <p className="mt-5 h-4 text-center text-[12.5px] text-brick-soft">
        {error ? 'Los PIN no coinciden. Inténtalo de nuevo.' : ''}
      </p>
      <button
        onClick={() => {
          setStep('create')
          setError(false)
        }}
        className="mt-2 block w-full text-center text-[12.5px] text-inkFaint hover:text-ink"
      >
        Empezar de nuevo
      </button>
    </AuthLayout>
  )
}
