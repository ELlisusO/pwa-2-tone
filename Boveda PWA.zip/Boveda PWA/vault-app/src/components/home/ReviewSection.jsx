import { Link } from 'react-router-dom'
import Avatar from '../common/Avatar.jsx'
import { IconChevronRight, IconCheckCircle } from '../../icons/index.jsx'

export default function ReviewSection({ items }) {
  if (items.length === 0) {
    return (
      <div className="flex items-center gap-2.5 rounded-xl2 border border-border bg-surface px-4 py-3.5 text-[13px] text-inkFaint">
        <IconCheckCircle size={16} className="shrink-0 text-emerald" />
        Toda tu información está al día. Buen trabajo.
      </div>
    )
  }

  return (
    <div className="divide-y divide-border overflow-hidden rounded-xl2 border border-border bg-surface">
      {items.slice(0, 5).map((a) => (
        <Link key={a.id} to={`/cuentas/${a.id}`} className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-surfaceHover">
          <Avatar iconKey={a.icon} customImage={a.customImage} size="sm" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13.5px] text-ink">{a.name || 'Sin nombre'}</p>
            <p className="truncate text-[11.5px] text-amber">{a.issues.join(' · ')}</p>
          </div>
          <IconChevronRight size={15} className="shrink-0 text-inkFaint" />
        </Link>
      ))}
    </div>
  )
}
