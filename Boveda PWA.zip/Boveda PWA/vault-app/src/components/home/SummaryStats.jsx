const ITEMS = (s) => [
  { label: 'Cuentas', value: s.accounts },
  { label: 'Accesos', value: s.services },
  { label: 'Categorías', value: s.categories },
  { label: 'Favoritas', value: s.favorites },
]

export default function SummaryStats({ stats }) {
  const items = ITEMS(stats)
  return (
    <div className="vault-seam relative overflow-hidden rounded-xl3 border border-border bg-surface bg-noise p-5">
      <svg
        className="pointer-events-none absolute -right-10 -top-10 h-48 w-48 text-emerald/[0.07]"
        viewBox="0 0 200 200"
        fill="none"
      >
        <circle cx="100" cy="100" r="98" stroke="currentColor" strokeWidth="1" />
        <circle cx="100" cy="100" r="76" stroke="currentColor" strokeWidth="1" />
        <circle cx="100" cy="100" r="54" stroke="currentColor" strokeWidth="1" />
      </svg>
      <div className="relative grid grid-cols-2 gap-x-4 gap-y-5 sm:grid-cols-4">
        {items.map((it) => (
          <div key={it.label}>
            <p className="font-display text-[32px] font-medium leading-none tabular-nums text-ink">{it.value}</p>
            <p className="mt-1.5 text-[11.5px] uppercase tracking-wide text-inkFaint">{it.label}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
