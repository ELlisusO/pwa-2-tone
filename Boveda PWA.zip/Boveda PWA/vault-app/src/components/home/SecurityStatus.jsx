import { accountIssues } from '../../data/model.js'
import { IconShieldCheck } from '../../icons/index.jsx'

function Dot({ tone }) {
  const map = { emerald: 'bg-emerald', amber: 'bg-amber', brick: 'bg-brick' }
  return <span className={`h-2 w-2 shrink-0 rounded-full ${map[tone]}`} />
}

export default function SecurityStatus({ accounts, hasPin2 }) {
  const total = accounts.length
  const complete = accounts.filter((a) => accountIssues(a).length === 0).length
  const incomplete = total - complete
  const noRecovery = accounts.filter((a) => !a.recovery?.email && !a.recovery?.method && !a.recovery?.backupCode).length
  const protectedCount = accounts.filter((a) => a.sensitive).length

  const rows = [
    { tone: 'emerald', label: 'Información completa', value: complete },
    { tone: 'amber', label: 'Información incompleta', value: incomplete },
    { tone: 'brick', label: 'Sin información de recuperación', value: noRecovery },
  ]

  return (
    <div className="rounded-xl2 border border-border bg-surface p-4">
      <div className="space-y-2.5">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center gap-2.5 text-[13px]">
            <Dot tone={r.tone} />
            <span className="flex-1 text-inkMuted">{r.label}</span>
            <span className="font-mono tabular-nums text-ink">{r.value}</span>
          </div>
        ))}
      </div>
      <div className="mt-3.5 flex items-center gap-2.5 border-t border-border pt-3.5 text-[13px]">
        <IconShieldCheck size={14} className="shrink-0 text-emerald" />
        <span className="flex-1 text-inkMuted">
          Cuentas con PIN 2 {hasPin2 ? '' : '(sin configurar)'}
        </span>
        <span className="font-mono tabular-nums text-ink">{protectedCount}</span>
      </div>
    </div>
  )
}
