import { IconByKey } from '../../icons/index.jsx'
import EmptyState from '../common/EmptyState.jsx'
import { IconGrid } from '../../icons/index.jsx'

export default function DistributionChart({ categories, accounts }) {
  const rows = categories
    .map((c) => ({ ...c, count: accounts.filter((a) => a.categoryId === c.id).length }))
    .filter((c) => c.count > 0)
    .sort((a, b) => b.count - a.count)

  if (rows.length === 0) {
    return <EmptyState icon={IconGrid} title="Todavía sin datos" description="Cuando crees cuentas, aquí verás cómo se distribuyen por categoría." compact />
  }

  const max = rows[0].count

  return (
    <div className="space-y-3">
      {rows.map((c) => (
        <div key={c.id} className="flex items-center gap-3">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
            <IconByKey iconKey={c.icon} size={13.5} />
          </span>
          <span className="w-24 shrink-0 truncate text-[13px] text-inkMuted sm:w-28">{c.name}</span>
          <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-surface2">
            <span className="block h-full rounded-full bg-emerald" style={{ width: `${Math.max(6, (c.count / max) * 100)}%` }} />
          </span>
          <span className="w-5 shrink-0 text-right font-mono text-[12.5px] tabular-nums text-inkFaint">{c.count}</span>
        </div>
      ))}
    </div>
  )
}
