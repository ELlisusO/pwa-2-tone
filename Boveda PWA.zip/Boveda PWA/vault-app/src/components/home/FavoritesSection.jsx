import { Link } from 'react-router-dom'
import Avatar from '../common/Avatar.jsx'
import EmptyState from '../common/EmptyState.jsx'
import { IconStar } from '../../icons/index.jsx'

export default function FavoritesSection({ accounts }) {
  if (accounts.length === 0) {
    return (
      <EmptyState
        icon={IconStar}
        title="Aún no tienes favoritas"
        description="Marca una cuenta con la estrella para encontrarla aquí más rápido."
        compact
      />
    )
  }

  return (
    <div className="chip-row -mx-4 flex gap-3 overflow-x-auto px-4 pb-1">
      {accounts.map((a) => (
        <Link
          key={a.id}
          to={`/cuentas/${a.id}`}
          className="flex w-24 shrink-0 flex-col items-center gap-2 rounded-xl2 border border-border bg-surface p-3 text-center transition-colors hover:border-borderStrong hover:bg-surfaceHover"
        >
          <Avatar iconKey={a.icon} customImage={a.customImage} size="lg" />
          <span className="line-clamp-2 text-[12px] leading-tight text-ink">{a.name || 'Sin nombre'}</span>
        </Link>
      ))}
    </div>
  )
}
