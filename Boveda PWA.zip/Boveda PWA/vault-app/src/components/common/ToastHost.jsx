import { useUiStore } from '../../state/useUiStore.js'
import { IconCheckCircle, IconAlertTriangle, IconInfo, IconClose } from '../../icons/index.jsx'

const ICONS = { success: IconCheckCircle, danger: IconAlertTriangle, default: IconInfo }
const TONES = {
  success: 'border-emerald/40 text-emerald-strong',
  danger: 'border-brick/40 text-brick-soft',
  default: 'border-border text-inkMuted',
}

export default function ToastHost() {
  const toasts = useUiStore((s) => s.toasts)
  const dismissToast = useUiStore((s) => s.dismissToast)

  if (toasts.length === 0) return null

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-[calc(76px+env(safe-area-inset-bottom))] z-[60] flex flex-col items-center gap-2 px-4 sm:bottom-6">
      {toasts.map((t) => {
        const Icon = ICONS[t.variant] || ICONS.default
        return (
          <div
            key={t.id}
            className={`animate-rise-in pointer-events-auto flex w-full max-w-sm items-start gap-2.5 rounded-xl border bg-surface2/95 px-4 py-3 shadow-pop backdrop-blur ${TONES[t.variant] || TONES.default}`}
          >
            <Icon size={17} className="mt-0.5 shrink-0" />
            <p className="flex-1 text-[13.5px] leading-snug text-ink">{t.message}</p>
            <button onClick={() => dismissToast(t.id)} className="shrink-0 text-inkFaint hover:text-ink">
              <IconClose size={15} />
            </button>
          </div>
        )
      })}
    </div>
  )
}
