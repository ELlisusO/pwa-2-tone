import { useEffect, useRef, useState } from 'react'
import { IconChevronDown, IconCheck } from '../../icons/index.jsx'

export default function Select({ label, value, onChange, options, placeholder = 'Seleccionar…', hint, error }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    if (!open) return
    function onDocClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [open])

  const selected = options.find((o) => o.value === value)
  const SelectedIcon = selected?.icon

  return (
    <div className="relative" ref={ref}>
      {label && <span className="mb-1.5 block text-[12.5px] font-medium text-inkMuted">{label}</span>}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={[
          'flex w-full items-center gap-2 rounded-xl border bg-surface2 px-3.5 py-2.5 text-left text-[14.5px] transition-colors',
          error ? 'border-brick/60' : open ? 'border-emerald/70' : 'border-border hover:border-borderStrong',
        ].join(' ')}
      >
        {SelectedIcon && <SelectedIcon size={16} className="shrink-0 text-emerald" />}
        <span className={`flex-1 truncate ${selected ? 'text-ink' : 'text-inkFaint'}`}>
          {selected ? selected.label : placeholder}
        </span>
        <IconChevronDown size={16} className={`shrink-0 text-inkFaint transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {error ? (
        <span className="mt-1.5 block text-[12px] text-brick-soft">{error}</span>
      ) : hint ? (
        <span className="mt-1.5 block text-[12px] text-inkFaint">{hint}</span>
      ) : null}

      {open && (
        <div className="absolute z-30 mt-1.5 max-h-64 w-full animate-scale-in overflow-y-auto rounded-xl border border-border bg-surface2 p-1.5 shadow-pop">
          {options.map((opt) => {
            const OptIcon = opt.icon
            const isSelected = opt.value === value
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  onChange(opt.value)
                  setOpen(false)
                }}
                className={[
                  'flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[13.5px] transition-colors',
                  isSelected ? 'bg-emerald-soft text-ink' : 'text-inkMuted hover:bg-surfaceHover hover:text-ink',
                ].join(' ')}
              >
                {OptIcon && <OptIcon size={15} className={isSelected ? 'text-emerald' : 'text-inkFaint'} />}
                <span className="flex-1 truncate">{opt.label}</span>
                {isSelected && <IconCheck size={14} className="text-emerald" />}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
