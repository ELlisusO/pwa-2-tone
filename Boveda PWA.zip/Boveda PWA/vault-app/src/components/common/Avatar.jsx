import { IconByKey } from '../../icons/index.jsx'

const SIZES = {
  sm: { box: 32, icon: 15, radius: 'rounded-lg' },
  md: { box: 44, icon: 19, radius: 'rounded-xl' },
  lg: { box: 60, icon: 25, radius: 'rounded-2xl' },
  xl: { box: 92, icon: 34, radius: 'rounded-3xl' },
}

export default function Avatar({ iconKey = 'sparkle', customImage, size = 'md', shape = 'square', className = '' }) {
  const s = SIZES[size]
  const shapeClass = shape === 'circle' ? 'rounded-full' : s.radius
  return (
    <span
      className={`relative inline-flex shrink-0 items-center justify-center overflow-hidden border border-border/70 bg-emerald-soft text-emerald ${shapeClass} ${className}`}
      style={{ width: s.box, height: s.box }}
    >
      {customImage ? (
        <img src={customImage} alt="" className="h-full w-full object-cover" />
      ) : (
        <IconByKey iconKey={iconKey} size={s.icon} strokeWidth={1.6} />
      )}
    </span>
  )
}
