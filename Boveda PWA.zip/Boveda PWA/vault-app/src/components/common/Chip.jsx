export default function Chip({ icon: Icon, label, active = false, onClick, onRemove, tone = 'default', size = 'md' }) {
  const isButton = !!onClick
  const Comp = isButton ? 'button' : 'span'
  const pad = size === 'sm' ? 'px-2.5 py-1 text-[12px]' : 'px-3 py-1.5 text-[13px]'
  return (
    <Comp
      onClick={onClick}
      type={isButton ? 'button' : undefined}
      className={[
        'inline-flex shrink-0 items-center gap-1.5 rounded-full border transition-colors',
        pad,
        active
          ? 'border-emerald/60 bg-emerald-soft text-ink'
          : tone === 'brick'
          ? 'border-brick/40 bg-brick/10 text-brick-soft'
          : 'border-border bg-surface2 text-inkMuted hover:border-borderStrong hover:text-ink',
      ].join(' ')}
    >
      {Icon && <Icon size={13} className={active ? 'text-emerald' : ''} />}
      <span className="whitespace-nowrap">{label}</span>
      {onRemove && (
        <span
          onClick={(e) => {
            e.stopPropagation()
            onRemove()
          }}
          className="ml-0.5 -mr-0.5 rounded-full p-0.5 hover:bg-surfaceHover"
        >
          ×
        </span>
      )}
    </Comp>
  )
}
