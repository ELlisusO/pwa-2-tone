export default function Switch({ checked, onChange, label, description, disabled = false, tone = 'emerald' }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-4 py-0.5 text-left disabled:opacity-50"
    >
      {(label || description) && (
        <span>
          {label && <span className="block text-[14px] text-ink">{label}</span>}
          {description && <span className="mt-0.5 block text-[12.5px] text-inkFaint">{description}</span>}
        </span>
      )}
      <span
        className={[
          'relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors duration-200',
          checked ? (tone === 'brick' ? 'bg-brick/70 border-brick/70' : 'bg-emerald border-emerald') : 'bg-surface2 border-border',
        ].join(' ')}
      >
        <span
          className={[
            'inline-block transform rounded-full bg-ink shadow transition-transform duration-200',
            checked ? 'translate-x-[22px]' : 'translate-x-[3px]',
          ].join(' ')}
          style={{ height: 18, width: 18 }}
        />
      </span>
    </button>
  )
}
