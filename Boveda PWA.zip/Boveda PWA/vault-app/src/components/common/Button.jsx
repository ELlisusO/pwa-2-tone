const VARIANTS = {
  primary: 'bg-emerald text-bg hover:bg-emerald-strong active:bg-emerald-deep shadow-vault',
  secondary: 'bg-surface2 text-ink border border-border hover:border-borderStrong hover:bg-surfaceHover',
  ghost: 'bg-transparent text-inkMuted hover:text-ink hover:bg-surfaceHover',
  danger: 'bg-brick/15 text-brick-soft border border-brick/40 hover:bg-brick/25',
  dangerSolid: 'bg-brick text-bg hover:brightness-110',
}

const SIZES = {
  sm: 'text-[13px] px-3 py-1.5 gap-1.5',
  md: 'text-[14px] px-4 py-2.5 gap-2',
  lg: 'text-[15px] px-5 py-3.5 gap-2.5',
}

export default function Button({
  variant = 'primary',
  size = 'md',
  icon: Icon,
  iconRight: IconRight,
  loading = false,
  disabled = false,
  full = false,
  className = '',
  children,
  ...rest
}) {
  return (
    <button
      disabled={disabled || loading}
      className={[
        'inline-flex items-center justify-center rounded-xl font-medium transition-all duration-150',
        'disabled:opacity-45 disabled:cursor-not-allowed active:scale-[0.98]',
        VARIANTS[variant],
        SIZES[size],
        full ? 'w-full' : '',
        className,
      ].join(' ')}
      {...rest}
    >
      {loading ? (
        <span className="h-3.5 w-3.5 rounded-full border-2 border-current border-t-transparent animate-spin" />
      ) : (
        Icon && <Icon size={16} />
      )}
      {children && <span>{children}</span>}
      {!loading && IconRight && <IconRight size={16} />}
    </button>
  )
}
