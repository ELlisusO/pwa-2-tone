export default function EmptyState({ icon: Icon, title, description, action, compact = false }) {
  return (
    <div
      className={[
        'flex flex-col items-center justify-center rounded-xl2 border border-dashed border-border text-center',
        compact ? 'px-5 py-8' : 'px-6 py-14',
      ].join(' ')}
    >
      {Icon && (
        <span className="mb-3.5 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-soft text-emerald">
          <Icon size={22} />
        </span>
      )}
      <p className="text-[15px] font-medium text-ink">{title}</p>
      {description && <p className="mx-auto mt-1.5 max-w-xs text-[13px] leading-relaxed text-inkFaint">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}
