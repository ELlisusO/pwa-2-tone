import { useState } from 'react'
import Input from './Input.jsx'
import { IconEye, IconEyeOff } from '../../icons/index.jsx'

export default function PasswordInput({ label, value, onChange, placeholder, hint, containerClassName }) {
  const [show, setShow] = useState(false)
  return (
    <Input
      label={label}
      type={show ? 'text' : 'password'}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      hint={hint}
      containerClassName={containerClassName}
      autoComplete="new-password"
      className="font-mono"
      trailing={
        <button
          type="button"
          onClick={() => setShow((s) => !s)}
          className="shrink-0 text-inkFaint transition-colors hover:text-ink"
        >
          {show ? <IconEyeOff size={16} /> : <IconEye size={16} />}
        </button>
      }
    />
  )
}
