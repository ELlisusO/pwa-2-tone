import { useEffect } from 'react'
import { IconClose } from '../../icons/index.jsx'

const WIDTHS = { sm: 'sm:max-w-sm', md: 'sm:max-w-md', lg: 'sm:max-w-lg', xl: 'sm:max-w-2xl' }

export default function Modal({ open, onClose, title, subtitle, children, size = 'md', hideClose = false, footer }) {
  useEffect(() => {
    if (!open) return
    function onKey(e) {
      if (e.key === 'Escape' && !hideClose) onClose?.()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onClose, hideClose])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div
        className="absolute inset-0 animate-fade-in bg-bg/70 backdrop-blur-sm"
        onClick={() => !hideClose && onClose?.()}
      />
      <div
        className={`vault-seam relative flex max-h-[88vh] w-full flex-col overflow-hidden rounded-t-xl3 border border-border bg-surface shadow-pop animate-sheet-in sm:mb-0 sm:rounded-xl3 sm:animate-scale-in ${WIDTHS[size]}`}
      >
        <div className="mx-auto mt-2.5 h-1 w-9 shrink-0 rounded-full bg-borderStrong sm:hidden" />
        {(title || !hideClose) && (
          <div className="flex shrink-0 items-start justify-between gap-3 px-5 pb-3 pt-4">
            <div>
              {title && <h3 className="font-display text-[18px] font-medium text-ink">{title}</h3>}
              {subtitle && <p className="mt-0.5 text-[13px] text-inkFaint">{subtitle}</p>}
            </div>
            {!hideClose && (
              <button
                onClick={onClose}
                className="rounded-lg p-1.5 text-inkFaint transition-colors hover:bg-surfaceHover hover:text-ink"
              >
                <IconClose size={18} />
              </button>
            )}
          </div>
        )}
        <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-2">{children}</div>
        {footer && <div className="shrink-0 border-t border-border px-5 py-4">{footer}</div>}
        <div className="h-[env(safe-area-inset-bottom)] shrink-0 sm:hidden" />
      </div>
    </div>
  )
}
