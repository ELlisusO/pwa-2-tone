import { useEffect, useState } from 'react'
import Modal from './Modal.jsx'
import PinPad from './PinPad.jsx'

/**
 * steps: [{ key, title, subtitle, matchKey? }]
 * onSubmit(values) -> { ok: boolean, error?: string }
 */
export default function PinFlowModal({ open, onClose, steps, onSubmit, length = 6 }) {
  const [stepIndex, setStepIndex] = useState(0)
  const [values, setValues] = useState({})
  const [error, setError] = useState('')
  const [shake, setShake] = useState(false)
  const [attemptKey, setAttemptKey] = useState(0)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (open) {
      setStepIndex(0)
      setValues({})
      setError('')
      setShake(false)
    }
  }, [open])

  const step = steps[stepIndex]

  function fail(message) {
    setError(message)
    setShake(true)
    setAttemptKey((k) => k + 1)
  }

  async function handleComplete(pin) {
    setShake(false)
    if (step.matchKey && pin !== values[step.matchKey]) {
      fail('Los PIN no coinciden. Inténtalo de nuevo.')
      setStepIndex(0)
      setValues({})
      return
    }
    const nextValues = { ...values, [step.key]: pin }
    setValues(nextValues)
    setError('')

    if (stepIndex < steps.length - 1) {
      setStepIndex((i) => i + 1)
      return
    }

    setSubmitting(true)
    const res = await onSubmit(nextValues)
    setSubmitting(false)
    if (res?.ok) {
      onClose()
    } else {
      fail(res?.error || 'No se pudo completar la operación.')
      setStepIndex(0)
      setValues({})
    }
  }

  if (!step) return null

  return (
    <Modal open={open} onClose={onClose} title={step.title} subtitle={step.subtitle} size="sm">
      <div className="flex flex-col items-center py-3">
        <PinPad length={length} onComplete={handleComplete} error={shake} disabled={submitting} resetSignal={attemptKey} />
        <p className="mt-4 h-4 text-center text-[12.5px] text-brick-soft">{error}</p>
      </div>
    </Modal>
  )
}
