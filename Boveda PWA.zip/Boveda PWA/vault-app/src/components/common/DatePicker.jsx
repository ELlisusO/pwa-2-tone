import { useEffect, useRef, useState } from 'react'
import {
  getMonthMatrix,
  monthLabel,
  toISODate,
  parseISODate,
  formatDate,
  todayISO,
  MONTHS_ES,
  WEEKDAYS_SHORT_ES,
} from '../../lib/dateUtils.js'
import { IconCalendar, IconChevronLeft, IconChevronRight } from '../../icons/index.jsx'

const MIN_YEAR = 1930
const MAX_YEAR = new Date().getFullYear() + 6

export default function DatePicker({ label, value, onChange, placeholder = 'Seleccionar fecha', hint, error }) {
  const [open, setOpen] = useState(false)
  const [panel, setPanel] = useState('days')
  const ref = useRef(null)

  const base = parseISODate(value) || new Date()
  const [viewYear, setViewYear] = useState(base.getFullYear())
  const [viewMonth, setViewMonth] = useState(base.getMonth())
  const [decadeStart, setDecadeStart] = useState(Math.floor(base.getFullYear() / 12) * 12)

  useEffect(() => {
    if (!open) return
    function onDocClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [open])

  function openPicker() {
    const b = parseISODate(value) || new Date()
    setViewYear(b.getFullYear())
    setViewMonth(b.getMonth())
    setDecadeStart(Math.floor(b.getFullYear() / 12) * 12)
    setPanel('days')
    setOpen(true)
  }

  function pick(iso) {
    onChange(iso)
    setOpen(false)
  }

  const weeks = getMonthMatrix(viewYear, viewMonth)
  const today = todayISO()

  return (
    <div className="relative" ref={ref}>
      {label && <span className="mb-1.5 block text-[12.5px] font-medium text-inkMuted">{label}</span>}
      <button
        type="button"
        onClick={openPicker}
        className={[
          'flex w-full items-center gap-2.5 rounded-xl border bg-surface2 px-3.5 py-2.5 text-left text-[14.5px] transition-colors',
          error ? 'border-brick/60' : open ? 'border-emerald/70' : 'border-border hover:border-borderStrong',
        ].join(' ')}
      >
        <IconCalendar size={16} className="shrink-0 text-inkFaint" />
        <span className={`flex-1 font-mono tabular-nums ${value ? 'text-ink' : 'text-inkFaint'}`}>
          {value ? formatDate(value) : placeholder}
        </span>
        {value && (
          <span
            role="button"
            tabIndex={-1}
            onClick={(e) => {
              e.stopPropagation()
              onChange('')
            }}
            className="rounded-md px-1.5 py-0.5 text-[11px] text-inkFaint hover:bg-surfaceHover hover:text-ink"
          >
            Limpiar
          </span>
        )}
      </button>
      {error ? (
        <span className="mt-1.5 block text-[12px] text-brick-soft">{error}</span>
      ) : hint ? (
        <span className="mt-1.5 block text-[12px] text-inkFaint">{hint}</span>
      ) : null}

      {open && (
        <div className="absolute z-30 mt-1.5 w-72 animate-scale-in rounded-xl2 border border-border bg-surface2 p-3.5 shadow-pop">
          {panel === 'years' && (
            <div>
              <div className="mb-2.5 flex items-center justify-between">
                <button
                  onClick={() => setDecadeStart((d) => Math.max(MIN_YEAR, d - 12))}
                  className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink"
                >
                  <IconChevronLeft size={16} />
                </button>
                <span className="text-[13px] font-medium text-ink">
                  {decadeStart} – {decadeStart + 11}
                </span>
                <button
                  onClick={() => setDecadeStart((d) => Math.min(MAX_YEAR - 11, d + 12))}
                  className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink"
                >
                  <IconChevronRight size={16} />
                </button>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {Array.from({ length: 12 }).map((_, i) => {
                  const y = decadeStart + i
                  if (y < MIN_YEAR || y > MAX_YEAR) return <span key={i} />
                  return (
                    <button
                      key={y}
                      onClick={() => {
                        setViewYear(y)
                        setPanel('months')
                      }}
                      className={`rounded-lg py-2 text-[13px] font-mono tabular-nums transition-colors ${
                        y === viewYear ? 'bg-emerald text-bg' : 'text-inkMuted hover:bg-surfaceHover hover:text-ink'
                      }`}
                    >
                      {y}
                    </button>
                  )
                })}
              </div>
            </div>
          )}

          {panel === 'months' && (
            <div>
              <div className="mb-2.5 flex items-center justify-between">
                <button
                  onClick={() => setViewYear((y) => y - 1)}
                  className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink"
                >
                  <IconChevronLeft size={16} />
                </button>
                <button
                  onClick={() => setPanel('years')}
                  className="rounded-lg px-2 py-1 font-mono text-[13px] font-medium text-ink hover:bg-surfaceHover"
                >
                  {viewYear}
                </button>
                <button
                  onClick={() => setViewYear((y) => y + 1)}
                  className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink"
                >
                  <IconChevronRight size={16} />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {MONTHS_ES.map((m, i) => (
                  <button
                    key={m}
                    onClick={() => {
                      setViewMonth(i)
                      setPanel('days')
                    }}
                    className={`rounded-lg py-2 text-[12.5px] capitalize transition-colors ${
                      i === viewMonth ? 'bg-emerald text-bg' : 'text-inkMuted hover:bg-surfaceHover hover:text-ink'
                    }`}
                  >
                    {m.slice(0, 3)}
                  </button>
                ))}
              </div>
            </div>
          )}

          {panel === 'days' && (
            <div>
              <div className="mb-2.5 flex items-center justify-between">
                <button
                  onClick={() => {
                    let y = viewYear
                    let m = viewMonth - 1
                    if (m < 0) {
                      m = 11
                      y -= 1
                    }
                    setViewYear(y)
                    setViewMonth(m)
                  }}
                  className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink"
                >
                  <IconChevronLeft size={16} />
                </button>
                <button
                  onClick={() => setPanel('months')}
                  className="rounded-lg px-2 py-1 text-[13px] font-medium capitalize text-ink hover:bg-surfaceHover"
                >
                  {monthLabel(viewYear, viewMonth)}
                </button>
                <button
                  onClick={() => {
                    let y = viewYear
                    let m = viewMonth + 1
                    if (m > 11) {
                      m = 0
                      y += 1
                    }
                    setViewYear(y)
                    setViewMonth(m)
                  }}
                  className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink"
                >
                  <IconChevronRight size={16} />
                </button>
              </div>
              <div className="mb-1 grid grid-cols-7 text-center text-[10.5px] uppercase tracking-wide text-inkFaint">
                {WEEKDAYS_SHORT_ES.map((d) => (
                  <span key={d}>{d}</span>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-y-1 text-center">
                {weeks.flat().map((day) => {
                  const isSelected = value === day.iso
                  const isToday = today === day.iso
                  return (
                    <button
                      key={day.iso}
                      onClick={() => pick(day.iso)}
                      className={[
                        'mx-auto flex h-8 w-8 items-center justify-center rounded-lg text-[12.5px] font-mono transition-colors',
                        !day.inMonth ? 'text-inkFaint/40' : 'text-inkMuted hover:bg-surfaceHover hover:text-ink',
                        isSelected ? '!bg-emerald !text-bg' : '',
                        isToday && !isSelected ? 'ring-1 ring-inset ring-emerald/50' : '',
                      ].join(' ')}
                    >
                      {day.date.getDate()}
                    </button>
                  )
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
