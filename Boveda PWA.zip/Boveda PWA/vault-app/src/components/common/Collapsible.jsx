import { useState } from 'react'
import { IconChevronDown } from '../../icons/index.jsx'

export default function Collapsible({ title, icon: Icon, defaultOpen = true, badge, children }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="overflow-hidden rounded-xl2 border border-border bg-surface">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full items-center gap-2.5 px-4 py-3.5 text-left">
        {Icon && <Icon size={15} className="shrink-0 text-emerald" />}
        <span className="flex-1 text-[13.5px] font-medium text-ink">{title}</span>
        {badge}
        <IconChevronDown size={16} className={`shrink-0 text-inkFaint transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="animate-fade-in border-t border-border px-4 py-4">{children}</div>}
    </div>
  )
}
