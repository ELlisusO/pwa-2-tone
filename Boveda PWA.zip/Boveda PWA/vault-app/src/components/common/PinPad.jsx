import { useEffect, useState } from 'react'
import { IconChevronLeft } from '../../icons/index.jsx'

export default function PinPad({ length = 6, onComplete, error = false, disabled = false, resetSignal }) {
  const [digits, setDigits] = useState([])

  useEffect(() => {
    setDigits([])
  }, [resetSignal])

  useEffect(() => {
    if (error) {
      const t = setTimeout(() => setDigits([]), 420)
      return () => clearTimeout(t)
    }
  }, [error])

  // Efecto (no el actualizador de estado) es quien dispara onComplete, con su propia
  // limpieza: así, si React vuelve a invocar el ciclo (p. ej. en modo estricto), el
  // primer timeout se cancela y sólo se llama a onComplete una vez.
  useEffect(() => {
    if (disabled || digits.length !== length) return
    const pin = digits.join('')
    const t = setTimeout(() => onComplete(pin), 60)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [digits, length, disabled])

  function press(d) {
    if (disabled) return
    setDigits((cur) => (cur.length >= length ? cur : [...cur, d]))
  }

  function backspace() {
    if (disabled) return
    setDigits((cur) => cur.slice(0, -1))
  }

  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'back']

  return (
    <div className="flex flex-col items-center">
      <div className={`mb-8 flex gap-3.5 ${error ? 'animate-shake' : ''}`}>
        {Array.from({ length }).map((_, i) => (
          <span
            key={i}
            className={[
              'h-3 w-3 rounded-full border transition-all duration-150',
              i < digits.length
                ? error
                  ? 'border-brick bg-brick'
                  : 'border-emerald bg-emerald scale-110'
                : 'border-borderStrong bg-transparent',
            ].join(' ')}
          />
        ))}
      </div>

      <div className="grid grid-cols-3 gap-3.5">
        {keys.map((k, i) => {
          if (k === '') return <span key={i} />
          if (k === 'back') {
            return (
              <button
                key={i}
                type="button"
                onClick={backspace}
                disabled={disabled}
                className="flex h-16 w-16 items-center justify-center rounded-2xl text-inkFaint transition-colors hover:bg-surfaceHover active:scale-95 disabled:opacity-40"
              >
                <IconChevronLeft size={22} />
              </button>
            )
          }
          return (
            <button
              key={i}
              type="button"
              onClick={() => press(k)}
              disabled={disabled}
              className="flex h-16 w-16 items-center justify-center rounded-2xl border border-border bg-surface2 font-mono text-[21px] text-ink transition-colors hover:border-borderStrong hover:bg-surfaceHover active:scale-95 disabled:opacity-40"
            >
              {k}
            </button>
          )
        })}
      </div>
    </div>
  )
}
