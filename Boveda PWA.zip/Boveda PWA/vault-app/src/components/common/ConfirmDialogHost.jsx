import { useUiStore } from '../../state/useUiStore.js'
import Modal from './Modal.jsx'
import Button from './Button.jsx'

export default function ConfirmDialogHost() {
  const confirmState = useUiStore((s) => s.confirmState)
  const resolveConfirm = useUiStore((s) => s.resolveConfirm)

  return (
    <Modal open={!!confirmState} onClose={() => resolveConfirm(false)} title={confirmState?.title} size="sm">
      <p className="pb-1 text-[14px] leading-relaxed text-inkMuted">{confirmState?.message}</p>
      <div className="mt-5 flex gap-2.5 pb-2">
        <Button variant="secondary" full onClick={() => resolveConfirm(false)}>
          {confirmState?.cancelLabel || 'Cancelar'}
        </Button>
        <Button
          variant={confirmState?.danger ? 'dangerSolid' : 'primary'}
          full
          onClick={() => resolveConfirm(true)}
        >
          {confirmState?.confirmLabel || 'Confirmar'}
        </Button>
      </div>
    </Modal>
  )
}
