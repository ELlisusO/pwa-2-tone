import { useNavigate } from 'react-router-dom'
import { IconArrowLeft } from '../../icons/index.jsx'

export default function PageHeader({ title, subtitle, action, backTo }) {
  const navigate = useNavigate()
  return (
    <div className="mb-5 flex items-center gap-3">
      <button
        onClick={() => (backTo ? navigate(backTo) : navigate(-1))}
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border bg-surface2 text-inkMuted transition-colors hover:text-ink"
      >
        <IconArrowLeft size={17} />
      </button>
      <div className="min-w-0 flex-1">
        <h1 className="truncate font-display text-[20px] font-medium text-ink">{title}</h1>
        {subtitle && <p className="truncate text-[12.5px] text-inkFaint">{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}
