export default function SectionHeader({ title, subtitle, action, className = '' }) {
  return (
    <div className={`mb-3 flex items-end justify-between gap-3 ${className}`}>
      <div>
        <h2 className="font-display text-[19px] font-medium tracking-tight text-ink">{title}</h2>
        {subtitle && <p className="mt-0.5 text-[13px] text-inkFaint">{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}
