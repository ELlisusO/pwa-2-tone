import { useState } from 'react'
import Chip from './Chip.jsx'
import { IconPlus, IconTag } from '../../icons/index.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'

export default function TagPicker({ selectedIds, onChange }) {
  const tags = useVaultStore((s) => s.tags)
  const addTag = useVaultStore((s) => s.addTag)
  const [text, setText] = useState('')

  const selected = selectedIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean)
  const suggestions = text.trim()
    ? tags.filter((t) => !selectedIds.includes(t.id) && t.name.toLowerCase().includes(text.trim().toLowerCase())).slice(0, 5)
    : []

  async function commit() {
    const clean = text.trim()
    if (!clean) return
    const tag = await addTag(clean)
    if (tag && !selectedIds.includes(tag.id)) onChange([...selectedIds, tag.id])
    setText('')
  }

  return (
    <div>
      {selected.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-1.5">
          {selected.map((t) => (
            <Chip
              key={t.id}
              icon={IconTag}
              label={t.name}
              active
              size="sm"
              onRemove={() => onChange(selectedIds.filter((id) => id !== t.id))}
            />
          ))}
        </div>
      )}
      <div className="relative">
        <div className="flex items-center gap-2 rounded-xl border border-border bg-surface2 px-3.5 py-2.5">
          <IconTag size={14} className="shrink-0 text-inkFaint" />
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault()
                commit()
              }
            }}
            placeholder="Añadir etiqueta y pulsar Enter"
            className="min-w-0 flex-1 bg-transparent text-[13.5px] text-ink placeholder:text-inkFaint focus:outline-none"
          />
          {text.trim() && (
            <button type="button" onClick={commit} className="shrink-0 text-inkFaint hover:text-emerald">
              <IconPlus size={15} />
            </button>
          )}
        </div>
        {suggestions.length > 0 && (
          <div className="absolute z-20 mt-1 w-full rounded-lg border border-border bg-surface2 p-1 shadow-pop">
            {suggestions.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => {
                  onChange([...selectedIds, s.id])
                  setText('')
                }}
                className="block w-full rounded-md px-2.5 py-1.5 text-left text-[13px] text-inkMuted hover:bg-surfaceHover hover:text-ink"
              >
                {s.name}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
