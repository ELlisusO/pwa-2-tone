export default function Input({
  label,
  hint,
  error,
  icon: Icon,
  trailing,
  className = '',
  containerClassName = '',
  required = false,
  ...rest
}) {
  return (
    <label className={`block ${containerClassName}`}>
      {label && (
        <span className="mb-1.5 flex items-baseline gap-1 text-[12.5px] font-medium text-inkMuted">
          {label}
          {required && <span className="text-emerald">·</span>}
        </span>
      )}
      <span
        className={[
          'flex items-center gap-2 rounded-xl border bg-surface2 px-3.5 transition-colors',
          error ? 'border-brick/60' : 'border-border focus-within:border-emerald/70',
        ].join(' ')}
      >
        {Icon && <Icon size={16} className="shrink-0 text-inkFaint" />}
        <input
          className={`min-w-0 flex-1 bg-transparent py-2.5 text-[14.5px] text-ink placeholder:text-inkFaint focus:outline-none ${className}`}
          {...rest}
        />
        {trailing}
      </span>
      {error ? (
        <span className="mt-1.5 block text-[12px] text-brick-soft">{error}</span>
      ) : hint ? (
        <span className="mt-1.5 block text-[12px] text-inkFaint">{hint}</span>
      ) : null}
    </label>
  )
}
