export default function TextArea({ label, hint, error, rows = 3, containerClassName = '', className = '', ...rest }) {
  return (
    <label className={`block ${containerClassName}`}>
      {label && <span className="mb-1.5 block text-[12.5px] font-medium text-inkMuted">{label}</span>}
      <span
        className={[
          'block rounded-xl border bg-surface2 px-3.5 py-2.5 transition-colors',
          error ? 'border-brick/60' : 'border-border focus-within:border-emerald/70',
        ].join(' ')}
      >
        <textarea
          rows={rows}
          className={`w-full resize-none bg-transparent text-[14.5px] text-ink placeholder:text-inkFaint focus:outline-none ${className}`}
          {...rest}
        />
      </span>
      {error ? (
        <span className="mt-1.5 block text-[12px] text-brick-soft">{error}</span>
      ) : hint ? (
        <span className="mt-1.5 block text-[12px] text-inkFaint">{hint}</span>
      ) : null}
    </label>
  )
}
