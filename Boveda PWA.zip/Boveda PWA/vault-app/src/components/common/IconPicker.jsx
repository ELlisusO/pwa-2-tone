import { useRef } from 'react'
import Modal from './Modal.jsx'
import Button from './Button.jsx'
import { ICON_LIBRARY } from '../../icons/index.jsx'
import { IconCamera } from '../../icons/index.jsx'

export default function IconPicker({ open, onClose, value, customImage, onChange }) {
  const fileRef = useRef(null)

  function handleFile(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      onChange({ icon: value, customImage: reader.result })
      onClose()
    }
    reader.readAsDataURL(file)
    e.target.value = ''
  }

  return (
    <Modal open={open} onClose={onClose} title="Elegir icono">
      <div className="mb-4 space-y-2">
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
        <Button variant="secondary" icon={IconCamera} full onClick={() => fileRef.current?.click()}>
          Subir imagen personalizada
        </Button>
        {customImage && (
          <button
            onClick={() => {
              onChange({ icon: value || 'sparkle', customImage: null })
            }}
            className="w-full text-center text-[12.5px] text-inkFaint hover:text-brick-soft"
          >
            Quitar imagen personalizada
          </button>
        )}
      </div>
      <div className="space-y-4 pb-3">
        {ICON_LIBRARY.map((group) => (
          <div key={group.group}>
            <p className="mb-1.5 text-[11px] font-medium uppercase tracking-wide text-inkFaint">{group.group}</p>
            <div className="grid grid-cols-6 gap-2">
              {group.items.map(({ key, label, Icon }) => {
                const selected = !customImage && value === key
                return (
                  <button
                    key={key}
                    title={label}
                    type="button"
                    onClick={() => {
                      onChange({ icon: key, customImage: null })
                      onClose()
                    }}
                    className={`flex aspect-square items-center justify-center rounded-xl border transition-colors ${
                      selected
                        ? 'border-emerald bg-emerald-soft text-emerald'
                        : 'border-border text-inkMuted hover:bg-surfaceHover hover:text-ink'
                    }`}
                  >
                    <Icon size={18} />
                  </button>
                )
              })}
            </div>
          </div>
        ))}
      </div>
    </Modal>
  )
}
