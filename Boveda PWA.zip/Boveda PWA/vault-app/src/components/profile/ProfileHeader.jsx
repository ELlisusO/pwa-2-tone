import { useEffect, useRef, useState } from 'react'
import Modal from '../common/Modal.jsx'
import Input from '../common/Input.jsx'
import TextArea from '../common/TextArea.jsx'
import Button from '../common/Button.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { IconCamera, IconEdit, IconPlus, IconTrash, IconGlobe, IconPhone } from '../../icons/index.jsx'

function EditProfileModal({ open, onClose, profile }) {
  const updateProfileBasic = useVaultStore((s) => s.updateProfileBasic)
  const [form, setForm] = useState(profile)
  const fileRef = useRef(null)

  useEffect(() => {
    if (open) setForm(profile)
  }, [open, profile])

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }
  function setPhone(i, value) {
    setForm((f) => ({ ...f, phones: f.phones.map((p, idx) => (idx === i ? value : p)) }))
  }
  function addPhone() {
    setForm((f) => ({ ...f, phones: [...f.phones, ''] }))
  }
  function removePhone(i) {
    setForm((f) => ({ ...f, phones: f.phones.filter((_, idx) => idx !== i) }))
  }

  function handleFile(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => set('photo', reader.result)
    reader.readAsDataURL(file)
    e.target.value = ''
  }

  async function handleSave(e) {
    e.preventDefault()
    await updateProfileBasic(form)
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Editar perfil"
      size="lg"
      footer={
        <div className="flex gap-2.5">
          <Button variant="secondary" full onClick={onClose}>
            Cancelar
          </Button>
          <Button full onClick={handleSave}>
            Guardar
          </Button>
        </div>
      }
    >
      <form onSubmit={handleSave} className="space-y-4 pb-2">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="relative flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-full border border-border bg-surface2 text-inkFaint"
          >
            {form.photo ? <img src={form.photo} alt="" className="h-full w-full object-cover" /> : <IconCamera size={22} />}
          </button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" onClick={() => fileRef.current?.click()}>
              Cambiar foto
            </Button>
            {form.photo && (
              <Button variant="ghost" size="sm" onClick={() => set('photo', null)}>
                Eliminar
              </Button>
            )}
          </div>
        </div>

        <Input label="Nombre completo" value={form.fullName} onChange={(e) => set('fullName', e.target.value)} />
        <TextArea label="Descripción" rows={2} value={form.headline} onChange={(e) => set('headline', e.target.value)} />

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input label="Ciudad" value={form.city} onChange={(e) => set('city', e.target.value)} />
          <Input label="País" value={form.country} onChange={(e) => set('country', e.target.value)} />
          <Input label="Correo" type="email" value={form.email} onChange={(e) => set('email', e.target.value)} />
          <Input label="Sitio web / red profesional" value={form.website} onChange={(e) => set('website', e.target.value)} />
        </div>

        <div>
          <span className="mb-1.5 block text-[12.5px] font-medium text-inkMuted">Números de contacto</span>
          <div className="space-y-2">
            {form.phones.map((p, i) => (
              <div key={i} className="flex items-center gap-2">
                <Input containerClassName="flex-1" value={p} onChange={(e) => setPhone(i, e.target.value)} />
                <button type="button" onClick={() => removePhone(i)} className="rounded-lg p-2.5 text-inkFaint hover:bg-surfaceHover hover:text-brick-soft">
                  <IconTrash size={15} />
                </button>
              </div>
            ))}
            <Button type="button" variant="secondary" size="sm" icon={IconPlus} onClick={addPhone}>
              Añadir número
            </Button>
          </div>
        </div>
      </form>
    </Modal>
  )
}

export default function ProfileHeader() {
  const profile = useVaultStore((s) => s.profile)
  const [open, setOpen] = useState(false)

  return (
    <div className="vault-seam relative overflow-hidden rounded-xl3 border border-border bg-surface bg-noise p-5">
      <div className="flex items-start gap-4">
        <span className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-full border border-border bg-emerald-soft text-emerald">
          {profile.photo ? <img src={profile.photo} alt="" className="h-full w-full object-cover" /> : <IconCamera size={24} />}
        </span>
        <div className="min-w-0 flex-1 pt-1">
          <h1 className="truncate font-display text-[21px] font-medium text-ink">{profile.fullName || 'Tu nombre'}</h1>
          {profile.headline && <p className="mt-0.5 text-[13px] text-inkMuted">{profile.headline}</p>}
          <p className="mt-1 text-[12.5px] text-inkFaint">
            {[profile.city, profile.country].filter(Boolean).join(', ') || 'Ubicación sin definir'}
          </p>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border bg-surface2 text-inkFaint hover:text-ink"
        >
          <IconEdit size={15} />
        </button>
      </div>

      {(profile.email || profile.phones?.length > 0 || profile.website) && (
        <div className="mt-4 flex flex-wrap gap-x-5 gap-y-1.5 border-t border-border pt-3.5 text-[12.5px] text-inkMuted">
          {profile.email && <span>{profile.email}</span>}
          {profile.phones?.filter(Boolean).map((p, i) => (
            <span key={i} className="inline-flex items-center gap-1">
              <IconPhone size={11} />
              {p}
            </span>
          ))}
          {profile.website && (
            <span className="inline-flex items-center gap-1 text-emerald">
              <IconGlobe size={11} />
              {profile.website}
            </span>
          )}
        </div>
      )}

      <EditProfileModal open={open} onClose={() => setOpen(false)} profile={profile} />
    </div>
  )
}
