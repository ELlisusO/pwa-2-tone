import { useState } from 'react'
import Chip from '../common/Chip.jsx'
import SectionHeader from '../common/SectionHeader.jsx'
import EmptyState from '../common/EmptyState.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { IconPlus, IconSparkle } from '../../icons/index.jsx'

export default function SkillsEditor() {
  const skills = useVaultStore((s) => s.profile.skills || [])
  const updateSkills = useVaultStore((s) => s.updateSkills)
  const [text, setText] = useState('')

  function commit() {
    const clean = text.trim()
    if (!clean || skills.includes(clean)) {
      setText('')
      return
    }
    updateSkills([...skills, clean])
    setText('')
  }

  function remove(skill) {
    updateSkills(skills.filter((s) => s !== skill))
  }

  return (
    <section>
      <SectionHeader title="Habilidades e intereses" subtitle="Información adicional sobre ti" />
      <div className="mb-3 flex items-center gap-2 rounded-xl border border-border bg-surface2 px-3.5 py-2.5">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              commit()
            }
          }}
          placeholder="Añadir habilidad o interés y pulsar Enter"
          className="min-w-0 flex-1 bg-transparent text-[13.5px] text-ink placeholder:text-inkFaint focus:outline-none"
        />
        {text.trim() && (
          <button onClick={commit} className="shrink-0 text-inkFaint hover:text-emerald">
            <IconPlus size={15} />
          </button>
        )}
      </div>
      {skills.length === 0 ? (
        <EmptyState icon={IconSparkle} title="Sin habilidades añadidas" compact />
      ) : (
        <div className="flex flex-wrap gap-1.5">
          {skills.map((s) => (
            <Chip key={s} label={s} onRemove={() => remove(s)} />
          ))}
        </div>
      )}
    </section>
  )
}
