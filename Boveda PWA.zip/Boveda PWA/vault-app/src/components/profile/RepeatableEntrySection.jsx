import { useEffect, useState } from 'react'
import Modal from '../common/Modal.jsx'
import Input from '../common/Input.jsx'
import TextArea from '../common/TextArea.jsx'
import DatePicker from '../common/DatePicker.jsx'
import Button from '../common/Button.jsx'
import SectionHeader from '../common/SectionHeader.jsx'
import EmptyState from '../common/EmptyState.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { useUiStore } from '../../state/useUiStore.js'
import { IconPlus, IconEdit, IconTrash } from '../../icons/index.jsx'

function fieldValue(field, entry) {
  return entry[field.key] ?? ''
}

export default function RepeatableEntrySection({ section, icon, title, subtitle, fields, emptyFactory, renderSummary }) {
  const entries = useVaultStore((s) => s.profile[section] || [])
  const addProfileEntry = useVaultStore((s) => s.addProfileEntry)
  const updateProfileEntry = useVaultStore((s) => s.updateProfileEntry)
  const removeProfileEntry = useVaultStore((s) => s.removeProfileEntry)
  const confirm = useUiStore((s) => s.confirm)
  const pushToast = useUiStore((s) => s.pushToast)

  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState(emptyFactory())

  useEffect(() => {
    if (open) setForm(editing ? { ...editing } : emptyFactory())
  }, [open, editing])

  async function handleSave(e) {
    e.preventDefault()
    if (editing) {
      await updateProfileEntry(section, editing.id, form)
    } else {
      await addProfileEntry(section, form)
    }
    setOpen(false)
    setEditing(null)
  }

  async function handleDelete(id) {
    const ok = await confirm({ title: 'Eliminar registro', message: 'Esta acción no se puede deshacer.', danger: true, confirmLabel: 'Eliminar' })
    if (!ok) return
    await removeProfileEntry(section, id)
    pushToast('Eliminado.', 'default')
  }

  return (
    <section>
      <SectionHeader
        title={title}
        subtitle={subtitle}
        action={
          <Button
            size="sm"
            variant="secondary"
            icon={IconPlus}
            onClick={() => {
              setEditing(null)
              setOpen(true)
            }}
          >
            Añadir
          </Button>
        }
      />

      {entries.length === 0 ? (
        <EmptyState icon={icon} title="Sin registros" description="Añade el primero para completar esta sección." compact />
      ) : (
        <div className="space-y-2.5">
          {entries.map((entry) => {
            const s = renderSummary(entry)
            return (
              <div key={entry.id} className="flex items-start gap-3 rounded-xl2 border border-border bg-surface p-3.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14px] font-medium text-ink">{s.title}</p>
                  {s.subtitle && <p className="truncate text-[12.5px] text-inkFaint">{s.subtitle}</p>}
                  {s.meta && <p className="mt-0.5 text-[11.5px] text-inkFaint">{s.meta}</p>}
                  {s.description && <p className="mt-1.5 text-[13px] leading-relaxed text-inkMuted">{s.description}</p>}
                </div>
                <div className="flex shrink-0 gap-1">
                  <button
                    onClick={() => {
                      setEditing(entry)
                      setOpen(true)
                    }}
                    className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink"
                  >
                    <IconEdit size={14} />
                  </button>
                  <button onClick={() => handleDelete(entry.id)} className="rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-brick-soft">
                    <IconTrash size={14} />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? `Editar` : `Añadir`}
        size="md"
        footer={
          <div className="flex gap-2.5">
            <Button variant="secondary" full onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button full onClick={handleSave}>
              Guardar
            </Button>
          </div>
        }
      >
        <form onSubmit={handleSave} className="space-y-3.5 pb-2">
          {fields.map((field) => {
            if (field.type === 'textarea') {
              return (
                <TextArea
                  key={field.key}
                  label={field.label}
                  rows={3}
                  value={fieldValue(field, form)}
                  onChange={(e) => setForm((f) => ({ ...f, [field.key]: e.target.value }))}
                />
              )
            }
            if (field.type === 'date') {
              return (
                <DatePicker
                  key={field.key}
                  label={field.label}
                  value={fieldValue(field, form)}
                  onChange={(v) => setForm((f) => ({ ...f, [field.key]: v }))}
                />
              )
            }
            if (field.type === 'image') {
              const inputId = `entry-image-${section}-${field.key}`
              const value = fieldValue(field, form)
              return (
                <div key={field.key}>
                  <span className="mb-1.5 block text-[12.5px] font-medium text-inkMuted">{field.label}</span>
                  <div className="flex items-center gap-3">
                    <span className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-border bg-surface2 text-inkFaint">
                      {value ? <img src={value} alt="" className="h-full w-full object-cover" /> : <IconPlus size={16} />}
                    </span>
                    <label
                      htmlFor={inputId}
                      className="cursor-pointer rounded-xl border border-border bg-surface2 px-3.5 py-2 text-[13px] text-inkMuted hover:text-ink"
                    >
                      {value ? 'Cambiar imagen' : 'Subir imagen'}
                    </label>
                    <input
                      id={inputId}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (!file) return
                        const reader = new FileReader()
                        reader.onload = () => setForm((f) => ({ ...f, [field.key]: reader.result }))
                        reader.readAsDataURL(file)
                        e.target.value = ''
                      }}
                    />
                  </div>
                </div>
              )
            }
            return (
              <Input
                key={field.key}
                label={field.label}
                value={fieldValue(field, form)}
                onChange={(e) => setForm((f) => ({ ...f, [field.key]: e.target.value }))}
              />
            )
          })}
        </form>
      </Modal>
    </section>
  )
}
