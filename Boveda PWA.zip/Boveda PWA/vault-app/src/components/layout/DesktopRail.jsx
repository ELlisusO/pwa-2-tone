import { NavLink } from 'react-router-dom'
import { IconHome, IconVault, IconActivity, IconUser, IconStar, IconGrid, IconSettings, IconCloudBackup, IconLock } from '../../icons/index.jsx'
import { useAuthStore } from '../../state/useAuthStore.js'

const MAIN = [
  { to: '/', label: 'Inicio', icon: IconHome, end: true },
  { to: '/cuentas', label: 'Cuentas', icon: IconVault },
  { to: '/registro', label: 'Registro', icon: IconActivity },
  { to: '/perfil', label: 'Mi perfil', icon: IconUser },
]
const QUICK = [
  { to: '/favoritas', label: 'Favoritas', icon: IconStar },
  { to: '/categorias', label: 'Categorías', icon: IconGrid },
  { to: '/respaldo', label: 'Copias de seguridad', icon: IconCloudBackup },
  { to: '/configuracion', label: 'Configuración', icon: IconSettings },
]

export default function DesktopRail() {
  const lock = useAuthStore((s) => s.lock)
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-border bg-surface px-4 py-6 lg:flex">
      <div className="mb-8 flex items-center gap-2.5 px-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-soft text-emerald">
          <IconVault size={19} />
        </span>
        <span className="font-display text-[19px] font-medium text-ink">Bóveda</span>
      </div>

      <nav className="flex flex-col gap-1">
        {MAIN.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-[14px] transition-colors ${
                isActive ? 'bg-emerald-soft text-ink' : 'text-inkMuted hover:bg-surfaceHover hover:text-ink'
              }`
            }
          >
            <item.icon size={18} />
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="mt-6 border-t border-border pt-4">
        <p className="mb-1.5 px-3 text-[11px] uppercase tracking-wide text-inkFaint">Acceso rápido</p>
        <nav className="flex flex-col gap-0.5">
          {QUICK.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-3 py-2 text-[13.5px] transition-colors ${
                  isActive ? 'text-emerald' : 'text-inkMuted hover:text-ink'
                }`
              }
            >
              <item.icon size={16} />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>

      <button
        onClick={lock}
        className="mt-auto flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] text-inkFaint transition-colors hover:bg-surfaceHover hover:text-ink"
      >
        <IconLock size={16} />
        Bloquear bóveda
      </button>
    </aside>
  )
}
