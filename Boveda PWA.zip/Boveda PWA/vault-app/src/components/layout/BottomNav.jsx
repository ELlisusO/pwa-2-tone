import { NavLink } from 'react-router-dom'
import { IconHome, IconVault, IconActivity, IconUser } from '../../icons/index.jsx'

const ITEMS = [
  { to: '/', label: 'Inicio', icon: IconHome, end: true },
  { to: '/cuentas', label: 'Cuentas', icon: IconVault },
  { to: '/registro', label: 'Registro', icon: IconActivity },
  { to: '/perfil', label: 'Mi perfil', icon: IconUser },
]

export default function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
      <div className="mx-auto flex max-w-lg items-stretch justify-around px-2">
        {ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `relative flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] transition-colors ${
                isActive ? 'text-emerald' : 'text-inkFaint'
              }`
            }
          >
            {({ isActive }) => (
              <>
                {isActive && <span className="absolute top-0 h-0.5 w-8 rounded-full bg-emerald" />}
                <item.icon size={21} strokeWidth={isActive ? 2 : 1.6} />
                <span className={isActive ? 'font-medium' : ''}>{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
