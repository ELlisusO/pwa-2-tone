import { Outlet } from 'react-router-dom'
import BottomNav from './BottomNav.jsx'
import DesktopRail from './DesktopRail.jsx'
import ToastHost from '../common/ToastHost.jsx'
import ConfirmDialogHost from '../common/ConfirmDialogHost.jsx'
import SecondPinGateModal from '../auth/SecondPinGateModal.jsx'
import { useAuthStore } from '../../state/useAuthStore.js'
import { useVaultStore } from '../../state/useVaultStore.js'
import { IconLock, IconSun, IconMoon } from '../../icons/index.jsx'

export default function AppShell() {
  const lock = useAuthStore((s) => s.lock)
  const theme = useVaultStore((s) => s.settings.theme)
  const updateSettings = useVaultStore((s) => s.updateSettings)

  return (
    <div className="min-h-full bg-bg lg:pl-60">
      <div className="fixed right-3 top-3 z-30 flex items-center gap-1.5 pt-[env(safe-area-inset-top)] lg:hidden">
        <button
          onClick={() => updateSettings({ theme: theme === 'dark' ? 'light' : 'dark' })}
          className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-surface/90 text-inkMuted backdrop-blur"
        >
          {theme === 'dark' ? <IconSun size={16} /> : <IconMoon size={16} />}
        </button>
        <button
          onClick={lock}
          className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-surface/90 text-inkMuted backdrop-blur"
        >
          <IconLock size={16} />
        </button>
      </div>

      <main className="mx-auto min-h-full max-w-3xl px-4 pb-28 pt-[calc(14px+env(safe-area-inset-top))] sm:px-6 lg:px-10 lg:pb-14 lg:pt-10">
        <Outlet />
      </main>

      <BottomNav />
      <DesktopRail />
      <ToastHost />
      <ConfirmDialogHost />
      <SecondPinGateModal />
    </div>
  )
}
