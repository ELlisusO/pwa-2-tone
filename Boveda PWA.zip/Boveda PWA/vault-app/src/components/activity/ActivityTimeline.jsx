import { formatDateTime, relativeTime } from '../../lib/dateUtils.js'
import EmptyState from '../common/EmptyState.jsx'
import {
  IconActivity,
  IconVault,
  IconLayers,
  IconGrid,
  IconTag,
  IconUser,
  IconLock,
  IconShieldCheck,
  IconCloudBackup,
} from '../../icons/index.jsx'

const ICONS = {
  account_created: IconVault,
  account_updated: IconVault,
  account_deleted: IconVault,
  service_added: IconLayers,
  service_updated: IconLayers,
  service_deleted: IconLayers,
  category_created: IconGrid,
  category_updated: IconGrid,
  category_deleted: IconGrid,
  tag_deleted: IconTag,
  profile_updated: IconUser,
  pin_changed: IconLock,
  pin2_enabled: IconShieldCheck,
  pin2_changed: IconShieldCheck,
  pin2_disabled: IconShieldCheck,
  backup_exported: IconCloudBackup,
  backup_imported: IconCloudBackup,
}

export default function ActivityTimeline({ entries }) {
  if (entries.length === 0) {
    return <EmptyState icon={IconActivity} title="Sin actividad todavía" description="Aquí verás un registro cronológico de lo que ocurra en tu bóveda." />
  }

  return (
    <div className="relative">
      <div className="absolute bottom-2 left-[18px] top-2 w-px bg-border" />
      <div className="space-y-1">
        {entries.map((e) => {
          const Icon = ICONS[e.type] || IconActivity
          return (
            <div key={e.id} className="relative flex gap-3.5 py-2.5 pl-0">
              <span className="relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border bg-surface2 text-emerald">
                <Icon size={15} />
              </span>
              <div className="min-w-0 flex-1 pt-1.5">
                <p className="text-[13.5px] text-ink">{e.message}</p>
                <p className="mt-0.5 text-[11.5px] text-inkFaint" title={formatDateTime(e.timestamp)}>
                  {relativeTime(e.timestamp)}
                </p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
