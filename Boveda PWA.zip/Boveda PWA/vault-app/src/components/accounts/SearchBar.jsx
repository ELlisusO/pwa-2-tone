import { IconSearch, IconClose } from '../../icons/index.jsx'

export default function SearchBar({ value, onChange, placeholder = 'Buscar en mi bóveda…' }) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl2 border border-border bg-surface2 px-4 py-3">
      <IconSearch size={17} className="shrink-0 text-inkFaint" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="min-w-0 flex-1 bg-transparent text-[14.5px] text-ink placeholder:text-inkFaint focus:outline-none"
      />
      {value && (
        <button onClick={() => onChange('')} className="shrink-0 rounded-lg p-1 text-inkFaint hover:text-ink">
          <IconClose size={15} />
        </button>
      )}
    </div>
  )
}
