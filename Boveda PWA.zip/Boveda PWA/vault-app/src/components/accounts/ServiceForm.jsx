import { useEffect, useState } from 'react'
import Modal from '../common/Modal.jsx'
import Input from '../common/Input.jsx'
import TextArea from '../common/TextArea.jsx'
import Select from '../common/Select.jsx'
import Switch from '../common/Switch.jsx'
import Button from '../common/Button.jsx'
import Avatar from '../common/Avatar.jsx'
import PasswordInput from '../common/PasswordInput.jsx'
import TagPicker from '../common/TagPicker.jsx'
import IconPicker from '../common/IconPicker.jsx'
import DatesEditor from './DatesEditor.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { emptyService } from '../../data/model.js'
import { IconByKey } from '../../icons/index.jsx'

function cloneForForm(service, categoryId) {
  return service ? JSON.parse(JSON.stringify(service)) : emptyService(categoryId)
}

export default function ServiceForm({ open, onClose, initialService = null, defaultCategoryId, onSave, parentSensitive }) {
  const categories = useVaultStore((s) => s.categories)
  const [form, setForm] = useState(() => cloneForForm(initialService, defaultCategoryId))
  const [nameError, setNameError] = useState('')
  const [iconPickerOpen, setIconPickerOpen] = useState(false)

  useEffect(() => {
    if (open) {
      setForm(cloneForForm(initialService, defaultCategoryId))
      setNameError('')
    }
  }, [open, initialService, defaultCategoryId])

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }
  function setRecovery(field, value) {
    setForm((f) => ({ ...f, recovery: { ...f.recovery, [field]: value } }))
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.name.trim()) {
      setNameError('El nombre es obligatorio.')
      return
    }
    onSave(form)
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initialService ? 'Editar servicio' : 'Nuevo servicio asociado'}
      subtitle={parentSensitive ? 'Hereda la protección adicional de la cuenta principal.' : undefined}
      size="lg"
      footer={
        <div className="flex gap-2.5">
          <Button variant="secondary" full onClick={onClose}>
            Cancelar
          </Button>
          <Button full onClick={handleSubmit}>
            Guardar
          </Button>
        </div>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-6 pb-2">
        <div className="flex items-center gap-3.5">
          <button type="button" onClick={() => setIconPickerOpen(true)} className="group relative">
            <Avatar iconKey={form.icon} customImage={form.customImage} size="xl" />
            <span className="absolute -bottom-1 -right-1 rounded-full border border-border bg-surface2 p-1 text-inkFaint group-hover:text-emerald">
              <IconByKey iconKey="image" size={11} />
            </span>
          </button>
          <div className="flex-1">
            <Input
              label="Nombre del servicio"
              required
              placeholder="p. ej. YouTube, Drive, Discord…"
              value={form.name}
              onChange={(e) => set('name', e.target.value)}
              error={nameError}
            />
          </div>
        </div>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Información</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input label="Usuario" value={form.username} onChange={(e) => set('username', e.target.value)} />
            <Input label="Correo" type="email" value={form.email} onChange={(e) => set('email', e.target.value)} />
            <PasswordInput label="Contraseña" value={form.password} onChange={(e) => set('password', e.target.value)} />
            <Input label="Teléfono" value={form.phone} onChange={(e) => set('phone', e.target.value)} />
          </div>
          <Input label="URL" placeholder="https://" value={form.url} onChange={(e) => set('url', e.target.value)} />
        </section>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Seguridad</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input
              label="Método de recuperación"
              value={form.recovery.method}
              onChange={(e) => setRecovery('method', e.target.value)}
            />
            <Input
              label="Correo de recuperación"
              type="email"
              value={form.recovery.email}
              onChange={(e) => setRecovery('email', e.target.value)}
            />
            <PasswordInput
              label="PIN adicional"
              value={form.recovery.additionalPin}
              onChange={(e) => setRecovery('additionalPin', e.target.value)}
            />
            <PasswordInput
              label="Código de recuperación"
              value={form.recovery.backupCode}
              onChange={(e) => setRecovery('backupCode', e.target.value)}
            />
          </div>
        </section>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Organización</p>
          <Select
            label="Categoría"
            value={form.categoryId}
            onChange={(v) => set('categoryId', v)}
            options={categories.map((c) => ({ value: c.id, label: c.name, icon: (p) => <IconByKey iconKey={c.icon} {...p} /> }))}
          />
          <div>
            <span className="mb-1.5 block text-[12.5px] font-medium text-inkMuted">Etiquetas</span>
            <TagPicker selectedIds={form.tags} onChange={(tags) => set('tags', tags)} />
          </div>
          <TextArea label="Notas" rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} />
          <div className="rounded-xl border border-border bg-surface2/60 px-3.5 py-3">
            <Switch checked={form.favorite} onChange={(v) => set('favorite', v)} label="Marcar como favorito" />
          </div>
        </section>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Fechas</p>
          <DatesEditor dates={form.dates} onChange={(dates) => set('dates', dates)} />
        </section>
      </form>

      <IconPicker
        open={iconPickerOpen}
        onClose={() => setIconPickerOpen(false)}
        value={form.icon}
        customImage={form.customImage}
        onChange={({ icon, customImage }) => setForm((f) => ({ ...f, icon, customImage }))}
      />
    </Modal>
  )
}
