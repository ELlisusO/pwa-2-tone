import { useEffect, useRef, useState } from 'react'
import { IconEye, IconEyeOff, IconCopy, IconShieldCheck } from '../../icons/index.jsx'
import { useAuthStore } from '../../state/useAuthStore.js'
import { useUiStore } from '../../state/useUiStore.js'
import { decryptString, isEncryptedField } from '../../lib/crypto.js'

const AUTO_HIDE_MS = 12000

export default function SensitiveField({ label, rawValue, sensitive = false, placeholder = 'Sin definir', mono = true }) {
  const [revealed, setRevealed] = useState(false)
  const [plain, setPlain] = useState(null)
  const [busy, setBusy] = useState(false)
  const timerRef = useRef(null)
  const pushToast = useUiStore((s) => s.pushToast)

  const isEmpty = isEncryptedField(rawValue) ? false : !rawValue

  useEffect(() => () => clearTimeout(timerRef.current), [])

  async function resolvePlain() {
    if (isEncryptedField(rawValue)) {
      const key = sensitive
        ? await useAuthStore.getState().requestSensitiveUnlock(label || 'información protegida')
        : useAuthStore.getState().vaultKey
      if (!key) return null
      return decryptString(rawValue, key)
    }
    return rawValue
  }

  async function toggleReveal() {
    if (isEmpty) return
    if (revealed) {
      hide()
      return
    }
    setBusy(true)
    try {
      const value = await resolvePlain()
      if (value == null) return
      setPlain(value)
      setRevealed(true)
      clearTimeout(timerRef.current)
      timerRef.current = setTimeout(hide, AUTO_HIDE_MS)
    } finally {
      setBusy(false)
    }
  }

  function hide() {
    setRevealed(false)
    setPlain(null)
    clearTimeout(timerRef.current)
  }

  async function copy() {
    if (isEmpty) return
    setBusy(true)
    try {
      const value = plain != null ? plain : await resolvePlain()
      if (value == null) return
      await navigator.clipboard.writeText(value)
      pushToast('Copiado al portapapeles', 'success')
    } catch {
      pushToast('No se pudo copiar', 'danger')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      {label && (
        <span className="mb-1.5 flex items-center gap-1.5 text-[12.5px] font-medium text-inkMuted">
          {label}
          {sensitive && <IconShieldCheck size={12.5} className="text-emerald" />}
        </span>
      )}
      <div className="flex items-center gap-1.5 rounded-xl border border-border bg-surface2 px-3.5 py-2.5">
        <span
          className={`flex-1 truncate text-[14.5px] ${mono ? 'font-mono' : ''} ${
            revealed ? 'text-ink' : 'text-inkFaint'
          }`}
        >
          {isEmpty ? placeholder : revealed ? plain : '•'.repeat(10)}
        </span>
        {!isEmpty && (
          <>
            <button
              type="button"
              onClick={toggleReveal}
              disabled={busy}
              className="shrink-0 rounded-lg p-1.5 text-inkFaint transition-colors hover:bg-surfaceHover hover:text-ink disabled:opacity-40"
            >
              {revealed ? <IconEyeOff size={16} /> : <IconEye size={16} />}
            </button>
            <button
              type="button"
              onClick={copy}
              disabled={busy}
              className="shrink-0 rounded-lg p-1.5 text-inkFaint transition-colors hover:bg-surfaceHover hover:text-ink disabled:opacity-40"
            >
              <IconCopy size={16} />
            </button>
          </>
        )}
      </div>
    </div>
  )
}
