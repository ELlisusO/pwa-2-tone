import Modal from '../common/Modal.jsx'
import Avatar from '../common/Avatar.jsx'
import Button from '../common/Button.jsx'
import SensitiveField from './SensitiveField.jsx'
import { formatDate, dateTypeLabel } from '../../lib/dateUtils.js'
import { IconEdit, IconTrash, IconGlobe } from '../../icons/index.jsx'

export default function ServiceDetailModal({ service, sensitive, onClose, onEdit, onDelete }) {
  return (
    <Modal
      open={!!service}
      onClose={onClose}
      title={service?.name || 'Servicio'}
      size="md"
      footer={
        service && (
          <div className="flex gap-2.5">
            <Button variant="secondary" full icon={IconEdit} onClick={onEdit}>
              Editar
            </Button>
            <Button variant="danger" full icon={IconTrash} onClick={onDelete}>
              Eliminar
            </Button>
          </div>
        )
      }
    >
      {service && (
        <div className="space-y-5 pb-2">
          <div className="flex items-center gap-3.5">
            <Avatar iconKey={service.icon} customImage={service.customImage} size="lg" />
            <div className="min-w-0">
              <p className="truncate text-[13.5px] text-inkMuted">{service.username || service.email || 'Sin usuario ni correo'}</p>
              {service.url && (
                <a
                  href={service.url}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-0.5 inline-flex items-center gap-1 text-[12px] text-emerald hover:underline"
                >
                  <IconGlobe size={11} />
                  {service.url}
                </a>
              )}
            </div>
          </div>

          <SensitiveField label="Contraseña" rawValue={service.password} sensitive={sensitive} />

          {(service.recovery?.method || service.recovery?.email) && (
            <div className="grid grid-cols-1 gap-3 text-[13px] sm:grid-cols-2">
              {service.recovery?.method && (
                <div>
                  <p className="text-[11.5px] text-inkFaint">Método de recuperación</p>
                  <p className="text-ink">{service.recovery.method}</p>
                </div>
              )}
              {service.recovery?.email && (
                <div>
                  <p className="text-[11.5px] text-inkFaint">Correo de recuperación</p>
                  <p className="text-ink">{service.recovery.email}</p>
                </div>
              )}
            </div>
          )}

          {service.recovery?.additionalPin && (
            <SensitiveField label="PIN adicional" rawValue={service.recovery.additionalPin} sensitive={sensitive} />
          )}
          {service.recovery?.backupCode && (
            <SensitiveField label="Código de recuperación" rawValue={service.recovery.backupCode} sensitive={sensitive} />
          )}

          {service.dates?.length > 0 && (
            <div>
              <p className="mb-1.5 text-[11.5px] uppercase tracking-wide text-inkFaint">Fechas</p>
              <div className="space-y-1.5">
                {service.dates.map((d) => (
                  <div key={d.id} className="flex justify-between text-[13px]">
                    <span className="text-inkMuted">{d.type === 'other' ? d.customLabel || 'Otra fecha' : dateTypeLabel(d.type)}</span>
                    <span className="font-mono tabular-nums text-ink">{formatDate(d.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {service.notes && (
            <div>
              <p className="mb-1 text-[11.5px] uppercase tracking-wide text-inkFaint">Notas</p>
              <p className="whitespace-pre-wrap text-[13.5px] text-inkMuted">{service.notes}</p>
            </div>
          )}
        </div>
      )}
    </Modal>
  )
}
