import Avatar from '../common/Avatar.jsx'
import { IconEdit, IconTrash, IconStar, IconStarFilled, IconChevronRight } from '../../icons/index.jsx'

export default function ServiceCard({ service, onOpen, onEdit, onDelete, onToggleFavorite }) {
  const identity = service.username || service.email || 'Sin usuario ni correo'
  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-surface2/50 p-3 transition-colors hover:border-borderStrong">
      <button onClick={onOpen} className="flex min-w-0 flex-1 items-center gap-3 text-left">
        <Avatar iconKey={service.icon} customImage={service.customImage} size="md" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13.5px] font-medium text-ink">{service.name || 'Sin nombre'}</p>
          <p className="truncate text-[12px] text-inkFaint">{identity}</p>
        </div>
      </button>
      <button onClick={onToggleFavorite} className="shrink-0 rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-amber">
        {service.favorite ? <IconStarFilled size={15} className="text-amber" /> : <IconStar size={15} />}
      </button>
      <button onClick={onEdit} className="shrink-0 rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-ink">
        <IconEdit size={15} />
      </button>
      <button onClick={onDelete} className="shrink-0 rounded-lg p-1.5 text-inkFaint hover:bg-surfaceHover hover:text-brick-soft">
        <IconTrash size={15} />
      </button>
    </div>
  )
}
