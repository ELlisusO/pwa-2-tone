import Avatar from '../common/Avatar.jsx'
import EmptyState from '../common/EmptyState.jsx'
import { IconShare } from '../../icons/index.jsx'

export default function RelationsGraph({ account, onSelectService }) {
  const services = account.services || []

  if (services.length === 0) {
    return (
      <EmptyState
        icon={IconShare}
        title="Sin servicios asociados"
        description="Cuando añadas servicios a esta cuenta, aparecerán aquí conectados visualmente."
        compact
      />
    )
  }

  const radius = services.length <= 3 ? 32 : services.length <= 6 ? 36 : 40
  const positions = services.map((_, i) => {
    const angle = (2 * Math.PI * i) / services.length - Math.PI / 2
    return { x: 50 + radius * Math.cos(angle), y: 50 + radius * Math.sin(angle) }
  })

  return (
    <div className="relative mx-auto h-80 w-full max-w-md select-none">
      <svg className="absolute inset-0 h-full w-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
        {positions.map((p, i) => (
          <line
            key={i}
            x1="50"
            y1="50"
            x2={p.x}
            y2={p.y}
            stroke="rgb(var(--c-border-strong))"
            strokeWidth="1"
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </svg>

      <div className="absolute left-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1.5">
        <Avatar iconKey={account.icon} customImage={account.customImage} size="lg" shape="circle" />
        <span className="max-w-[92px] truncate text-center text-[11.5px] font-medium text-ink">{account.name}</span>
      </div>

      {services.map((s, i) => (
        <button
          key={s.id}
          onClick={() => onSelectService(s.id)}
          style={{ left: `${positions[i].x}%`, top: `${positions[i].y}%` }}
          className="group absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1.5"
        >
          <Avatar
            iconKey={s.icon}
            customImage={s.customImage}
            size="md"
            shape="circle"
            className="transition-transform duration-150 group-hover:scale-110"
          />
          <span className="max-w-[76px] truncate text-center text-[10.5px] text-inkFaint group-hover:text-ink">{s.name}</span>
        </button>
      ))}
    </div>
  )
}
