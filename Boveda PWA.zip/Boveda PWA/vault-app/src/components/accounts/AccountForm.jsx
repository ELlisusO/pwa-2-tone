import { useEffect, useState } from 'react'
import Modal from '../common/Modal.jsx'
import Input from '../common/Input.jsx'
import TextArea from '../common/TextArea.jsx'
import Select from '../common/Select.jsx'
import Switch from '../common/Switch.jsx'
import Button from '../common/Button.jsx'
import Avatar from '../common/Avatar.jsx'
import PasswordInput from '../common/PasswordInput.jsx'
import TagPicker from '../common/TagPicker.jsx'
import IconPicker from '../common/IconPicker.jsx'
import DatesEditor from './DatesEditor.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { useAuthStore } from '../../state/useAuthStore.js'
import { useUiStore } from '../../state/useUiStore.js'
import { emptyAccount } from '../../data/model.js'
import { IconByKey, IconShieldCheck } from '../../icons/index.jsx'

function cloneForForm(account, defaultCategoryId) {
  return account ? JSON.parse(JSON.stringify(account)) : emptyAccount(defaultCategoryId)
}

export default function AccountForm({ open, onClose, initialAccount = null, defaultCategoryId }) {
  const categories = useVaultStore((s) => s.categories)
  const upsertAccount = useVaultStore((s) => s.upsertAccount)
  const hasPin2 = useAuthStore((s) => !!s.meta?.pin2)
  const requestSensitiveUnlock = useAuthStore((s) => s.requestSensitiveUnlock)
  const pushToast = useUiStore((s) => s.pushToast)

  const [form, setForm] = useState(() => cloneForForm(initialAccount, defaultCategoryId))
  const [nameError, setNameError] = useState('')
  const [iconPickerOpen, setIconPickerOpen] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (open) {
      setForm(cloneForForm(initialAccount, defaultCategoryId))
      setNameError('')
    }
  }, [open, initialAccount, defaultCategoryId])

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }
  function setRecovery(field, value) {
    setForm((f) => ({ ...f, recovery: { ...f.recovery, [field]: value } }))
  }

  async function handleToggleSensitive(next) {
    if (!next) {
      set('sensitive', false)
      return
    }
    if (!hasPin2) {
      pushToast('Configura un PIN 2 en Ajustes antes de proteger cuentas.', 'danger')
      return
    }
    const key = await requestSensitiveUnlock(`proteger "${form.name || 'esta cuenta'}"`)
    if (key) set('sensitive', true)
  }

  async function handleSubmit(e) {
    e.preventDefault()
    if (!form.name.trim()) {
      setNameError('El nombre es obligatorio.')
      return
    }
    setSaving(true)
    try {
      await upsertAccount(form)
      pushToast(initialAccount ? 'Cuenta actualizada.' : 'Cuenta creada.', 'success')
      onClose()
    } catch (err) {
      pushToast(
        err?.code === 'SENSITIVE_LOCKED' ? 'Verifica tu PIN 2 para guardar cambios protegidos.' : 'No se pudo guardar la cuenta.',
        'danger'
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initialAccount ? 'Editar cuenta' : 'Nueva cuenta'}
      size="lg"
      footer={
        <div className="flex gap-2.5">
          <Button variant="secondary" full onClick={onClose}>
            Cancelar
          </Button>
          <Button full loading={saving} onClick={handleSubmit}>
            Guardar
          </Button>
        </div>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-6 pb-2">
        <div className="flex items-center gap-3.5">
          <button type="button" onClick={() => setIconPickerOpen(true)} className="group relative">
            <Avatar iconKey={form.icon} customImage={form.customImage} size="xl" />
            <span className="absolute -bottom-1 -right-1 rounded-full border border-border bg-surface2 p-1 text-inkFaint group-hover:text-emerald">
              <IconByKey iconKey="image" size={11} />
            </span>
          </button>
          <div className="flex-1">
            <Input
              label="Nombre de la cuenta"
              required
              placeholder="p. ej. Google, Banco, Netflix…"
              value={form.name}
              onChange={(e) => set('name', e.target.value)}
              error={nameError}
            />
          </div>
        </div>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Información</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input label="Usuario" value={form.username} onChange={(e) => set('username', e.target.value)} />
            <Input label="Correo" type="email" value={form.email} onChange={(e) => set('email', e.target.value)} />
            <PasswordInput label="Contraseña" value={form.password} onChange={(e) => set('password', e.target.value)} />
            <Input label="Teléfono asociado" value={form.phone} onChange={(e) => set('phone', e.target.value)} />
          </div>
          <Input label="URL" placeholder="https://" value={form.url} onChange={(e) => set('url', e.target.value)} />
        </section>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Seguridad</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input
              label="Método de recuperación"
              placeholder="p. ej. Correo, SMS, app…"
              value={form.recovery.method}
              onChange={(e) => setRecovery('method', e.target.value)}
            />
            <Input
              label="Correo de recuperación"
              type="email"
              value={form.recovery.email}
              onChange={(e) => setRecovery('email', e.target.value)}
            />
            <PasswordInput
              label="PIN adicional"
              value={form.recovery.additionalPin}
              onChange={(e) => setRecovery('additionalPin', e.target.value)}
            />
            <PasswordInput
              label="Código de recuperación"
              value={form.recovery.backupCode}
              onChange={(e) => setRecovery('backupCode', e.target.value)}
            />
          </div>
          <Input
            label="Autenticación utilizada"
            placeholder="p. ej. Autenticación en dos pasos, app autenticadora…"
            value={form.recovery.twoFactor}
            onChange={(e) => setRecovery('twoFactor', e.target.value)}
          />
        </section>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Organización</p>
          <Select
            label="Categoría"
            value={form.categoryId}
            onChange={(v) => set('categoryId', v)}
            options={categories.map((c) => ({ value: c.id, label: c.name, icon: (p) => <IconByKey iconKey={c.icon} {...p} /> }))}
          />
          <div>
            <span className="mb-1.5 block text-[12.5px] font-medium text-inkMuted">Etiquetas</span>
            <TagPicker selectedIds={form.tags} onChange={(tags) => set('tags', tags)} />
          </div>
          <TextArea label="Descripción" rows={2} value={form.description} onChange={(e) => set('description', e.target.value)} />
          <div className="rounded-xl border border-border bg-surface2/60 px-3.5 py-3">
            <Switch checked={form.favorite} onChange={(v) => set('favorite', v)} label="Marcar como favorita" />
          </div>
          <div className="rounded-xl border border-emerald/25 bg-emerald-soft/40 px-3.5 py-3">
            <Switch
              checked={form.sensitive}
              onChange={handleToggleSensitive}
              label={
                <span className="flex items-center gap-1.5">
                  <IconShieldCheck size={13} className="text-emerald" /> Protección adicional
                </span>
              }
              description="Pedirá tu PIN 2 para ver o editar la contraseña y la información de recuperación de esta cuenta."
            />
          </div>
        </section>

        <section className="space-y-3">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-inkFaint">Fechas</p>
          <DatesEditor dates={form.dates} onChange={(dates) => set('dates', dates)} />
        </section>
      </form>

      <IconPicker
        open={iconPickerOpen}
        onClose={() => setIconPickerOpen(false)}
        value={form.icon}
        customImage={form.customImage}
        onChange={({ icon, customImage }) => setForm((f) => ({ ...f, icon, customImage }))}
      />
    </Modal>
  )
}
