import { Link } from 'react-router-dom'
import Avatar from '../common/Avatar.jsx'
import { IconByKey, IconStar, IconStarFilled, IconShieldCheck, IconLayers, IconAlertTriangle } from '../../icons/index.jsx'
import { accountIssues } from '../../data/model.js'
import { useVaultStore } from '../../state/useVaultStore.js'

export default function AccountCard({ account, category }) {
  const toggleFavorite = useVaultStore((s) => s.toggleFavorite)
  const issues = accountIssues(account)
  const identity = account.username || account.email || 'Sin usuario ni correo'
  const serviceCount = account.services?.length || 0

  return (
    <Link
      to={`/cuentas/${account.id}`}
      className="group flex items-center gap-3.5 rounded-xl2 border border-border bg-surface p-3.5 transition-colors hover:border-borderStrong hover:bg-surfaceHover"
    >
      <Avatar iconKey={account.icon} customImage={account.customImage} size="lg" />

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <p className="truncate text-[14.5px] font-medium text-ink">{account.name || 'Sin nombre'}</p>
          {account.sensitive && <IconShieldCheck size={13} className="shrink-0 text-emerald" />}
        </div>
        <p className="truncate text-[12.5px] text-inkFaint">{identity}</p>
        <div className="mt-1.5 flex flex-wrap items-center gap-2.5">
          {category && (
            <span className="inline-flex items-center gap-1 text-[11px] text-inkFaint">
              <IconByKey iconKey={category.icon} size={11.5} />
              {category.name}
            </span>
          )}
          {serviceCount > 0 && (
            <span className="inline-flex items-center gap-1 text-[11px] text-inkFaint">
              <IconLayers size={11.5} />
              {serviceCount} asociado{serviceCount > 1 ? 's' : ''}
            </span>
          )}
          {issues.length > 0 && (
            <span className="inline-flex items-center gap-1 text-[11px] text-amber" title={issues.join(', ')}>
              <IconAlertTriangle size={11.5} />
              Revisar
            </span>
          )}
        </div>
      </div>

      <button
        onClick={(e) => {
          e.preventDefault()
          e.stopPropagation()
          toggleFavorite(account.id)
        }}
        className="shrink-0 rounded-lg p-2 text-inkFaint transition-colors hover:bg-surfaceHover hover:text-amber"
      >
        {account.favorite ? <IconStarFilled size={18} className="text-amber" /> : <IconStar size={18} />}
      </button>
    </Link>
  )
}
