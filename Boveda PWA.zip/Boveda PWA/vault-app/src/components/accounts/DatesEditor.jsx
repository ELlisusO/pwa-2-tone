import Select from '../common/Select.jsx'
import Input from '../common/Input.jsx'
import DatePicker from '../common/DatePicker.jsx'
import Button from '../common/Button.jsx'
import { DATE_TYPES } from '../../lib/dateUtils.js'
import { emptyDateEntry } from '../../data/model.js'
import { IconPlus, IconTrash, IconCalendar } from '../../icons/index.jsx'

export default function DatesEditor({ dates, onChange }) {
  function update(id, patch) {
    onChange(dates.map((d) => (d.id === id ? { ...d, ...patch } : d)))
  }
  function remove(id) {
    onChange(dates.filter((d) => d.id !== id))
  }
  function add() {
    onChange([...dates, emptyDateEntry()])
  }

  return (
    <div className="space-y-3">
      {dates.length === 0 && (
        <p className="rounded-xl border border-dashed border-border px-3.5 py-3 text-[12.5px] text-inkFaint">
          Sin fechas registradas todavía.
        </p>
      )}
      {dates.map((d) => (
        <div key={d.id} className="rounded-xl border border-border bg-surface2/60 p-3">
          <div className="flex items-start gap-2">
            <div className="grid flex-1 grid-cols-1 gap-2 sm:grid-cols-2">
              <Select
                value={d.type}
                onChange={(type) => update(d.id, { type })}
                options={DATE_TYPES.map((t) => ({ value: t.id, label: t.label }))}
              />
              <DatePicker value={d.value} onChange={(value) => update(d.id, { value })} />
            </div>
            <button
              onClick={() => remove(d.id)}
              className="mt-0.5 shrink-0 rounded-lg p-2 text-inkFaint hover:bg-surfaceHover hover:text-brick-soft"
            >
              <IconTrash size={15} />
            </button>
          </div>
          {d.type === 'other' && (
            <Input
              className="mt-2"
              placeholder="Nombre de la fecha (p. ej. Renovación del dominio)"
              value={d.customLabel}
              onChange={(e) => update(d.id, { customLabel: e.target.value })}
            />
          )}
        </div>
      ))}
      <Button variant="secondary" size="sm" icon={IconPlus} onClick={add}>
        Añadir fecha
      </Button>
    </div>
  )
}
