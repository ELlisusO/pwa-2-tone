import { IconByKey, IconGrid } from '../../icons/index.jsx'

export default function CategoryFilterBar({ categories, value, onChange }) {
  return (
    <div className="chip-row -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
      <button
        onClick={() => onChange(null)}
        className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[13px] transition-colors ${
          value === null ? 'border-emerald/60 bg-emerald-soft text-ink' : 'border-border bg-surface2 text-inkMuted hover:text-ink'
        }`}
      >
        <IconGrid size={13} className={value === null ? 'text-emerald' : ''} />
        Todas
      </button>
      {categories.map((cat) => (
        <button
          key={cat.id}
          onClick={() => onChange(cat.id)}
          className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[13px] transition-colors ${
            value === cat.id ? 'border-emerald/60 bg-emerald-soft text-ink' : 'border-border bg-surface2 text-inkMuted hover:text-ink'
          }`}
        >
          <IconByKey iconKey={cat.icon} size={13} className={value === cat.id ? 'text-emerald' : ''} />
          {cat.name}
        </button>
      ))}
    </div>
  )
}
