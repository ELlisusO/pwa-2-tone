import { useRef, useState } from 'react'
import SectionHeader from '../common/SectionHeader.jsx'
import Button from '../common/Button.jsx'
import Modal from '../common/Modal.jsx'
import PasswordInput from '../common/PasswordInput.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { useAuthStore } from '../../state/useAuthStore.js'
import { useUiStore } from '../../state/useUiStore.js'
import { buildPlaintextBundle, exportVault, parseBackupFile, decryptBackup, reEncryptBundleForVault } from '../../lib/backup.js'
import { IconDownload, IconUpload, IconFileJson } from '../../icons/index.jsx'

function BackupPasswordModal({ open, onClose, mode, title, subtitle, onSubmit, submitting }) {
  const [password, setPassword] = useState('')
  const [confirmPw, setConfirmPw] = useState('')
  const [error, setError] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    if (password.length < 6) {
      setError('Usa al menos 6 caracteres.')
      return
    }
    if (mode === 'create' && password !== confirmPw) {
      setError('Las contraseñas no coinciden.')
      return
    }
    setError('')
    onSubmit(password)
  }

  return (
    <Modal
      open={open}
      onClose={() => {
        setPassword('')
        setConfirmPw('')
        setError('')
        onClose()
      }}
      title={title}
      subtitle={subtitle}
      size="sm"
      footer={
        <Button full loading={submitting} onClick={handleSubmit}>
          Continuar
        </Button>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-3.5 pb-2">
        <PasswordInput label="Contraseña de respaldo" value={password} onChange={(e) => setPassword(e.target.value)} />
        {mode === 'create' && (
          <PasswordInput label="Confirmar contraseña" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} />
        )}
        {error && <p className="text-[12.5px] text-brick-soft">{error}</p>}
      </form>
    </Modal>
  )
}

export default function BackupSettings() {
  const accounts = useVaultStore((s) => s.accounts)
  const categories = useVaultStore((s) => s.categories)
  const tags = useVaultStore((s) => s.tags)
  const profile = useVaultStore((s) => s.profile)
  const activityLog = useVaultStore((s) => s.activityLog)
  const settings = useVaultStore((s) => s.settings)
  const replaceAll = useVaultStore((s) => s.replaceAll)
  const logAndPersist = useVaultStore((s) => s.logAndPersist)
  const requestSensitiveUnlock = useAuthStore((s) => s.requestSensitiveUnlock)
  const confirm = useUiStore((s) => s.confirm)
  const pushToast = useUiStore((s) => s.pushToast)

  const [exportOpen, setExportOpen] = useState(false)
  const [exportBusy, setExportBusy] = useState(false)
  const [importOpen, setImportOpen] = useState(false)
  const [importBusy, setImportBusy] = useState(false)
  const [pendingRaw, setPendingRaw] = useState(null)
  const fileRef = useRef(null)

  async function handleExport(password) {
    setExportBusy(true)
    try {
      const hasSensitive = accounts.some((a) => a.sensitive)
      let sensitiveKey = null
      if (hasSensitive) {
        sensitiveKey = await requestSensitiveUnlock('exportar tu copia de seguridad')
        if (!sensitiveKey) {
          setExportBusy(false)
          return
        }
      }
      const bundle = await buildPlaintextBundle({ accounts, categories, tags, profile, activityLog, settings }, sensitiveKey)
      const { fileName, json } = await exportVault(bundle, password)
      const blob = new Blob([json], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = fileName
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
      await logAndPersist('backup_exported', 'Copia de seguridad exportada')
      pushToast('Copia de seguridad descargada.', 'success')
      setExportOpen(false)
    } catch (err) {
      pushToast('No se pudo exportar la bóveda.', 'danger')
    } finally {
      setExportBusy(false)
    }
  }

  function handlePickFile(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const raw = parseBackupFile(reader.result)
        setPendingRaw(raw)
        setImportOpen(true)
      } catch (err) {
        pushToast(err.message || 'Archivo no válido.', 'danger')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  async function handleImport(password) {
    if (!pendingRaw) return
    setImportBusy(true)
    try {
      const bundle = await decryptBackup(pendingRaw, password)
      const ok = await confirm({
        title: 'Restaurar copia de seguridad',
        message: 'Esto reemplazará todas las cuentas, categorías, etiquetas, perfil y registro actuales de tu bóveda. No se puede deshacer.',
        danger: true,
        confirmLabel: 'Reemplazar todo',
      })
      if (!ok) {
        setImportBusy(false)
        return
      }
      const sensitiveKey = useAuthStore.getState().sensitiveKey
      const { bundle: readyBundle, downgraded } = await reEncryptBundleForVault(bundle, sensitiveKey)
      await replaceAll(readyBundle)
      if (downgraded > 0) {
        pushToast(`${downgraded} cuenta(s) perdieron la protección adicional. Configura tu PIN 2 para reactivarla.`, 'danger')
      }
      pushToast('Bóveda restaurada.', 'success')
      setImportOpen(false)
      setPendingRaw(null)
    } catch (err) {
      pushToast(err.message || 'No se pudo restaurar la copia de seguridad.', 'danger')
    } finally {
      setImportBusy(false)
    }
  }

  return (
    <section>
      <SectionHeader title="Copias de seguridad" subtitle="Un archivo cifrado con su propia contraseña, independiente de tus PIN" />
      <div className="space-y-2.5">
        <div className="flex items-center gap-3 rounded-xl2 border border-border bg-surface p-3.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
            <IconFileJson size={16} />
          </span>
          <div className="flex-1">
            <p className="text-[13.5px] text-ink">Exportar bóveda</p>
            <p className="text-[12px] text-inkFaint">Descarga un archivo .json cifrado con todos tus datos.</p>
          </div>
          <Button variant="secondary" size="sm" icon={IconDownload} onClick={() => setExportOpen(true)}>
            Exportar
          </Button>
        </div>

        <div className="flex items-center gap-3 rounded-xl2 border border-border bg-surface p-3.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
            <IconUpload size={16} />
          </span>
          <div className="flex-1">
            <p className="text-[13.5px] text-ink">Importar bóveda</p>
            <p className="text-[12px] text-inkFaint">Restaura tu bóveda desde un archivo de copia de seguridad.</p>
          </div>
          <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={handlePickFile} />
          <Button variant="secondary" size="sm" icon={IconUpload} onClick={() => fileRef.current?.click()}>
            Importar
          </Button>
        </div>
      </div>

      <BackupPasswordModal
        open={exportOpen}
        onClose={() => setExportOpen(false)}
        mode="create"
        title="Proteger tu copia de seguridad"
        subtitle="Elige una contraseña para cifrar el archivo. La necesitarás para restaurarlo."
        onSubmit={handleExport}
        submitting={exportBusy}
      />

      <BackupPasswordModal
        open={importOpen}
        onClose={() => {
          setImportOpen(false)
          setPendingRaw(null)
        }}
        mode="enter"
        title="Contraseña de la copia de seguridad"
        subtitle="Introduce la contraseña que usaste al exportar este archivo."
        onSubmit={handleImport}
        submitting={importBusy}
      />
    </section>
  )
}
