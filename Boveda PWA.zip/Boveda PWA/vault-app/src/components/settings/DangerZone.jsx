import SectionHeader from '../common/SectionHeader.jsx'
import Button from '../common/Button.jsx'
import { useAuthStore } from '../../state/useAuthStore.js'
import { useUiStore } from '../../state/useUiStore.js'
import { IconAlertOctagon } from '../../icons/index.jsx'

export default function DangerZone() {
  const wipeVault = useAuthStore((s) => s.wipeVault)
  const confirm = useUiStore((s) => s.confirm)
  const pushToast = useUiStore((s) => s.pushToast)

  async function handleReset() {
    const ok = await confirm({
      title: 'Restablecer la bóveda',
      message: 'Se borrarán permanentemente todas las cuentas, servicios, el perfil y el registro de este dispositivo. Esta acción no se puede deshacer.',
      danger: true,
      confirmLabel: 'Borrar todo',
    })
    if (!ok) return
    await wipeVault()
    pushToast('La bóveda se restableció en este dispositivo.', 'default')
  }

  return (
    <section>
      <SectionHeader title="Zona de riesgo" />
      <div className="flex items-center gap-3 rounded-xl2 border border-brick/30 bg-brick/[0.06] p-3.5">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brick/15 text-brick-soft">
          <IconAlertOctagon size={16} />
        </span>
        <div className="flex-1">
          <p className="text-[13.5px] text-ink">Restablecer bóveda</p>
          <p className="text-[12px] text-inkFaint">Borra todos los datos de este dispositivo de forma permanente.</p>
        </div>
        <Button variant="dangerSolid" size="sm" onClick={handleReset}>
          Restablecer
        </Button>
      </div>
    </section>
  )
}
