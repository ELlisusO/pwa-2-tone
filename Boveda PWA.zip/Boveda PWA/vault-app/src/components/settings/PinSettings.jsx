import { useState } from 'react'
import PinFlowModal from '../common/PinFlowModal.jsx'
import SectionHeader from '../common/SectionHeader.jsx'
import Button from '../common/Button.jsx'
import { useAuthStore, PIN1_LENGTH, PIN2_LENGTH } from '../../state/useAuthStore.js'
import { useUiStore } from '../../state/useUiStore.js'
import { IconLock, IconShieldCheck, IconKey } from '../../icons/index.jsx'

const FLOWS = {
  pin1: {
    length: PIN1_LENGTH,
    steps: [
      { key: 'current', title: 'PIN actual', subtitle: 'Introduce tu PIN principal actual' },
      { key: 'new', title: 'Nuevo PIN', subtitle: `Elige ${PIN1_LENGTH} dígitos nuevos` },
      { key: 'confirm', title: 'Confirma el nuevo PIN', subtitle: 'Vuelve a introducirlo', matchKey: 'new' },
    ],
    run: (v) => useAuthStore.getState().changePin1(v.current, v.new),
    successMsg: 'PIN principal actualizado.',
  },
  pin2setup: {
    length: PIN2_LENGTH,
    steps: [
      { key: 'new', title: 'Crea tu PIN 2', subtitle: `Elige ${PIN2_LENGTH} dígitos para tus cuentas protegidas` },
      { key: 'confirm', title: 'Confirma tu PIN 2', subtitle: 'Vuelve a introducirlo', matchKey: 'new' },
    ],
    run: (v) => useAuthStore.getState().setupPin2(v.new),
    successMsg: 'PIN 2 configurado.',
  },
  pin2change: {
    length: PIN2_LENGTH,
    steps: [
      { key: 'current', title: 'PIN 2 actual', subtitle: 'Introduce tu PIN 2 actual' },
      { key: 'new', title: 'Nuevo PIN 2', subtitle: `Elige ${PIN2_LENGTH} dígitos nuevos` },
      { key: 'confirm', title: 'Confirma el nuevo PIN 2', subtitle: 'Vuelve a introducirlo', matchKey: 'new' },
    ],
    run: (v) => useAuthStore.getState().changePin2(v.current, v.new),
    successMsg: 'PIN 2 actualizado.',
  },
  pin2disable: {
    length: PIN2_LENGTH,
    steps: [{ key: 'current', title: 'Desactivar protección adicional', subtitle: 'Introduce tu PIN 2 actual para confirmar' }],
    run: (v) => useAuthStore.getState().disablePin2(v.current),
    successMsg: 'Protección adicional desactivada.',
  },
}

export default function PinSettings() {
  const hasPin2 = useAuthStore((s) => !!s.meta?.pin2)
  const pushToast = useUiStore((s) => s.pushToast)
  const confirm = useUiStore((s) => s.confirm)
  const [flow, setFlow] = useState(null)

  async function handleSubmit(values) {
    const res = await FLOWS[flow].run(values)
    if (res.ok) pushToast(FLOWS[flow].successMsg, 'success')
    return res
  }

  async function startDisable() {
    const ok = await confirm({
      title: 'Desactivar protección adicional',
      message: 'Las cuentas marcadas como protegidas dejarán de requerir un PIN 2. Sus contraseñas quedarán protegidas solo por tu PIN principal.',
      danger: true,
      confirmLabel: 'Continuar',
    })
    if (ok) setFlow('pin2disable')
  }

  const active = flow ? FLOWS[flow] : null

  return (
    <section>
      <SectionHeader title="PIN de acceso" subtitle="Gestiona las dos capas de protección de tu bóveda" />
      <div className="space-y-2.5">
        <Row icon={IconLock} title="PIN principal" description="Protege el acceso general a la bóveda.">
          <Button variant="secondary" size="sm" onClick={() => setFlow('pin1')}>
            Cambiar
          </Button>
        </Row>

        <Row
          icon={IconShieldCheck}
          title="PIN 2 · Protección adicional"
          description={hasPin2 ? 'Protege tus cuentas más delicadas.' : 'Aún no configurado.'}
        >
          {hasPin2 ? (
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" onClick={() => setFlow('pin2change')}>
                Cambiar
              </Button>
              <Button variant="danger" size="sm" onClick={startDisable}>
                Desactivar
              </Button>
            </div>
          ) : (
            <Button variant="secondary" size="sm" icon={IconKey} onClick={() => setFlow('pin2setup')}>
              Configurar
            </Button>
          )}
        </Row>
      </div>

      {active && (
        <PinFlowModal open={!!flow} onClose={() => setFlow(null)} steps={active.steps} length={active.length} onSubmit={handleSubmit} />
      )}
    </section>
  )
}

function Row({ icon: Icon, title, description, children }) {
  return (
    <div className="flex items-center gap-3 rounded-xl2 border border-border bg-surface p-3.5">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
        <Icon size={16} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[13.5px] text-ink">{title}</p>
        <p className="truncate text-[12px] text-inkFaint">{description}</p>
      </div>
      {children}
    </div>
  )
}
