import SectionHeader from '../common/SectionHeader.jsx'
import Switch from '../common/Switch.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { IconMoon, IconSun } from '../../icons/index.jsx'

export default function AppearanceSettings() {
  const theme = useVaultStore((s) => s.settings.theme)
  const updateSettings = useVaultStore((s) => s.updateSettings)
  const isLight = theme === 'light'

  return (
    <section>
      <SectionHeader title="Apariencia" />
      <div className="flex items-center gap-3 rounded-xl2 border border-border bg-surface p-3.5">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-soft text-emerald">
          {isLight ? <IconSun size={16} /> : <IconMoon size={16} />}
        </span>
        <div className="flex-1">
          <Switch
            checked={isLight}
            onChange={(v) => updateSettings({ theme: v ? 'light' : 'dark' })}
            label="Modo claro"
            description="El modo oscuro es el predeterminado y el más cuidado."
          />
        </div>
      </div>
    </section>
  )
}
