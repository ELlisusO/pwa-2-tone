import { useState } from 'react'
import SectionHeader from '../common/SectionHeader.jsx'
import Chip from '../common/Chip.jsx'
import Button from '../common/Button.jsx'
import EmptyState from '../common/EmptyState.jsx'
import { useVaultStore } from '../../state/useVaultStore.js'
import { useUiStore } from '../../state/useUiStore.js'
import { IconTag, IconPlus } from '../../icons/index.jsx'

export default function TagManager() {
  const tags = useVaultStore((s) => s.tags)
  const addTag = useVaultStore((s) => s.addTag)
  const deleteTag = useVaultStore((s) => s.deleteTag)
  const confirm = useUiStore((s) => s.confirm)
  const [text, setText] = useState('')

  async function handleAdd() {
    if (!text.trim()) return
    await addTag(text.trim())
    setText('')
  }

  async function handleDelete(tag) {
    const ok = await confirm({
      title: `Eliminar etiqueta "${tag.name}"`,
      message: 'Se quitará de todas las cuentas y servicios que la usen.',
      danger: true,
      confirmLabel: 'Eliminar',
    })
    if (ok) deleteTag(tag.id)
  }

  return (
    <section>
      <SectionHeader title="Etiquetas" subtitle="Administra las etiquetas de tu bóveda" />
      <div className="mb-3 flex gap-2">
        <div className="flex flex-1 items-center gap-2 rounded-xl border border-border bg-surface2 px-3.5 py-2.5">
          <IconTag size={14} className="text-inkFaint" />
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAdd())}
            placeholder="Nueva etiqueta"
            className="min-w-0 flex-1 bg-transparent text-[13.5px] text-ink placeholder:text-inkFaint focus:outline-none"
          />
        </div>
        <Button variant="secondary" icon={IconPlus} onClick={handleAdd}>
          Añadir
        </Button>
      </div>
      {tags.length === 0 ? (
        <EmptyState icon={IconTag} title="Sin etiquetas todavía" compact />
      ) : (
        <div className="flex flex-wrap gap-1.5">
          {tags.map((t) => (
            <Chip key={t.id} icon={IconTag} label={t.name} onRemove={() => handleDelete(t)} />
          ))}
        </div>
      )}
    </section>
  )
}
